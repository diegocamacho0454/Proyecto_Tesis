--------------------------- REVISION DE LA LINEA ------------------------------------------------------------
SELECT A.CO_ID, FUNC_CAP_CO_ID_GSM(CO_ID,'MIN',3005) MIN,   FUNC_CAP_CO_ID_GSM(CO_ID,'IMSI',3005) IMSI,
FUNC_CAP_CO_ID_GSM(CO_ID,'HLR',NULL)  HLR,          FUNC_CAP_CO_ID_GSM(CO_ID,'SERV',3013) ACT,  --3013 --0001
FUNC_CAP_CO_ID_GSM(CO_ID,'RCAT',NULL) RC,           FUNC_CAP_CO_ID_GSM(CO_ID,'PLPR',NULL) TIPOPLAN,
FUNC_CAP_CO_ID_GSM(CO_ID,'CIC',3005) CIC,           A.STATUS  ,A.REF_TEXT, A.USERID, A.INSERT_DATE, A.TS, A.*, rowid 
FROM SYSADM.MDSRRTAB A WHERE CO_ID   IN (SELECT CO_ID  FROM CONTR_SERVICES WHERE DN_ID IN (
SELECT D.DN_ID FROM DIRECTORY_NUMBER D WHERE DN_NUM  IN ('3136519691'))) ORDER BY REQUEST DESC;  

select * from  MPUSNTAB M WHERE UPPER(SHDES) LIKE '%BL99G%';   --Servicios
select * from  MPUSNTAB M WHERE M.SNCODE in (6020, 3013, 3288);   --Servicios

--------------------------- SERVICIOS DE UNA LINEA -----------------------------------------------------------
  SELECT M.SNCODE,M.DES,C.SPCODE,S.DES,CS_SEQNO,CS_STAT_CHNG, 
  (SELECT DES FROM MPUTMTAB WHERE TMCODE = C.TMCODE AND STATUS = 'W') PLAN_TARIFARIO,C.*
  FROM CONTR_SERVICES C, MPUSNTAB M, MPUSPTAB S WHERE M.SNCODE = C.SNCODE AND S.SPCODE = C.SPCODE
  AND CO_ID = 31708766 ORDER BY C.CS_SEQNO    DESC, 2, C.SNCODE;
      
select * from  MPUSNTAB M  WHERE /* m.des like '%Internac%'*/SNCODE in (select distinct sncode from MPUlktmb Mp WHERE  mp.tmcode =13571);

select * from mpulktmb Mp WHERE  mp.tmcode =13571 and mp.sncode=5370;

--------------------------------------TRANSACCIONES BSCS-PCRF-MAGUARE--------------------------------------------
select * from SYSADM.CAP_PCRF_EVENTO e where e.msisdn in ('3107995991') order by e.fecha_procesado desc;

---------------------------------------CONTROL GPRS----------------------------------------------------------
select * from CAP_CONTROL_GPRS where msisdn in ('3107995991');

---------------------------------------CONFIGURACI�N PAQUETE GPRS--------------------------------------------------
select a.* from CAP_CONF_DATOS A WHERE SPCODE = 5087; 
select a.* from CAP_CONF_DATOS A WHERE TMCODE = 12072;

--------------------------- HISTORICO SERVICIOS DE UNA LINEA -------------------------------------------------
SELECT N.SNCODE, N.DES, I.SPCODE, S.DES, CS_SEQNO, CS_STAT_CHNG,
(SELECT DES FROM MPUTMTAB WHERE TMCODE = I.TMCODE AND STATUS = 'W') PLAN_TARIFARIO, I.*
FROM INH_DELETE_CONTR I, MPUSPTAB S, MPUSNTAB N
WHERE I.SPCODE = S.SPCODE AND I.SNCODE = N.SNCODE
AND CO_ID = '139242784' ORDER BY I.CS_SEQNO DESC, 2, I.SNCODE;

-------------------------------CUSTCODE-----------------------------------------------------------------------
SELECT a.dn_num, b.co_id, b.cs_seqno, b.tmcode, b.cs_stat_chng, b.cs_deactiv_date, d.customer_id, d.custcode
  FROM directory_number a, contr_services b, contract_all c, customer_all d
WHERE a.dn_num in ('3214742842')
   AND b.dn_id = a.dn_id
   AND c.co_id = b.co_id
   AND d.customer_id = c.customer_id
   --AND b.cs_deactiv_date IS NULL 
  ORDER BY nvl(b.cs_deactiv_date,SYSDATE) DESC ;
  
-------------------------------------Validacion creacion nuevo CUSCODE----------------------
select * from sysadm.inh_rel_equ_ser s where '109417587' in (s.customer_id_equipo, s.customer_id_servicio);

----------------------------------------Validacion acelaracion de cuotas--------------------
Select f.customer_id, f.amount, f.remark, f.period, f.descripcion 
from inh_fees_auditoria@BSCSREP_REPLI.WORLD f 
where f.sub_customer_id in (165216740) and f.glcode = 1305050025;

---------------------------Validacion factura en la que fueron aceleradas las cuotas--------------
select CUSTOMER_ID ,OHXACT documento ,OHENTDATE fecha_creac ,OHINVAMT valor ,OHOPNAMT pendiente ,OHSTATUS tipo_fact ,OHTOTAL_TAXES ,OHDUEDATE fecha_corte 
from orderhdr_all o 
where o.customer_id in (175996486) 
order by o.ohentdate desc;
  
---------------------------Valdacion registro del equipo en ACTIVA--------------------------
select * from activacion_equipo@activa where customer_id in (109417587) and fecha_inicial is null ;

---------------------------Valdacion factura cobro total equipo--------------------------
SELECT h.ohentdate, h.ohxact, h.customer_id, d.otglsale, g.gladesc, SUM(d.otmerch) VALOR,SUM(d.otexttax) IVA, g.GLATYPE 
FROM orderhdr h, ordertrailer d, glaccount g 
WHERE h.ohxact = d.otxact AND d.otglsale = g.glacode AND h.customer_id = 167226699 AND h.ohstatus = 'IN' AND h.ohxact = 681784350 
GROUP BY h.ohentdate, h.ohxact, h.customer_id, d.otglsale, g.gladesc, d.otexttax, g.GLATYPE ORDER BY h.ohentdate;
  
select * from inh_imei i where i.customer_id = '163891242';
 
select * from customer_all c where c.customer_id = '118074785';
  
select * from cashreceipts_all where customer_id='142408123';

-------------------------Revisi�n promociones-----------------------------------
select *
from sysadm.perm_usuarios p, sysadm.perm_camp_usuarios c, sysadm.perm_campana a
where p.customer_id = 109417587 and p.id = c.id_usuario and c.id_campana = a.id;

-------------------------Historico promociones-----------------------------------
select * from sysadm.perm_historico_beneficios a where a.id_usuario = 66811;
  
----------------- TIPO DE PLAN------------------------
SELECT a.dn_num, b.co_id, b.tmcode,(SELECT sysadm.fncextraer(x.clase_plan, ',', 3)FROM inh_tmsp_prep x WHERE x.tmcode = b.tmcode AND ROWNUM = 1) clase_plan
FROM directory_number a, contr_services b
WHERE a.dn_num IN ('&min')
AND b.dn_id = a.dn_id
AND SUBSTR(b.cs_stat_chng, -1) <> 'd';

----------------------------------------------ELEGIDOS------------------------------------------------------
SELECT A.*, ROWID  FROM MPUFFTAB A WHERE CO_ID = '175886423';
SELECT A.*, ROWID  FROM INH_ELEGIDOS_NEW.INH_ELEGIDOS A WHERE CO_ID = '175886423';
SELECT * FROM RED_INT WHERE CO_ID = '175886423' ORDER BY FECHA_CREACION DESC;

SELECT * FROM CICLOP.CAMBIO_PLAN_SINFIN@PLATAFORMA_PREPAGO WHERE MIN in ('3138956190');

inh_elegidos_new.PKG_ELEGIDOS.ELIMINAR_CONTRATO(); 

select * from elegidos_plan@activa where id_activacion in (select a.id_activacion from activacion@activa a where a.codmin  in ('&min'));

select * from inh_cambiofavorito_actualiza@plataforma_prepago where msisdn = (&min);

SELECT * FROM SYSADM.INH_ELEG5_LOG A WHERE A.CODMIN='118504328';  --LOG 5 MINUTOS
SELECT a.* FROM EX_DESACTIVSERVICIO a WHERE CO_ID = '90808902'; --DESACTIVACION SERVICIO

SELECT * FROM INH_TMSP_PREP TMS WHERE TMS.TMCODE=15111;

---------------------------------MICROCELDA--------------------  ----------------------------------------------
select * from inh_tmsp_prep  where tmcode=8982;

------------------------------------HISTORICO CONTROL HOTRATING----------------------------------------------
select * from CAP_MASIVOS_HISTORICO h where h.co_id='158169730' order by h.fecha desc;
select * from CAP_MASIVOS h where h.co_id='34688770' order by h.fecha desc;

------------- CONTR_DEVICES ---------- Para la ultima secuencia cd_deactiv_date - cd_moddate (null)
Select cd_seqno , co_id , cd_port_num , cd_activ_date , cd_validfrom, cd_entdate , cd_deactiv_date , cd_moddate ,
decode(substr(cd_sm_num,8,1),0,'Oriente',1,'Occidente',2,'Costa') Zona, 
''''||cd_sm_num||''''||',' , ''''||port_id||''''||','  , 
cd_status ,  cd_pending_state,ROWID  
from contr_devices a
where co_id in ('176318901')
order by CO_ID,cd_seqno asc; --136118313 3118584943

--Esta tabla contiene los cambios de n�mero de celular que---- STORAGE_MEDIUM ----- Para la sim activa (a) SM_MODDATE debe ser NULL
Select sm_serialnum , sm_status , sm_entdate , sm_moddate, ROWID
from storage_medium 
where sm_serialnum in ('89571010014019156713'
)order by SM_MODDATE asc;

---- PORT ---- Para la sim activa (a) PORT_DEACTIV_DATE - PORT_MODDATE deben ser NULL
select port_id , port_num , port_status , port_activ_date , port_deactiv_date , port_entdate , port_moddate, ROWID
from port p
where port_id  in ('172465663'
)order by port_activ_date asc;

select * from INH_INFO_CAMBIOMIN where customer_id=150860440;

-------------- DESCRIPCION PLANES -------------------------
select * from sysadm.ex_paquetes_serv q where q.spcode = 5075; 
select * from sysadm.ex_planes n where n.tmcode = '12063';
select * from split_contratos s where s.co_id = 69851896;

---FACTURA ELECTR�NICA
select * from ex_factu_elec_insentiva_invi i
where i.vcmin in (3177424602); 

------------------CODIGO MATERIAL ACTIVACION-------------------
select * from SYSADM.INH_INFOACTPREPAGO where codmin = '3003627745';

--------------------------------- ACTIVACIONES NORMALES ------------------------------------------------
SELECT id_activacion, codmin,codminext, tmcode, spcode, estado, tmcodeext, spcodeext, 
       datos, spcode_paq, mms, mensajes, a.rowid, a.resn, a.rtar, a.fecregis, a.fecbscs, a.text12, a.esn, 
       promocion, barrio, id_vendedor, sexo, iva_equipo, total_venta,
       grupo_clientes, centro_costo, sccode, trajo_equipo, tipo_contrato, text17 elegido_si5min,
       hlr
  FROM extranet.activacion@activa a 
 WHERE codmin in ('3134831067');
 
 select * from sysadm.inh_rel_equ_ser s where '136253781' in (s.customer_id_equipo, s.customer_id_servicio);

--------------------------------------TICKLERS---------------------------------------------------------------
select * from tickler_records t where customer_id = 175683755 order by t.created_date desc;

------------------------------------CUSTOMER ID MAESTRA------------------------------------------------------
select * from customer_all c where c.custcode='8.21599842';

---------- CRUCE DE MINES ----------
SELECT TAREA_ID, PROCESO_STATUS, FECHA_INICIO, PROCESO_ERRORES, USUARIORED, DESC_CORTA, DESC_USUARIO
FROM sysadm.ex_batch_Tareas WHERE DESC_CORTA = 'Cruce Mines' 
and PARAMETROS_STRING1 like '%3124925135%' ORDER BY TAREA_ID desc;

---------- VALIDAR ZONA ----------

SELECT a.dn_num, a.dn_status, a.dn_status_requ, a.hlcode 
FROM directory_number a 
WHERE a.dn_num IN ('3203919507','3124925135');

------------------------------------DETALLE DE FACTURACION--------------------------------------------------
select f.*, f.customer_id,remark,substr(TRIM(remark),-10),f.amount,f.entdate,f.valid_from, f.glcode /*+full f parallel (f ,4)*/ --, username,period,length(remark)
FROM sysadm.FEES f   --DE DOS MESES
--from inh_purging.fees_archiving f   --MAS DE DOS MESES
where f.customer_id in (33219671);
--AND f.valid_from>= to_date ('15082014 00:00:00','ddmmyyyy hh24:mi:ss')
--AND f.valid_from<= to_date ('14092014 23:59:59','ddmmyyyy hh24:mi:ss');
--AND substr(TRIM(remark),-10)= '3205810034';             
--AND length(remark)>69  --3146451332 
--AND remark like '%*#7%';

---consulta consecutivo de factura
SELECT o.ohxact consecutivo, customer_id, o.ohentdate fecha,o.ohinvamt vlr_pagar, o.ohstatus estado
FROM sysadm.orderhdr_all o
WHERE customer_id = '145171939'
ORDER BY o.ohentdate DESC;

--consulta detalle de factura
select a.otxact cnsc_detalle, a.otglsale cuenta,g.gladesc descripcion, a.otmerch valor 
from ordertrailer a, glaccount_all g 
where a.otglsale = g.glacode 
and otxact = 622589593;

select * from split_contratos s where s.co_id in('133746886','158945591','138192256','153477170','153477176','67108309','103686397','103685915','49955222','108435904','108436776','60789058','131303098','153477181','154635344','154636370','154502154','153477156','158428630','158484032','158484116','158410389','158410398','158399286','94123128','135344676','160479737','137783015','139603021','139107653','87145295','112559304','127025700','132020288','124917856','153477190','83386295','83386293','67110047','48696353','32345548','17581695','104852716','114418236','117478772','25792378','155273107','30530206','151436935','151625478','152116697','152115901','152118286','159046854','159047471','159048742','158988700','158988568','159047863','159048291','159047862','158903075','158901616','158871588','158850970','158769651','158769748','158770750','158771594','158871595','87251541','158770692','158769823','158770691','158769721','158547860','158544503','158552886','158548260','158552691','158552937','158552680','158547873','158594563','158553264','158786283','122169863','153477160','88209999','118146994','132606958','133797999','134294112','134463515','134463694','160479748','158904617','67109137','67110023','67110036','46825344','158728516','158728530','158945604','122185436','133746903','113185407','153477141','48696349','48696352','48812198','50107320','50621017','52050689','52028618','52030013','53574028','62066195','54135028','54824914','54825742','55841139','57918124','57647356','59910896','59910379','59885329','59912069','61150737','62055403','75400176','48688614','99732207','112557769','79630906','79630922','79619126','78362349','78039854','77590924','87090989','87091016','80444976','64167761','64168849','64271723','114530049','114530050','114530045','142075633','142076191','142118708','142154400','142352182','160479668','143252911','143252910','143367827','147326652','147933887','148522381','148520781','149503221','149502702','150220692','114418237','114530046','114530048','114530047','155273113','98904785','114530043','119234631','114418238','98811962','114530051');

-----------------------BONIFICACION 5 MINUTOS-----------------------
select * from inh_mindescuento
where co_id
in
       (select co_id
          from contr_services a
         where dn_id in
               (select dn_id from directory_number where dn_num in ('3144426267'))
               and substr (a.cs_stat_chng, -1)<> 'd');


--------------------CLAVE DE UNA L�NEA--------------------------
SELECT CSPASSWORD 
FROM customer_all 
WHERE customer_id = (select customer_id    
                    from contract_all
                     where co_id = (select co_id 
                                    from contr_services 
                                    where cs_deactiv_date is null
                                    and   dn_id = (select dn_id
                                                   FROM directory_number 
                                                   WHERE dn_num = '3133080078')));


--------------------------------MINES DE UN NIT--------------------------------------------------------------
SELECT '&nit', A.CO_ID, C.DN_NUM, A.CUSTOMER_ID
  FROM SYSADM.CONTRACT_ALL     A,
       SYSADM.CONTR_SERVICES   B,
       SYSADM.DIRECTORY_NUMBER C,
       INH_TMSP_PREP           D
WHERE B.DN_ID = C.DN_ID
   AND B.CO_ID = A.CO_ID
   AND A.TMCODE = D.TMCODE
   AND PREPAGO NOT IN (0, 3)
   AND SUBSTR(B.CS_STAT_CHNG, -1) <> 'd'
   AND CUSTOMER_ID IN
       (SELECT CUSTOMER_ID
          FROM SYSADM.CUSTOMER_ALL
         WHERE CUSTOMER_ID_HIGH IN (SELECT CUSTOMER_ID
                                      FROM SYSADM.CUSTOMER_ALL
                                     WHERE PASSPORTNO = '&nit'
                                       AND CSLEVEL = 10)
        UNION ALL
        SELECT CUSTOMER_ID
          FROM SYSADM.CUSTOMER_ALL
         WHERE CUSTOMER_ID_HIGH IS NULL
           AND PASSPORTNO = '&nit'
           AND CSLEVEL = 40);


------------------------------------------------------------------------------------------
select * from inh_mindescuento
where co_id
in
       (select co_id
          from contr_services a
         where dn_id in
               (select dn_id from directory_number where dn_num in ('3107774005'))
               and substr (a.cs_stat_chng, -1)<> 'd');


--------------- CONCILIACION ------------------- 
declare
vc varchar2(30000);
begin
sysadm.proc_concilia(154511088,vc); 
DBMS_OUTPUT.put_line(vc);
end;
