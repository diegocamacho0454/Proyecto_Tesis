-------------------Consulta 1.  (Obtener Co_id) gprs.--------------------
SELECT c.cgb_msisdn, c.cgb_migrado, p.plps_ilimitado, c.cgb_msisdn_ant,c.cgb_id, c.cgb_estado, c.cgb_indica, c.cgb_ctr, c.cgb_tope, c.cgb_conskb_add, c.cgb_cons, c.cgb_conskbant, c.cgb_conskb,c.cgb_dispkb,d.cort_cort_id,p.plps_plan,p.plps_paquete,p.plps_valor_kb,p.plps_incluido_mb,c.cgb_fechaini_add,c.cgb_fechafin_add
FROM cuentas_gprsb c, cortes d, plps p
WHERE c.cgb_plps_id = p.plps_id AND
       c.cgb_cort_id = d.cort_id AND
       c.cgb_msisdn IN  ('3208539022') AND
       c.cgb_estado = 'A';

------------------------------------Control GPRS-------------------------------------------------
select * from sysgprs.control_usuarios c where c.ctr_msisdn in (3126284273) order by c.ctr_fhora_ctr desc;

------------------------------Consultas de Migraci�n PCRF - paquetes smartphone----------------------------------
SELECT C.CGB_MIGRADO
      FROM SYSGPRS.CUENTAS_GPRSB C, (SELECT MAX(D.CGB_ID) ID
                                      FROM SYSGPRS.CUENTAS_GPRSB D
                                     WHERE D.CGB_MSISDN in ('3126284273')
                                       AND D.CGB_ESTADO = 'A') Q
     WHERE Q.ID = C.CGB_ID;
     
-------------------------------Mensajes de Consumos-------------------------------------
select * from envio_mo e where e.em_msisdn in (3142997790) order by e.em_fenvio_mensa desc;

-- Consulta tabla basica MAGUARE
select * from sysgprs.cuentas_gprsb ss where ss.cgb_msisdn=3106745511;
 
-- para conocer la configuracion del paquete o plan de datos registrado en Maguare para la l�nea
select * from plps where plps_id=13884;

-- Transacciones de BSCS - validacion campo migraci�n, si apc_procesado = 1 es que Maguar� ya actualiz� el usuario (cuentas_gprsb)
select * from sysgprs.aprov_gprsb a where apc_msisdn=3115084257 order by a.apc_fechareg desc;

-- para ver que significa cada evento de aprovisionamiento
select * from sysgprs.eventos e where e.even_id = 11;

--------------------------Transacciones-----------------------------------
SELECT t.tran_cuen_id, t.tran_msisdn, e.even_descripcion, t.tran_fecha_reg, p.plps_plan, p.plps_paquete, p.plps_techo_valor, p.plps_valor_kb, p.plps_incluido_mb              
FROM --sysgprs.transacciones_201202 t, 
     sysgprs.transacciones_20140925 t, sysgprs.eventos e, sysgprs.plps p     
WHERE/* t.tran_msisdn in ('&min')*/
     t.tran_cuen_id in /*('&CO_ID')*/ (select c.cgb_id FROM cuentas_gprsb c     
                               WHERE c.cgb_msisdn in ('&min'))
AND  t.tran_even_id = e.even_id 
AND  t.tran_tmcode = p.plps_tmcode
AND  t.tran_spcode = p.plps_spcode
AND  t.tran_resu_id = 0
ORDER BY t.tran_fecha_reg desc;

---------------Consulta 2. blackberry.------------------------
SELECT c.cgbb_msisdn,c.cgbb_id,c.cgbb_estado,c.cgbb_indica,c.cgbb_ctr,c.cgbb_tope,c.cgbb_conskb_add,c.cgbb_cons,c.cgbb_conskbant,c.cgbb_conskb,c.cgbb_dispkb,d.cort_cort_id,p.plps_plan,p.plps_paquete,p.plps_valor_kb,p.plps_incluido_mb,c.cgbb_fechaini_add,c.cgbb_fechafin_add
FROM cuentas_gprsbb c,
       cortes d,
       plps p
WHERE c.cgbb_plps_id = p.plps_id AND
       c.cgbb_cort_id = d.cort_id AND
       c.cgbb_msisdn = 3153929180  AND
       c.cgbb_estado = 'A';

------------------------------Consultas de Migraci�n PCRF - paquetes blackberry----------------------------------
SELECT C.CGBB_MIGRADO
        FROM SYSGPRS.CUENTAS_GPRSBB C, (SELECT MAX(D.CGBB_ID) ID
                                         FROM SYSGPRS.CUENTAS_GPRSBB D
                                        WHERE D.CGBB_MSISDN = '3142261509'
                                          AND D.CGBB_ESTADO = 'A') Q
       WHERE Q.ID = C.CGBB_ID;

------------------------------------Control Roaming GPRS-------------------------------------------------
select * from sysgprs.control_roaming c where c.ctrrac_msisdn = 3126913838 order by c.ctrrac_fhora_ctr desc;

select * from sysgprs.cuentas_gprsb_roaming cr where cr.cgr_msisdn = 3126913838;



