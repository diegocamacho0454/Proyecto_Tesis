  --Usuario_SMO--

  SELECT a.min, a.npa, a.plan, a.estado, a.cod_plan, a.d_corte,
         a.tecnologia, a.spcode, a.ndc, a.password, a.marca, a.npamin
    FROM inh_smo.usuarios_mo a WHERE
  npamin in ('&min');

  --Con este  query verificas el estado del min en el aprovisionador-- 

  select t.cap_npamin, t.cap_nuevo_min, t.cap_accion,
  decode(t.cap_accion,'A', 'Activaci�n','B','Activaci�n Categor�a T21','C','Conciliaci�n','D','Reposici�n','E','Cambio de Min','F','Cambio de Plan','G','Cambio a Estado Activo','H','Cambio a Estado Suspendido','I','Eliminaci�n','J','Suspensi�n','K','Reconexi�n'),
  t.cap_fecha_cargue,
  t.*
  from inh_smo.APROV_REGISTROS_CAP042008 t
  where t.cap_npamin in ('&min')
  order by t.cap_fecha_cargue desc;

  --Luego se verifica que se encuentren en la tabla usuarios_mo y en estado 0--

  select * from inh_smo.usuarios_mo@SMO07 t
  where npamin in ('&min');

  select * from inh_smo.usuarios_mo@SMO12 t
  where npamin in ('&min');

