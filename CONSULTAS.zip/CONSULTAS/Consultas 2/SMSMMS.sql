-----------------------------Averiguar MIN antiguo.-------------------------------------
select *
  from aprovisionamiento_hist a
 where a.apro_msisdn in ('3147843533')
 order by a.apro_msisdn, a.apro_fecha_reg, a.apro_even_id;

----------------------------------------------------------------------------------------
select /*+ INDEX( a ID_APRO_ESTA_FECHAR)*/ *  
  from aprovisionamiento a
 where a.apro_msisdn in ('3147843533')
 order by a.apro_msisdn, a.apro_fecha_reg, a.apro_even_id;
 
 select * from mensajes_incluidos m where m.minc_msisdn=3115165963; 

------------------------MOS (Tr�fico de Claro a Claro)---------------------------
SELECT M.MOS_CING_NUM ORIGEN,M.MOS_CLED_NUM DESTINO,M.MOS_SUBMITION FECHA_ENVIO,m.mos_delivery FECHA_RECEPCION, 'Mensaje de Texto a Claro' DESCRIPCION
FROM SYSMED.MOS_201412 M
WHERE M.MOS_CING_NUM = 3214024762 AND
m.mos_submition BETWEEN to_date('20141218000000','yyyymmddhh24miss')
                    AND to_date('20141231235959','yyyymmddhh24miss')
UNION ALL
SELECT M.MOS_CING_NUM ORIGEN,M.MOS_CLED_NUM DESTINO,M.MOS_SUBMITION FECHA_ENVIO,m.mos_delivery FECHA_RECEPCION, 'Mensaje de Texto a Claro' DESCRIPCION
FROM SYSMED.MOS_201501 M
WHERE M.MOS_CING_NUM = 3222168723 AND
m.mos_submition BETWEEN to_date('20150101000000','yyyymmddhh24miss')
                    AND to_date('20150130235959','yyyymmddhh24miss')
UNION ALL
SELECT M.MOS_CING_NUM ORIGEN,M.MOS_CLED_NUM DESTINO,M.MOS_SUBMITION FECHA_ENVIO,m.mos_delivery FECHA_RECEPCION, 'Mensaje de Texto a Claro' DESCRIPCION
FROM SYSMED.MOS_201502 M
WHERE M.MOS_CING_NUM = 3222168723 AND
m.mos_submition BETWEEN to_date('20150201000000','yyyymmddhh24miss')
                    AND to_date('20150227235959','yyyymmddhh24miss')
order by FECHA_ENVIO                  



-----------------------Mensajes (Trafico Claro-Otros)------------------------------
  SELECT me.mens_called_number ORIGEN,me.mens_cled_cuid DESTINO,me.mens_codigo_servicio,me.mens_fecha_envio FECHA_ENVIO,me.mens_fecha_recepcion FECHA_RECEPCION,sp.sptr_descripcion DESCRIPCION,ta.tari_valor
  FROM mensajes_201401 me,sptr sp,tarifas ta
   WHERE me.mens_sptr_id = sp.sptr_id
     AND me.mens_tari_id = ta.tari_id
     AND me.mens_called_number in ('3144702374')
     AND me.mens_fecha_envio BETWEEN to_date ('20140123000000','yyyymmddhh24miss')
                                 AND to_date ('20140131235959','yyyymmddhh24miss') 
UNION ALL
  SELECT me.mens_called_number ORIGEN,me.mens_cled_cuid DESTINO,me.mens_codigo_servicio,me.mens_fecha_envio FECHA_ENVIO,me.mens_fecha_recepcion FECHA_RECEPCION,sp.sptr_descripcion DESCRIPCION,ta.tari_valor
  FROM mensajes_201402 me,sptr sp,tarifas ta
   WHERE me.mens_sptr_id = sp.sptr_id
     AND me.mens_tari_id = ta.tari_id
     AND me.mens_called_number in ('3144702374')
     AND me.mens_fecha_envio BETWEEN to_date ('20140201000000','yyyymmddhh24miss')
                                 AND to_date ('20140228235959','yyyymmddhh24miss')
UNION ALL
  SELECT me.mens_called_number ORIGEN,me.mens_cled_cuid DESTINO,me.mens_codigo_servicio,me.mens_fecha_envio FECHA_ENVIO,me.mens_fecha_recepcion FECHA_RECEPCION,sp.sptr_descripcion DESCRIPCION,ta.tari_valor
  FROM mensajes_201403 me,sptr sp,tarifas ta
   WHERE me.mens_sptr_id = sp.sptr_id
     AND me.mens_tari_id = ta.tari_id
     AND me.mens_called_number in ('3216766609')
     AND me.mens_fecha_envio BETWEEN to_date ('20140301000000','yyyymmddhh24miss')
                                 AND to_date ('20140323235959','yyyymmddhh24miss')                                
UNION ALL
  SELECT me.mens_called_number ORIGEN,me.mens_cled_cuid DESTINO,me.mens_codigo_servicio,me.mens_fecha_envio FECHA_ENVIO,me.mens_fecha_recepcion FECHA_RECEPCION,sp.sptr_descripcion DESCRIPCION,ta.tari_valor
  FROM mensajes_201404 me,sptr sp,tarifas ta
   WHERE me.mens_sptr_id = sp.sptr_id
     AND me.mens_tari_id = ta.tari_id
     AND me.mens_called_number in ('3216766609')
     AND me.mens_fecha_envio BETWEEN to_date ('20140425000000','yyyymmddhh24miss')
                                 AND to_date ('20140430235959','yyyymmddhh24miss')
UNION ALL
  SELECT me.mens_called_number ORIGEN,me.mens_cled_cuid DESTINO,me.mens_codigo_servicio,me.mens_fecha_envio FECHA_ENVIO,me.mens_fecha_recepcion FECHA_RECEPCION,sp.sptr_descripcion DESCRIPCION,ta.tari_valor
  FROM mensajes_201501 me,sptr sp,tarifas ta
   WHERE me.mens_sptr_id = sp.sptr_id
     AND me.mens_tari_id = ta.tari_id
     AND me.mens_called_number in ('3222168723')
     AND me.mens_fecha_envio BETWEEN to_date ('20150101000000','yyyymmddhh24miss')
                                 AND to_date ('20150130235959','yyyymmddhh24miss')
