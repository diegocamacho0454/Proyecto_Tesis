--------------------------DATOS HOTATING--------------------------------
SELECT C1.CHL_INICIO,C1.CHL_FINICIO_CORTE, B1.PBS_PLAN_DES,B1.CFM,B1.CFM2,B1.CFMP,H1.*
FROM SYSHOT.HOT_USUARIO_01 H1, SYSHOT.HOT_CICLO C1, SYSHOT.HOT_PLANES_BSCS B1, SYSHOT.HOT_TIPOPLAN P1
WHERE H1.DN_NUM IN ('63281501') /*H1.CO_ID = 1900641*/
   AND H1.CIC_CICLO = C1.CIC_CICLO
   AND H1.CIC_TMCODE = B1.TMCODE
   AND B1.PLAN_HR = P1.TTP_IDENHOT;

--------------------------HISTORICO CONTROLES-----------------------------------------
SELECT *
FROM SYSHOT.HOT_TRANS_ENVIO TRANS
WHERE TRANS.TRE_DN_NUM IN ('62348384')
ORDER BY TRANS.TRE_FENVIO_PRP DESC;

----------------------------TRANSACCIONES---------------------------------   
SELECT /*+full(TR) parallel(TR,8)*/ *
  FROM SYSHOT.TRANSACCION TR
WHERE TR.TRA_DESCRIPCION LIKE '%62192352%' /*or TR.TRA_DESCRIPCION LIKE '%112283985%'*/ 
   AND TRA_FECHA >= TO_DATE('05/02/2014', 'dd/mm/rrrr'); 
   
----------------------------------------------------------------------
SELECT *
FROM SYSHOT.HOT_MIXTOS
WHERE HM_DN_NUM = '62348384'
ORDER BY HM_FECHA DESC;

------------------------ELEGIDOS------------------------------------------------   
SELECT * FROM SYSHOT.HOT_ELEGIDO WHERE CO_ID = 2023430;

SELECT * FROM HOT_ELEGIDO_BOLSA UU WHERE UU.CO_ID = 152969459;

-------Pasaminutos que ha hecho HotRating HotRatingProd -------------
SELECT BS.*--, ROWID
FROM SYSHOT.BSCS_ROLLOVER BS
WHERE --BS.CELULAR = '62580410'
bs.co_id= 1879794
order by fecha_reporte desc;

-----Pasaminutos entregados------

SELECT *
  FROM SYSHOT.HISTORICO_CANT_ROLLOVER HS
WHERE HS.MSISDN in ('64785080')
ORDER BY HS.FECHA_INS DESC;

