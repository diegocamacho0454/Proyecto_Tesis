-------------Encontrar IMSI asociado a la l�nea------------------------
SELECT u.uro_imsi IMSI, u.uro_min FROM usuarios_roaming u WHERE u.uro_min = '62539024';

---------------Para cuentas desactivadas.---------------------------------
select * from usuarios_roaming_historico where urh_min='62539024';
       
-------------------Consulta Consumos por IMSI (Vista)-------------------------
select * from billroac.VM_CDRAC t
WHERE t.cdrac_imsi =714030003200434
AND cdrac_fecha >= to_date (20131201,'rrrrmmdd')
AND cdrac_fecha <= to_date (20131205,'rrrrmmdd')
AND T.CDRAC_SER_ID IN (5);
-- Para consultas de GPRS SERVICIO: 5
-- Para consultas de SMS SERVICIO:  2
-- Para consultas de VOZ SERVICIO: 1


-------------------Consulta Detalle Consumo por IMSI--------------------------
select * FROM cdrac c
WHERE c.crc_cin_id IN (
  select cin.cin_id FROM cinta_rac cin WHERE  cin.cin_tipo_cinta in (10, 1)
  and cin.cin_fecha_ini >= to_date('20131206','YYYYMMDD')
  AND cin.cin_fecha_fin <= to_date('20140105','YYYYMMDD') )
AND c.crc_abo_a =   7140300031 --7321010194  
AND c.crc_abo_a_of = 82118;--75770
-- Para consultas de GPRS SERVICIO: 10
-- Para consultas de SMS SERVICIO:  2
-- Para consultas de VOZ SERVICIO: 1

---------------Conocer el paquete Roaming--------------------------
select * from cliente_servgene where celular ='66781236';  

---------------Conocer descripcion el paquete Roaming--------------
select * FROM servicios_espe e where e.cod_serv = 5 OR e.cod_servpp = 5;

select * FROM serviespe_vs_gruposop s WHERE s.cod_ser = 68;

SELECT * FROM DESTINOS D WHERE D.DES_ID =  33;
