-------------------------Destinos Claro----------------------------
SELECT M.MOS_CING_NUM ORIGEN,M.MOS_CLED_NUM DESTINO,M.MOS_SUBMITION FECHA_ENVIO,m.mos_delivery FECHA_RECEPCION, 'Mensaje de Texto a Claro' DESCRIPCION
FROM SYSMED.MOS_201307 M
WHERE M.MOS_CING_NUM = 62812510 AND
m.mos_submition BETWEEN to_date('20130706000000','yyyymmddhh24miss')
                    AND to_date('20130731235959','yyyymmddhh24miss')
UNION ALL
SELECT M.MOS_CING_NUM ORIGEN,M.MOS_CLED_NUM DESTINO,M.MOS_SUBMITION FECHA_ENVIO,m.mos_delivery FECHA_RECEPCION, 'Mensaje de Texto a Claro' DESCRIPCION
FROM SYSMED.MOS_201308 M
WHERE M.MOS_CING_NUM = 62812510 AND
m.mos_submition BETWEEN to_date('20130801000000','yyyymmddhh24miss')
                    AND to_date('20130831235959','yyyymmddhh24miss')
UNION ALL
SELECT M.MOS_CING_NUM ORIGEN,M.MOS_CLED_NUM DESTINO,M.MOS_SUBMITION FECHA_ENVIO,m.mos_delivery FECHA_RECEPCION, 'Mensaje de Texto a Claro' DESCRIPCION
FROM SYSMED.MOS_201309 M
WHERE M.MOS_CING_NUM = 62812510  AND
m.mos_submition BETWEEN to_date('20130901000000','yyyymmddhh24miss')
                    AND to_date('20130930235959','yyyymmddhh24miss')
UNION ALL
SELECT M.MOS_CING_NUM ORIGEN,M.MOS_CLED_NUM DESTINO,M.MOS_SUBMITION FECHA_ENVIO,m.mos_delivery FECHA_RECEPCION, 'Mensaje de Texto a Claro' DESCRIPCION
FROM SYSMED.MOS_201310 M
WHERE M.MOS_CING_NUM = 62812510  AND
m.mos_submition BETWEEN to_date('20131001000000','yyyymmddhh24miss')
                    AND to_date('20131031235959','yyyymmddhh24miss')
UNION ALL
SELECT M.MOS_CING_NUM ORIGEN,M.MOS_CLED_NUM DESTINO,M.MOS_SUBMITION FECHA_ENVIO,m.mos_delivery FECHA_RECEPCION, 'Mensaje de Texto a Claro' DESCRIPCION
FROM SYSMED.MOS_201311 M
WHERE M.MOS_CING_NUM = 62812510  AND
m.mos_submition BETWEEN to_date('20131101000000','yyyymmddhh24miss')
                    AND to_date('20131130235959','yyyymmddhh24miss')
UNION ALL
SELECT M.MOS_CING_NUM ORIGEN,M.MOS_CLED_NUM DESTINO,M.MOS_SUBMITION FECHA_ENVIO,m.mos_delivery FECHA_RECEPCION, 'Mensaje de Texto a Claro' DESCRIPCION
FROM SYSMED.MOS_201312 M
WHERE M.MOS_CING_NUM = 62812510  AND
m.mos_submition BETWEEN to_date('20131201000000','yyyymmddhh24miss')
                    AND to_date('20131205235959','yyyymmddhh24miss')
                    
----------------------Otros destinos-----------------------------
  SELECT me.mens_called_number ORIGEN,me.mens_cled_cuid DESTINO,me.mens_codigo_servicio,me.mens_fecha_envio FECHA_ENVIO,me.mens_fecha_recepcion FECHA_RECEPCION,sp.sptr_descripcion DESCRIPCION,ta.tari_valor
  FROM mensajes_201307 me,sptr sp,tarifas ta
   WHERE me.mens_sptr_id = sp.sptr_id
     AND me.mens_tari_id = ta.tari_id
     AND me.mens_called_number in ('62812510')
     AND me.mens_fecha_envio BETWEEN to_date ('20130706000000','yyyymmddhh24miss')
                                 AND to_date ('20130731235959','yyyymmddhh24miss')
UNION ALL
  SELECT me.mens_called_number ORIGEN,me.mens_cled_cuid DESTINO,me.mens_codigo_servicio,me.mens_fecha_envio FECHA_ENVIO,me.mens_fecha_recepcion FECHA_RECEPCION,sp.sptr_descripcion DESCRIPCION,ta.tari_valor
  FROM mensajes_201308 me,sptr sp,tarifas ta
   WHERE me.mens_sptr_id = sp.sptr_id
     AND me.mens_tari_id = ta.tari_id
     AND me.mens_called_number in ('62812510')
     AND me.mens_fecha_envio BETWEEN to_date ('20130801000000','yyyymmddhh24miss')
                                 AND to_date ('20130831235959','yyyymmddhh24miss')
UNION ALL
  SELECT me.mens_called_number ORIGEN,me.mens_cled_cuid DESTINO,me.mens_codigo_servicio,me.mens_fecha_envio FECHA_ENVIO,me.mens_fecha_recepcion FECHA_RECEPCION,sp.sptr_descripcion DESCRIPCION,ta.tari_valor
  FROM mensajes_201309 me,sptr sp,tarifas ta
   WHERE me.mens_sptr_id = sp.sptr_id
     AND me.mens_tari_id = ta.tari_id
     AND me.mens_called_number in ('62812510')
     AND me.mens_fecha_envio BETWEEN to_date ('20130901000000','yyyymmddhh24miss')
                                 AND to_date ('20130930235959','yyyymmddhh24miss')
UNION ALL
  SELECT me.mens_called_number ORIGEN,me.mens_cled_cuid DESTINO,me.mens_codigo_servicio,me.mens_fecha_envio FECHA_ENVIO,me.mens_fecha_recepcion FECHA_RECEPCION,sp.sptr_descripcion DESCRIPCION,ta.tari_valor
  FROM mensajes_201310 me,sptr sp,tarifas ta
   WHERE me.mens_sptr_id = sp.sptr_id
     AND me.mens_tari_id = ta.tari_id
     AND me.mens_called_number in ('62812510')
     AND me.mens_fecha_envio BETWEEN to_date ('20131001000000','yyyymmddhh24miss')
                                 AND to_date ('20131031235959','yyyymmddhh24miss')
UNION ALL
  SELECT me.mens_called_number ORIGEN,me.mens_cled_cuid DESTINO,me.mens_codigo_servicio,me.mens_fecha_envio FECHA_ENVIO,me.mens_fecha_recepcion FECHA_RECEPCION,sp.sptr_descripcion DESCRIPCION,ta.tari_valor
  FROM mensajes_201311 me,sptr sp,tarifas ta
   WHERE me.mens_sptr_id = sp.sptr_id
     AND me.mens_tari_id = ta.tari_id
     AND me.mens_called_number in ('62812510')
     AND me.mens_fecha_envio BETWEEN to_date ('20131101000000','yyyymmddhh24miss')
                                 AND to_date ('20131130235959','yyyymmddhh24miss')
UNION ALL
  SELECT me.mens_called_number ORIGEN,me.mens_cled_cuid DESTINO,me.mens_codigo_servicio,me.mens_fecha_envio FECHA_ENVIO,me.mens_fecha_recepcion FECHA_RECEPCION,sp.sptr_descripcion DESCRIPCION,ta.tari_valor
  FROM mensajes_201312 me,sptr sp,tarifas ta
   WHERE me.mens_sptr_id = sp.sptr_id
     AND me.mens_tari_id = ta.tari_id
     AND me.mens_called_number in ('62812510')
     AND me.mens_fecha_envio BETWEEN to_date ('20131201000000','yyyymmddhh24miss')
                                 AND to_date ('20131205235959','yyyymmddhh24miss')
