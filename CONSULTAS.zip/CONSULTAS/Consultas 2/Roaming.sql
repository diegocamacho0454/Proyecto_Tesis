-------------Encontrar IMSI asociado a la l�nea------------------------
SELECT u.uro_imsi IMSI FROM usuarios_roaming u WHERE u.uro_imsi = '&MIN'; 

SELECT * FROM usuarios_roaming u WHERE u.uro_imsi = 732101151862666;

---------------Para cuentas desactivadas.---------------------------------
select * from usuarios_roaming_historico where urh_min='3187165731';
       
-------------------Consulta Consumos por IMSI (Vista)-------------------------
select * from billroac.VM_CDRAC t   
WHERE t.cdrac_imsi in (732101080354944)  
AND cdrac_fecha >= to_date (20141205,'rrrrmmdd')
AND cdrac_fecha <= to_date (20150105,'rrrrmmdd')
AND T.CDRAC_SER_ID IN (5);
-- Para consultas de GPRS SERVICIO: 5
-- Para consultas de SMS SERVICIO:  2
-- Para consultas de VOZ SERVICIO: 1


-------------------Consulta Detalle Consumo por IMSI--------------------------
select * FROM cdrac c
WHERE c.crc_cin_id IN (
  select cin.cin_id FROM cinta_rac cin WHERE  cin.cin_tipo_cinta in (10)
  and cin.cin_fecha_ini >= to_date('20150310','YYYYMMDD')
  AND cin.cin_fecha_fin <= to_date('20150325','YYYYMMDD') )
AND c.crc_abo_a =   7321010812 --7321010194  
AND c.crc_abo_a_of = 18717;--75770
-- Para consultas de GPRS SERVICIO: 10
-- Para consultas de SMS SERVICIO:  2
-- Para consultas de VOZ SERVICIO: 1

---------------Conocer el paquete Roaming--------------------------
select * from cliente_servgene where celular ='3208133247' order by fecha_ini desc;

---------------Conocer descripcion el paquete Roaming--------------
select * FROM servicios_espe e where e.cod_serv = 455 OR e.cod_servpp = 455;

select * FROM serviespe_vs_gruposop s WHERE s.cod_ser = 68;

SELECT * FROM DESTINOS D WHERE D.DES_ID =  33;

/*Para visualizar el consumo de un paquete de bolsa de un usuario*/
SELECT  b.*
  FROM acum_bolsa b
 WHERE b.abl_min = 3108963363
 and b.abl_fechatra >= to_date('26/03/2014','DD/MM/YYYY');

