-------------------Consulta 1.  (Obtener Co_id) gprs.--------------------
SELECT c.cgb_msisdn, p.plps_ilimitado, c.cgb_msisdn_ant,c.cgb_id, c.cgb_estado, c.cgb_indica, c.cgb_ctr, c.cgb_tope, c.cgb_conskb_add, c.cgb_cons, c.cgb_conskbant, c.cgb_conskb,c.cgb_dispkb,d.cort_cort_id,p.plps_plan,p.plps_paquete,p.plps_valor_kb,p.plps_incluido_mb,c.cgb_fechaini_add,c.cgb_fechafin_add
FROM sysgprs.cuentas_gprsb c,
       sysgprs.cortes d,
       sysgprs.plps p
WHERE c.cgb_plps_id = p.plps_id AND
       c.cgb_cort_id = d.cort_id AND
       c.cgb_msisdn = 66613086 AND
       c.cgb_estado = 'A';
       
------------------------------------Control GPRS-------------------------------------------------
select * from sysgprs.control_usuarios c where c.ctr_msisdn = 65724504 order by c.ctr_fhora_ctr desc;

--------------------------Transacciones-----------------------------------
SELECT t.tran_cuen_id, t.tran_msisdn, e.even_descripcion, t.tran_fecha_reg, p.plps_plan, p.plps_paquete, p.plps_techo_valor, p.plps_valor_kb, p.plps_incluido_mb              
FROM --sysgprs.transacciones_201202 t, 
     transacciones t, eventos e, plps p      
WHERE/* t.tran_msisdn in ('&min')*/
     t.tran_cuen_id in /*('&CO_ID')*/ (select c.cgb_id FROM SYSGPRS.cuentas_gprsb c     
                               WHERE c.cgb_msisdn in ('&min'))
AND  t.tran_even_id = e.even_id 
AND  t.tran_tmcode = p.plps_tmcode
AND  t.tran_spcode = p.plps_spcode
AND  t.tran_resu_id = 0
ORDER BY t.tran_fecha_reg desc;

-------------------------------Configuaracion Control--------------------------------
select * from config_control;
       
---------------Consulta 2.  (Obtener Co_id) blackberry.------------------------
SELECT c.cgbb_msisdn,c.cgbb_id,c.cgbb_estado,c.cgbb_indica,c.cgbb_ctr,c.cgbb_tope,c.cgbb_conskb_add,c.cgbb_cons,c.cgbb_conskbant,c.cgbb_conskb,c.cgbb_dispkb,d.cort_cort_id,p.plps_plan,p.plps_paquete,p.plps_valor_kb,p.plps_incluido_mb,c.cgbb_fechaini_add,c.cgbb_fechafin_add
FROM sysgprs.cuentas_gprsbb c,
       sysgprs.cortes d,
       sysgprs.plps p
WHERE c.cgbb_plps_id = p.plps_id AND
       c.cgbb_cort_id = d.cort_id AND
       c.cgbb_msisdn = 62426156 AND
       c.cgbb_estado = 'A';

----------------------------------Trafico de datos Panam�--------------------------------------
SELECT c.* FROM sysgprs.cuentas_gprsb c WHERE c.cgb_msisdn = 62047776    

select tr.cons_msisdn, tr.cons_cuen_id, tr.cons_uplink, tr.cons_downlink, tr. cons_cantidad_kb, tr.cons_cobrado_kb, tr.cons_kbincluidos, tr.cons_kbsobrepasados, tr.cons_cobrado_kb, tr.cons_fecha_trafico, tr.cons_imsi, tr.cons_imei  
from sysgprs.consumos_intwap201305 tr where tr.cons_cuen_id = 400238
union all
select tr.cons_msisdn, tr.cons_cuen_id, tr.cons_uplink, tr.cons_downlink, tr. cons_cantidad_kb, tr.cons_cobrado_kb, tr.cons_kbincluidos, tr.cons_kbsobrepasados, tr.cons_cobrado_kb, tr.cons_fecha_trafico, tr.cons_imsi, tr.cons_imei  
from sysgprs.consumos_intwap201306 tr where tr.cons_cuen_id = 443586
union all
select tr.cons_msisdn, tr.cons_cuen_id, tr.cons_uplink, tr.cons_downlink, tr. cons_cantidad_kb, tr.cons_cobrado_kb, tr.cons_kbincluidos, tr.cons_kbsobrepasados, tr.cons_cobrado_kb, tr.cons_fecha_trafico, tr.cons_imsi, tr.cons_imei  
from sysgprs.consumos_intwap201307 tr where tr.cons_cuen_id = 457904
union all
select tr.cons_msisdn, tr.cons_cuen_id, tr.cons_uplink, tr.cons_downlink, tr. cons_cantidad_kb, tr.cons_cobrado_kb, tr.cons_kbincluidos, tr.cons_kbsobrepasados, tr.cons_cobrado_kb, tr.cons_fecha_trafico, tr.cons_imsi, tr.cons_imei  
from sysgprs.consumos_intwap201308 tr where tr.cons_cuen_id = 552382
union all
select tr.cons_msisdn, tr.cons_cuen_id, tr.cons_uplink, tr.cons_downlink, tr. cons_cantidad_kb, tr.cons_cobrado_kb, tr.cons_kbincluidos, tr.cons_kbsobrepasados, tr.cons_cobrado_kb, tr.cons_fecha_trafico, tr.cons_imsi, tr.cons_imei  
from sysgprs.consumos_intwap201309 tr where tr.cons_cuen_id = 552382
union all
select tr.cons_msisdn, tr.cons_cuen_id, tr.cons_uplink, tr.cons_downlink, tr. cons_cantidad_kb, tr.cons_cobrado_kb, tr.cons_kbincluidos, tr.cons_kbsobrepasados, tr.cons_cobrado_kb, tr.cons_fecha_trafico, tr.cons_imsi, tr.cons_imei  
from sysgprs.consumos_intwap201310 tr where tr.cons_cuen_id = 138442
union all
select tr.cons_msisdn, tr.cons_cuen_id, tr.cons_uplink, tr.cons_downlink, tr. cons_cantidad_kb, tr.cons_cobrado_kb, tr.cons_kbincluidos, tr.cons_kbsobrepasados, tr.cons_cobrado_kb, tr.cons_fecha_trafico, tr.cons_imsi, tr.cons_imei  
from sysgprs.consumos_intwap201311 tr where tr.cons_cuen_id = 535465
union all
select tr.cons_msisdn, tr.cons_cuen_id, tr.cons_uplink, tr.cons_downlink, tr. cons_cantidad_kb, tr.cons_cobrado_kb, tr.cons_kbincluidos, tr.cons_kbsobrepasados, tr.cons_cobrado_kb, tr.cons_fecha_trafico, tr.cons_imsi, tr.cons_imei  
from sysgprs.consumos_intwap201312 tr where tr.cons_cuen_id = 529909
union all
select tr.cons_msisdn, tr.cons_cuen_id, tr.cons_uplink, tr.cons_downlink, tr. cons_cantidad_kb, tr.cons_cobrado_kb, tr.cons_kbincluidos, tr.cons_kbsobrepasados, tr.cons_cobrado_kb, tr.cons_fecha_trafico, tr.cons_imsi, tr.cons_imei  
from sysgprs.consumos_intwap201401 tr where tr.cons_cuen_id = 529909
union all
select tr.cons_msisdn, tr.cons_cuen_id, tr.cons_uplink, tr.cons_downlink, tr. cons_cantidad_kb, tr.cons_cobrado_kb, tr.cons_kbincluidos, tr.cons_kbsobrepasados, tr.cons_cobrado_kb, tr.cons_fecha_trafico, tr.cons_imsi, tr.cons_imei  
from sysgprs.consumos_intwap201402 tr where tr.cons_cuen_id = 529909
union all
select tr.cons_msisdn, tr.cons_cuen_id, tr.cons_uplink, tr.cons_downlink, tr. cons_cantidad_kb, tr.cons_cobrado_kb, tr.cons_kbincluidos, tr.cons_kbsobrepasados, tr.cons_cobrado_kb, tr.cons_fecha_trafico, tr.cons_imsi, tr.cons_imei  
from sysgprs.consumos_intwap201403 tr where tr.cons_cuen_id = 585374
union all
select tr.cons_msisdn, tr.cons_cuen_id, tr.cons_uplink, tr.cons_downlink, tr. cons_cantidad_kb, tr.cons_cobrado_kb, tr.cons_kbincluidos, tr.cons_kbsobrepasados, tr.cons_cobrado_kb, tr.cons_fecha_trafico, tr.cons_imsi, tr.cons_imei  
from sysgprs.consumos_intwap201404 tr where tr.cons_cuen_id = 585374
union all
select tr.cons_msisdn, tr.cons_cuen_id, tr.cons_uplink, tr.cons_downlink, tr. cons_cantidad_kb, tr.cons_cobrado_kb, tr.cons_kbincluidos, tr.cons_kbsobrepasados, tr.cons_cobrado_kb, tr.cons_fecha_trafico, tr.cons_imsi, tr.cons_imei  
from sysgprs.consumos_intwap201405 tr where tr.cons_cuen_id = 585374
union all
select tr.cons_msisdn, tr.cons_cuen_id, tr.cons_uplink, tr.cons_downlink, tr. cons_cantidad_kb, tr.cons_cobrado_kb, tr.cons_kbincluidos, tr.cons_kbsobrepasados, tr.cons_cobrado_kb, tr.cons_fecha_trafico, tr.cons_imsi, tr.cons_imei  
from sysgprs.consumos_intwap201406 tr where tr.cons_cuen_id = 585374
union all
select tr.cons_msisdn, tr.cons_cuen_id, tr.cons_uplink, tr.cons_downlink, tr. cons_cantidad_kb, tr.cons_cobrado_kb, tr.cons_kbincluidos, tr.cons_kbsobrepasados, tr.cons_cobrado_kb, tr.cons_fecha_trafico, tr.cons_imsi, tr.cons_imei  
from sysgprs.consumos_intwap201407 tr where tr.cons_cuen_id = 466235
union all
select tr.cons_msisdn, tr.cons_cuen_id, tr.cons_uplink, tr.cons_downlink, tr. cons_cantidad_kb, tr.cons_cobrado_kb, tr.cons_kbincluidos, tr.cons_kbsobrepasados, tr.cons_cobrado_kb, tr.cons_fecha_trafico, tr.cons_imsi, tr.cons_imei  
from sysgprs.consumos_intwap201408 tr where tr.cons_cuen_id = 466235

select * from sysgprs.consumos_blackb201403 bb where bb.cons_msisdn= 62328313
union all
select * from sysgprs.consumos_blackb201404 bb where bb.cons_msisdn= 62328313
