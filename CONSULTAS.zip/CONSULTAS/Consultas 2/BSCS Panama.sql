--------------------------- REVISION DE LA LINEA ------------------------------------------------------------
SELECT A.CO_ID, FUNC_CAP_CO_ID_GSM(CO_ID,'MIN',3005) MIN,   FUNC_CAP_CO_ID_GSM(CO_ID,'IMSI',3005) IMSI,
FUNC_CAP_CO_ID_GSM(CO_ID,'HLR',NULL)  HLR,          FUNC_CAP_CO_ID_GSM(CO_ID,'SERV',3013) ACT,  --3013 --0001
FUNC_CAP_CO_ID_GSM(CO_ID,'RCAT',NULL) RC,           FUNC_CAP_CO_ID_GSM(CO_ID,'PLPR',NULL) TIPOPLAN,
FUNC_CAP_CO_ID_GSM(CO_ID,'CIC',3005) CIC,           A.STATUS ,A.REF_TEXT, A.USERID, A.INSERT_DATE, A.TS, A.*, A.ROWID
FROM SYSADM.MDSRRTAB A WHERE CO_ID IN (SELECT CO_ID  FROM CONTR_SERVICES WHERE DN_ID IN (
SELECT DN_ID  FROM DIRECTORY_NUMBER WHERE DN_NUM  IN ('65724504'))) ORDER BY REQUEST DESC;   

select * from  MPUSNTAB M WHERE UPPER(SHDES) LIKE '%S00%';   --Servicios

--------------------------- SERVICIOS DE UNA LINEA -----------------------------------------------------------
SELECT M.SNCODE,M.DES,C.SPCODE,S.DES,CS_SEQNO,CS_STAT_CHNG,
(SELECT DES FROM MPUTMTAB WHERE TMCODE = C.TMCODE AND STATUS = 'W') PLAN_TARIFARIO,C.*
FROM CONTR_SERVICES C, MPUSNTAB M, MPUSPTAB S WHERE M.SNCODE = C.SNCODE AND S.SPCODE = C.SPCODE
AND CO_ID = 1495160 ORDER BY C.CS_SEQNO    DESC, 2, C.SNCODE;

---------------------------------------CONTROL GPRS----------------------------------------------------------
select * from CAP_CONTROL_GPRS where msisdn= '65724504';

--------------------------- HISTORICO SERVICIOS DE UNA LINEA -------------------------------------------------
SELECT N.SNCODE, N.DES, I.SPCODE, S.DES, CS_SEQNO, CS_STAT_CHNG,
(SELECT DES FROM MPUTMTAB WHERE TMCODE = I.TMCODE AND STATUS = 'W') PLAN_TARIFARIO, I.*
FROM INH_DELETE_CONTR I, MPUSPTAB S, MPUSNTAB N
WHERE I.SPCODE = S.SPCODE AND I.SNCODE = N.SNCODE
AND CO_ID = '489589' ORDER BY I.CS_SEQNO DESC, 2, I.SNCODE;

-------------------------------CUSTCODE-----------------------------------------------------------------------
SELECT a.dn_num, b.co_id, b.cs_seqno, b.tmcode, b.cs_stat_chng, b.cs_deactiv_date, d.customer_id, d.custcode
  FROM directory_number a, contr_services b, contract_all c, customer_all d
WHERE a.dn_num = '66783655'
   AND b.dn_id = a.dn_id
   AND c.co_id = b.co_id
   AND d.customer_id = c.customer_id
  ORDER BY nvl(b.cs_deactiv_date,SYSDATE) DESC ;

----------------------------------------------ELEGIDOS------------------------------------------------------
SELECT A.*, ROWID  FROM MPUFFTAB A WHERE CO_ID = '3007125';
SELECT A.*, ROWID  FROM INH_ELEGIDOS_NEW.INH_ELEGIDOS A WHERE CO_ID = '3007125';
SELECT * FROM RED_INT WHERE CO_ID = '3007125 ' ORDER BY FECHA_CREACION DESC;

SELECT * FROM SYSADM.INH_ELEG5_LOG A WHERE A.CODMIN='98616663';  --LOG 5 MINUTOS
SELECT a.rowid, a.* FROM EX_DESACTIVSERVICIO a WHERE CO_ID = '85570649'; --DESACTIVACION SERVICIO

---------------------------------MICROCELDA------------------------------------------------------------------
select * from inh_tmsp_prep  where tmcode=419;

------------------------------------HISTORICO CONTROL HOTRATING----------------------------------------------
select * from CAP_MASIVOS_HISTORICO h where h.co_id='666363' order by h.feha desc;
select * from CAP_MASIVOS h where h.co_id='666363' order by h.fecha desc;

---------------------------------------CALIDAD PAQUETE GPRS--------------------------------------------------
select a.*,a.rowid from CAP_CONF_DATOS A WHERE SPCODE = 4881;
select a.*,a.rowid from CAP_CONF_DATOS A WHERE TMCODE = 10342;

--------------------------------------------------------------------------------------------------------------
select * from tickler_records where customer_id = 2700264;

------------------------------------CUSTOMER ID MAESTRA------------------------------------------------------
select * from customer_all c where c.custcode='8.10009623';

select * from sysadm.cashreceipts_all where customer_id = '1148391'
---------- CRUCE DE MINES ----------
SELECT TAREA_ID, PROCESO_STATUS, FECHA_INICIO, PROCESO_ERRORES, USUARIORED, DESC_CORTA, DESC_USUARIO
FROM sysadm.ex_batch_Tareas WHERE DESC_CORTA = 'Cruce Mines' 
and PARAMETROS_STRING1 like '%3125979357%' ORDER BY TAREA_ID desc; 


---------- VALIDAR ZONA ----------

SELECT a.dn_num, a.dn_status, a.dn_status_requ, a.hlcode 
FROM directory_number a 
WHERE a.dn_num IN ('3202893458','3107990789');


--------------------------------MINES DE UN NIT--------------------------------------------------------------
SELECT '&nit', A.CO_ID, C.DN_NUM, A.CUSTOMER_ID
  FROM SYSADM.CONTRACT_ALL     A,
       SYSADM.CONTR_SERVICES   B,
       SYSADM.DIRECTORY_NUMBER C,
       INH_TMSP_PREP           D
WHERE B.DN_ID = C.DN_ID
   AND B.CO_ID = A.CO_ID
   AND A.TMCODE = D.TMCODE
   AND PREPAGO NOT IN (0, 3)
   AND SUBSTR(B.CS_STAT_CHNG, -1) <> 'd'
   AND CUSTOMER_ID IN
       (SELECT CUSTOMER_ID
          FROM SYSADM.CUSTOMER_ALL
         WHERE CUSTOMER_ID_HIGH IN (SELECT CUSTOMER_ID
                                      FROM SYSADM.CUSTOMER_ALL
                                     WHERE PASSPORTNO = '&nit'
                                       AND CSLEVEL = 10)
        UNION ALL
        SELECT CUSTOMER_ID
          FROM SYSADM.CUSTOMER_ALL
         WHERE CUSTOMER_ID_HIGH IS NULL
           AND PASSPORTNO = '&nit'
           AND CSLEVEL = 40);


------------------------------------DETALLE DE FACTURACION--------------------------------------------------
select * --f.customer_id,remark,substr(TRIM(remark),-10),f.amount,f.entdate,f.valid_from, f.glcode /*+full f parallel (f ,4)*/ --, username,period,length(remark)
FROM sysadm.FEES f   ---DE DOS MESES
--from inh_purging.fees_archiving f   --MAS DE DOS MESES
where f.customer_id in (2241102)
AND f.valid_from>= to_date ('23032014 00:00:00','ddmmyyyy hh24:mi:ss')
AND f.valid_from<= to_date ('04052014 23:59:59','ddmmyyyy hh24:mi:ss');
--AND substr(TRIM(remark),-10)= '3133338463'
--AND length(remark)>69  --3146451332 
--AND remark like '%*#6%';

--------------- CONCILIACION ------------------- 
declare
vc varchar2(30000);
begin
sysadm.proc_concilia(4055692,vc); 
DBMS_OUTPUT.put_line(vc);
end;
