select * from cashreceipts_all c  
where c.customer_id = '218724333'      
order by c.caxact desc

------------------------ ver los pagos del cliente
