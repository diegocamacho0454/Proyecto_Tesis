-----------------------IMEI Actual--------------------
SELECT a.dn_num, b.co_id, b.tmcode,b.spcode, c.customer_id , d.imei
  FROM directory_number a, contr_services b, contract_all c, inh_imei d
WHERE a.dn_num in (

'3218599765'
)
   AND b.dn_id = a.dn_id
   AND c.co_id = b.co_id
   AND d.customer_id = c.customer_id
   AND b.cs_deactiv_date IS NULL;
