    select m.sncode,m.DES,m.sncode , c.spcode,c.tmcode ,  cs_seqno ,cs_stat_chng,
 (select des from  MPUTMTAB where tmcode = c.tmcode and status = 'W' ) Plan_Tarifario,C.* 
    from CONTR_SERVICES     C, MPUSNTAB M where m.sncode = c.sncode  
    and co_id = 220271056          
   order by c.cs_seqno DESC,2,c.sncode 
