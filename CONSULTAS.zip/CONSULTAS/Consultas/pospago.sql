---- CONSULTA VALIDA_ESTADO_ACTUAL_LINEA

SELECT a.dn_num, a.dn_status, 
(SELECT x.co_id 
FROM contr_services x 
WHERE x.dn_id = a.dn_id 
AND SUBSTR(x.cs_stat_chng, -1) <> 'd') CO_ID 
FROM directory_number a 
WHERE a.dn_num IN ( 
'3204938930'



)
ORDER BY a.dn_status; 
-------------------------------------------------------------------------------



---- CONSULTA HLR POR MIN ----
/*
DECLARE TYPE ARREGLO IS TABLE OF VARCHAR2(25);
arListado ARREGLO := ARREGLO(&MIN); 
NmHlr NUMBER; BEGIN FOR i IN arListado.first .. arListado.last LOOP 
select sysadm.pkg_mdscongif.fngethlr (arListado(i)) 
INTO NmHlr from dual; dbms_output.put_line(''||' '||arListado(i)||' '||NmHlr); END LOOP; END;
