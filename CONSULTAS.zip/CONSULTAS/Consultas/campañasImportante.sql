SELECT ca.customer_id, cs.co_id, dn.dn_num 
FROM CONTRACT_ALL ca, contr_services cs, directory_number dn 
WHERE ca.co_id = cs.co_id 
AND cs.dn_id = dn.dn_id 
AND substr(cs.cs_stat_chng, -1) <> 'd' 
AND dn.dn_num IN (

'3112414539'

)

;



select *
   from sysadm.perm_usuarios      p,  
        sysadm.perm_camp_usuarios c,  
        sysadm.perm_campana       a  
  where p.customer_id IN (
 
 

'225475989'




)  
    and p.id = c.id_usuario    
    and c.id_campana  = a.id    
   
;



----- promocion otorgada
select * from sysadm.perm_historico_beneficios a where a.id_usuario IN (        

'4542340'

);
