
select t.initial_source_addr ORIGEN, t.initial_destination_addr DESTINO, t.insert_time FECHA_RECEPCION_CLARO, t.last_update_time FECHA_ENVIO_AL_USUARIO,
DECODE(t.message_status||t.processing_status, '42', 'EXITOSO', 'NO EXITOSO') ESTADO, t.short_message MENSAJE
from pygnthis.HISTORY_SMS_ALL t where (t.initial_destination_addr in('1323166961700','573166961700', '3166961700')
or t.initial_source_addr in('1323166961700','573166961700', '3166961700'));
