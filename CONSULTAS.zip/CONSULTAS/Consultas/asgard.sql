/* Consultas para validar datos de financiaci�n para cr�ditos en Base de Datos BSCS */


---Financiaci�n en plataforma ASCARD


----bscs---- sacar datos de creditos

--- listas negras

En BSCS: select * from esn_robados where esn = '357366093137449';
--------------------------------------------------------------------------------
SELECT i.*,rowid FROM SYSADM.inh_act_ascard i where i.imei in ('357366093137449'); -- 
--------------------------------------------------------------------------------
SELECT i.*,rowid FROM SYSADM.inh_act_ascard i where i.msisdn in ('3232890049');
---------------------------------------------------------------------------------
SELECT i.*,rowid FROM SYSADM.inh_act_ascard i where i.custcode_ser in ('2.192400608');
-------------------------------------------------------------------------------------

---- ciclos --- bscs----
select * from inh_ciclos;

--Centro de costos--
select costcenter_id from customer_all where customer_id = 182479837;
---------------------------------------------------------------------
select * from costcenter where cost_id = '100014'; -- 100015 0150001
----------------------------------------------------------------------
select * from costcenter where cost_code ='0413001';


/*Crear financiaci�n en BSCS (CustCode de Equipo)*/


--Validar custcode y customer_id a partir del MIN
SELECT ca.customer_id, cs.co_id, dn.dn_num,cu.custcode
 FROM CONTRACT_ALL ca, contr_services cs, directory_number dn,customer_all cu
WHERE ca.co_id = cs.co_id
  AND cs.dn_id = dn.dn_id
  and cu.customer_id=ca.customer_id
 AND substr(cs.cs_stat_chng, -1) <> 'd'
  AND dn.dn_num in ('3232890049');

-- Verificar que el cliente no tenga creado CUSTCODE de equipo
SELECT i.custcode_equipo,i.customer_id_equipo,i.fecha_registro,i.ciclo,c.customer_id,c.customer_id_high,c.paymntresp 
FROM sysadm.inh_rel_equ_ser i, sysadm.customer_all c 
WHERE i.customer_id_servicio (+) = NVL2(c.paymntresp,c.customer_id,c.customer_id_high) 
and c.customer_id = 295869450;    

-- custcode de equipos a cuotas
select * from sysadm.inh_rel_equ_ser s where '96011501' in (s.customer_id_equipo, s.customer_id_servicio);                             

/* Validar los valores de los campos CUSTCODE_NUEVO, SEQ_EQ_USUARIO, NRO_TOTAL_CUOTAS de la tabla EXTRANET.ACTIVACION_EQUIPO 
de la base de datos ACTIVA con el CUSTOMER_ID */
SELECT A.CUSTCODE_NUEVO, A.SEQ_EQ_USUARIO, A.NRO_TOTAL_CUOTAS, a.rowid, A.* 
FROM activacion_equipo@activa A WHERE A.CUSTOMER_ID in ('96011501'); --customer de servicio

--Test para creaci�n OCC
SYSADM.PKG_VENTA_EQUIPOS_4444.PRC_ASOCIAR_EQUIPO

--Validar la Referencia del equipo � Creaci�n del custcode 
SELECT * FROM SYSADM.INH_REL_EQU_SER S WHERE S.CUSTOMER_ID_SERVICIO = '267855713';
 
--Validar el OCC creado con el periodo y valor de la cuota
SELECT * FROM SYSADM.FEES f WHERE F.CUSTOMER_ID = '273796181'; --customer equipo
