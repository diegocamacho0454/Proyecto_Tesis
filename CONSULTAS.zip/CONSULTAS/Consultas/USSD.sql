---Query USSD
SELECT t.*,
     case when( t.tipo_elegido = 'V' ) then 'Voz' 
          when( t.tipo_elegido = 'T' ) then 'Texto'
          else  t.tipo_elegido end as tipo_elegido,
            
     case when( t.tipo_plan = 'C' ) then 'Costa'
          when( t.tipo_plan = 'N' ) then 'Nacional'
          else  t.tipo_plan end as tipo_plan,
     
     case when( t.estado = 0 ) then 'Fallido'
          when( t.estado = 1 ) then 'Exitoso'
          else  t.estado  end as estado_transaccion,
           t.rta_ws,
     case
         when( t.rta_ws in ('2','3' )    )  then 'Exitoso'
         when( t.rta_ws in ('-2','37' )  )  then 'Plan no soportado por el servicio'
         when( t.rta_ws in ('-1','-32')  )  then 'Keyword Invalido'
         when( t.rta_ws in ('-35')       )  then 'Accion no habilitada para la marcaci�n'
         when( t.rta_ws = '-99' )           then 'Fallas en el servicio'
         when( t.rta_ws = '-12' )           then 'Fallas al intentar cobrar el SMS'
         when( t.rta_ws in ('-19','-25','-23','-19','-20' ) ) then 'Falla en Plataforma Prepago'
         when( t.rta_ws in ('-21','-44','-13'))               then 'Usuario ya presenta elegido inscrito' 
         when( t.rta_ws in ('-22'))          then 'Suscriptor sin servicio de elegido activo'
         when( t.rta_ws in ('17'))           then 'Modificacion No permitida'
         when( t.rta_ws in ('-41'))          then 'El usuario intenta listar los elegidos sin tener elegidos inscrito'
         when( t.rta_ws = '999' )            then 'Servicio de Elegido equivocado'
         when( t.rta_ws = '-15'   )          then 'No cumple con el saldo minimo requerido'
         else
           t.rta_ws
         end as estado_elegidos,
         
     t.desc_rta_ws as descripcion
     
FROM inh_smo.REGISTRO_ELEGIDOS_USSD t
WHERE t.min = '3207763121'
  and t.accion in ( 'INSCRIPCION' , 'I' )  -- Aqui la accion solicitada
  and t.estado in (0,1)
  order by t.fecha desc;
