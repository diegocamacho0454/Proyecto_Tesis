

SELECT * FROM sysadm.perm_historico_beneficios a WHERE a.id_usuario = 2604866;
--------------------------------------------------------------------------------

SELECT dnu.dn_num,
                cu.id_usuario, 
                cu.id_campana, 
                cu.fecha_inicio_prom, 
                u.ciclo,u.customer_id, 
                pp.descripcion, 
                aa.patron, 
                cu.estado,
                bb.aplica_customer 
FROM   sysadm.perm_camp_usuarios cu,
                sysadm.perm_usuarios u, 
                sysadm.perm_campana pp, 
                sysadm.PERM_PERIODICIDAD aa, 
                sysadm.PERM_CAMP_BENEFICIO cb,
                sysadm.PERM_BENEFICIO bb, 
                sysadm.contr_services se, 
                sysadm.directory_number dnu
WHERE  cu.id_usuario = u.id 
AND    u.customer_id in (218193110) 
AND    pp.id = cu.id_campana
AND    cb.id_campana = pp.id 
AND    cb.id_beneficio = bb.id 
AND    bb.perioricidad = aa.id 
AND    u.co_id = se.co_id 
AND    se.dn_id = dnu.dn_id;
