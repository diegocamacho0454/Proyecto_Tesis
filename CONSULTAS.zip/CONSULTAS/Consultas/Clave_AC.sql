SELECT CSPASSWORD 
FROM customer_all 
WHERE customer_id = (select customer_id 
                    from contract_all
                     where co_id = (select co_id 
                                    from contr_services 
                                    where cs_deactiv_date is null
                                    and   dn_id = (select dn_id
                                                   FROM directory_number 
                                                   WHERE dn_num = '3229718978')))


-- CODGIO MATERIAL CMAX
select *
from SYSADM.INH_INFOACTPREPAGO
where codmin = '3114769592';
