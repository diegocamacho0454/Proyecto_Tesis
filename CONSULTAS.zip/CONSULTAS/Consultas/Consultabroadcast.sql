SELECT t.noti_min, t.noti_fecha_origen,
t.noti_estado
FROM inh_broad.broadcast_activ_noti_final t
WHERE T.NOTI_MIN = '3105142419';
