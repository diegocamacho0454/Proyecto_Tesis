---Compra de paquete


SELECT * FROM inh_smo.TBL_PAQUETES_VOZDATOS_TRANS t
WHERE t.min = '&Min'
AND t.operacion = 'COMPRAR PAQUETE'
AND t.Trans_Exitosa = 1
--AND t.canal = 'USSD'
AND T.TIPO_PAQUETE = 'DATOS'
AND T.TIPO_TRANSACCION = 'FACTURA'
AND t.fecha>= to_date ('10122020 00:00:00','ddmmyyyy hh24:mi:ss')
AND t.fecha<= to_date ('14012021 23:59:59','ddmmyyyy hh24:mi:ss');
