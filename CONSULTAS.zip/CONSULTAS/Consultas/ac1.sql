
Select * from mpulktmb 
where tmcode in ('17349')
and sncode in ('9502')
and spcode in ('4103')        
order by 1 desc
