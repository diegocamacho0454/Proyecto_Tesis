--Estado linea

select a.co_id, func_cap_co_id_GSM(co_id,'MIN',NULL) MIN,   func_cap_co_id_GSM(co_id,'IMSI',NULL) IMSI, 
          func_cap_co_id_GSM(co_id,'HLR',NULL)  HLR,          func_cap_co_id_GSM(co_id,'SERV',3013) ACT, 
          func_cap_co_id_GSM(co_id,'RCAT',NULL) RC,           func_cap_co_id_GSM(co_id,'PLPR',NULL) TipoPlan,
          func_cap_co_id_GSM(co_id,'CIC',NULL) CIC,           a.status , func_cap_co_id_GSM(co_id,'MIN',NULL) MIN,a.ref_text ,a.userid, a.insert_date, a.ts, a.* 
          from sysadm.MDSRRTAB a where co_id in (select co_id  FROM contr_services where dn_id in (
          select dn_id from directory_number where dn_num  in ('3148723979'))) order by REQUEST desc;

--contr
Select cd_seqno , co_id , cd_port_num , cd_activ_date , cd_validfrom, cd_entdate , cd_deactiv_date , cd_moddate ,
decode(substr(cd_sm_num,8,1),0,'Oriente',1,'Occidente',2,'Costa') Zona,
''''||cd_sm_num||''''||',' , ''''||port_id||''''||','  , 
cd_status ,  cd_pending_state  
from contr_devices a
where co_id in (62154291)
order by CO_ID,cd_seqno asc;

--validarsim

Select sm_id, sm_serialnum , sm_status ,sm_entdate , sm_moddate 
from storage_medium sm
where sm_serialnum in ( 
'89571012005043995876',
'89571012009061526290',
'89571012008123819073',
'89571012011091080314',
'89571012013116212898',
'89571012013014634573',
'89571012014048239710',
'89571012014055573480'



);

