--BD BSCS

---Datos b�sicos de la l�nea

---- Transacciones de la l�nea

SELECT a.co_id,  sysadm.func_cap_co_id_GSM(co_id,'MIN',NULL) MIN,sysadm.func_cap_co_id_GSM(co_id,'IMSI',NULL) IMSI,
func_cap_co_id_GSM(co_id,'HLR',NULL)  HLR, sysadm.func_cap_co_id_GSM(co_id,'SERV',3013) ACT,func_cap_co_id_GSM(co_id,'RCAT',NULL) RC,           sysadm.func_cap_co_id_GSM(co_id,'PLPR',NULL) TipoPlan,
func_cap_co_id_GSM(co_id,'CIC',NULL) CIC,  a.status , sysadm.func_cap_co_id_GSM(co_id,'MIN',NULL) MIN, a.ref_text ,a.userid, a.insert_date, a.ts, a.*
FROM sysadm.MDSRRTAB a where co_id in 
(select co_id  FROM contr_services where dn_id in( select dn_id from directory_number where dn_num  in ('3127766609'))) 
ORDER BY REQUEST desc;

----- Validaci�n servicios (TMCODE)
select m.sncode,m.DES,m.sncode , c.spcode,c.tmcode ,  cs_seqno ,cs_stat_chng,
(select des from  MPUTMTAB where tmcode = c.tmcode and status = 'W' ) Plan_Tarifario,C.*
from CONTR_SERVICES     C, MPUSNTAB M where m.sncode = c.sncode
and co_id = 95372079  
order by c.cs_seqno DESC,2,c.sncode;

----- Consulta de Customer_Id

SELECT ca.customer_id, cs.co_id, dn.dn_num,cu.custcode
FROM CONTRACT_ALL ca, contr_services cs, directory_number dn,customer_all cu
WHERE ca.co_id = cs.co_id
AND cs.dn_id = dn.dn_id
and cu.customer_id=ca.customer_id
AND substr(cs.cs_stat_chng, -1) <> 'd'
AND dn.dn_num in ('3116515630');

----- N�MERO DE L�NEAS POR DOCUMENTO

SELECT CUSTOMER_ALL.paymntresp SPLITB, MAX(CCONTACT_ALL.CCSEQ) VER, DIRECTORY_NUMBER.DN_NUM MIN, CCONTACT_ALL.ccline2 NOMBRE, CUSTOMER_ALL.CUSTCODE CUSTCODE, contr_services.cs_stat_chng FECHAS_CAMBIOS, CUSTOMER_ALL.PASSPORTNO NIToCC, 
MAX(MPULKTMB.ACCESSFEE) CFM, mputmtab.des DES_PLAN, contract_all.CO_CRD_CLICKS_DAY MINUTOS, CUSTOMER_ALL.PREV_BALANCE CARGOS_MESE_ANTER,CUSTOMER_ALL.CUSTOMER_ID CUSTOMER_ID, CONTR_SERVICES.co_id CO_ID, contr_services.tmcode TMCODE, contr_services.spcode  PQTE, CCONTACT_ALL.ccline4 DIR,  CCONTACT_ALL.ccline5 ciudad, CUSTOMER_ALL.billcycle CICLO, CUSTOMER_ALL.CUSTOMER_ID_HIGH
FROM  DIRECTORY_NUMBER DIRECTORY_NUMBER, MPUTMTAB MPUTMTAB, CONTRACT_ALL CONTRACT_ALL, CONTR_SERVICES CONTR_SERVICES, CUSTOMER_ALL CUSTOMER_ALL, CCONTACT_ALL CCONTACT_ALL, MPULKTMB MPULKTMB
WHERE    DIRECTORY_NUMBER.DN_ID = CONTR_SERVICES.DN_ID AND CONTR_SERVICES.TMCODE = MPUTMTAB.TMCODE 
AND CONTR_SERVICES.CO_ID = CONTRACT_ALL.CO_ID AND CONTRACT_ALL.CUSTOMER_ID = CUSTOMER_ALL.CUSTOMER_ID
AND CONTRACT_ALL.CUSTOMER_ID = CCONTACT_ALL.CUSTOMER_ID
AND MPULKTMB.tmcode = CONTR_SERVICES.tmcode AND MPULKTMB.spcode = CONTR_SERVICES.spcode 
AND MPULKTMB.SNCODE = CONTR_SERVICES.SNCODE 
AND CCONTACT_ALL.CCBILL='X'
AND ((SUBSTR(contr_services.cs_stat_chng,-1) IN ('a')) OR (SUBSTR(contr_services.cs_stat_chng,-7) LIKE ('0503%d')) OR (SUBSTR(contr_services.cs_stat_chng,-7) LIKE ('0504%d')))
AND CUSTOMER_ALL.passportno in ('700361151')--Documento, ya sea CC, CE, NIT 860000596
--AND DIRECTORY_NUMBER.DN_NUM in('3125923195')
GROUP BY  CUSTOMER_ALL.paymntresp,CCONTACT_ALL.CCSEQ, DIRECTORY_NUMBER.DN_NUM, CCONTACT_ALL.ccline2, CUSTOMER_ALL.CUSTCODE, 
mputmtab.des, contr_services.cs_stat_chng, contract_all.CO_CRD_CLICKS_DAY, CUSTOMER_ALL.PREV_BALANCE, CUSTOMER_ALL.CUSTOMER_ID, 
CONTR_SERVICES.co_id, contr_services.tmcode, contr_services.spcode, CCONTACT_ALL.ccline4, CCONTACT_ALL.ccline5,CUSTOMER_ALL.billcycle,  
CUSTOMER_ALL.PASSPORTNO, CUSTOMER_ALL.CUSTOMER_ID_HIGH 
ORDER BY  DIRECTORY_NUMBER.DN_NUM, contr_services.cs_stat_chng  desc;

--Listas negras

select * from sysadm.ex_black_list e
where e.co_id = sysadm.getcoid(233953571)
and e.sncode = 3090
and e.estado = 1;


----- Historico por MIN 

SELECT dn.dn_num, 
       dn_status,
       sysadm.func_cap_co_id(cs.co_id, 'HLR', null) hlr,
       ca.customer_id, cu.custcode, cs.co_id, cs.cs_seqno,
       substr(cs.Cs_Stat_Chng, -1) estado, cs.tmcode,
       (SELECT x.cd_port_num
         FROM sysadm.contr_devices x 
        WHERE x.co_id = cs.co_id 
          AND x.cd_seqno = (SELECT MAX(y.cd_seqno) 
                              FROM sysadm.contr_devices y 
                             WHERE y.co_id = x.co_id)) imsi,
       (SELECT x.cd_sm_num
         FROM sysadm.contr_devices x 
        WHERE x.co_id = cs.co_id 
          AND x.cd_seqno = (SELECT MAX(y.cd_seqno) 
                              FROM sysadm.contr_devices y 
                             WHERE y.co_id = x.co_id)) iccid,
       (SELECT tm.des
           FROM mputmtab tm
          WHERE tm.tmcode = cs.tmcode
            AND tm.vscode = (SELECT MAX(x.vscode)
                               FROM mputmtab x
                              WHERE x.tmcode = tm.tmcode)) tmdes,
       sysadm.func_cap_co_id(cs.co_id, 'PLPR', NULL) TipoPlan,
       cu.billcycle,
       (SELECT x.billcycle_desc 
         FROM sysadm.billcycles x 
           WHERE x.billcycle = cu.billcycle) billcycle_desc,
      cc.ccfname, cc.cclname,
       ch.ch_reason causal_activ,
       (SELECT x.rs_desc FROM sysadm.reasonstatus_all x WHERE x.rs_id = ch.ch_reason) causal_activ_desc,
       ch.entdate fec_activ, ch.userlastmod usuario_activ,
       cd.ch_reason causal_desac,
       (SELECT x.rs_desc FROM sysadm.reasonstatus_all x WHERE x.rs_id = cd.ch_reason) causal_desac_desc,
       cd.entdate fec_desac, cd.userlastmod usuario_desac,
       (SELECT po.destino
           FROM sysadm.cap_ported_out po
          WHERE po.co_id = cs.co_id 
            AND po.fecha = (SELECT MAX(x.fecha) FROM cap_ported_out x WHERE x.co_id = po.co_id)
       ) destino
  FROM sysadm.directory_number dn, sysadm.contr_services cs,
       sysadm.contract_all ca, sysadm.customer_all cu,
       sysadm.contract_history ch, sysadm.contract_history cd, 
       sysadm.ccontact_all cc
WHERE dn.dn_num = '&MSISDN'
   AND cs.dn_id = dn.dn_id
   AND ca.co_id = cs.co_id
   AND cu.customer_id = ca.customer_id
   AND ch.co_id(+) = cs.co_id
   AND ch.ch_seqno(+) = 2
   AND cd.co_id(+) = cs.co_id
   AND cd.ch_status(+) = 'd'
   AND cc.customer_id (+) = cu.customer_id
   and cc.ccbill (+) = 'X'
ORDER BY NVL(cd.entdate, SYSDATE) DESC, cs.co_id, cs_seqno DESC ;

--DatosImportantesPorLinea:BSCS

SELECT dn.DN_ID, dn.DN_NUM, DN_Status, cs.co_id,cs.CS_ACTIV_DATE,ca.CUSTOMER_ID, cu.CUSTCODE,cu.PASSPORTNO
,cca.CCFNAME, cca.CCLNAME, cca.CCSTREET,cca.CCSTREETNO, cca.CCCITY, cca.CCJOBDESC, cca.CCEMAIL
,cs.TMCODE, (SELECT DES FROM MPUTMTAB WHERE TMCODE = cs.TMCODE AND ROWNUM = 1) AS MPUTMTAB_Plan
,cs.SPCODE, (SELECT DES FROM MPUSPTAB WHERE SPCODE = cs.SPCODE AND ROWNUM = 1) AS MPUSPTAB_Paquete
,cs.SNCODE, (SELECT DES FROM MPUSNTAB WHERE SNCODE = cs.SNCODE AND ROWNUM = 1) AS MPUSNTAB_Servicio
FROM directory_number dn
INNER JOIN contr_services cs    ON cs.dn_id = dn.dn_id
INNER JOIN contract_all ca      ON ca.co_id = cs.co_id
INNER JOIN customer_all cu      ON cu.customer_id = ca.customer_id
INNER JOIN ccontact_all cca     ON cca.customer_id = cu.customer_id AND cca.customer_id = ca.customer_id
WHERE
cu.PASSPORTNO IN ('700361151') -- Documento
--and DN_STATUS in ('d')
--dn.dn_num IN ('3232889072') -- Linea
ORDER BY cs.co_id DESC;

--- Pagos

select * from fees where customer_id = '111051796';


select* from inh_ciclos 



/*Validar si documento corresponde al MIN (si esta retorna un FALSE generara el mensaje de alert al usuario. 
En caso contrario debe validarse en la tabla Activa.Servicios, filtrando por el campo MINENTRA)*/

select (case
         when (SELECT nvl(1, 0)
                 From sysadm.CUSTOMER_ALL     CS,
                      sysadm.CONTRACT_ALL     CO,
                      sysadm.CONTR_SERVICES   CR,
                      sysadm.DIRECTORY_NUMBER DN
                Where CS.CUSTOMER_ID = CO.CUSTOMER_ID
                  AND CO.CO_ID = CR.CO_ID
                  AND CR.DN_ID = DN.DN_ID
                  AND CS.CUSTOMER_ID = CO.CUSTOMER_ID
                  AND (DN.DN_NUM = '3126892477') -- min
                  AND (CS.PASSPORTNO = '19705353') -- cc
                  AND SUBSTR(CR.CS_STAT_CHNG, -1) IN ('a', 's')
                  AND ROWNUM < 5) > 0 then
          'True'
         else
          'False'
       end) AS VALOR
  from dual;

