-----quete de SMS micro_recuerrente activo---
select *from inh_smo.paquetes_micro_rec where NPAMIN in ('3176473287');
-----paquete de SMS recurrente--- 
select * from inh_smo.paquetes_recurrentes where npamin in ('3112835086');
-----paquetes recurrentes de la linea
SELECT t.min, t.fecha_inscripcion,  t.idpaquete, t.fecha_activacion, t.fecha_vigencia,t.estado, t.canal, t.fecha_desactivacion 
FROM inh_smo.recu_act_paq_datos t WHERE t.min = '3112835086';

 SELECT t.consecutivo, t.mensaje, t.min, t.estado, t.observacion, t.id_paquete, t.fecha, t.canal, t.servicio
FROM INH_SMO.REGISTRO_DATOS_RECURRENTES T WHERE T.MIN = '3112835086'ORDER BY T.FECHA DESC;

SELECT * FROM INH_SMO.LOG_DES_PRC_SERVICIOS WHERE MIN ='3112835086';

--desactivacion de paquetes microrecurrentes--
inh_smo.pkg_gnt_servicedesk.desact_paq_microrec();
--desactivacion de paquetes recurrentes--
inh_smo.pkg_gnt_servicedesk.desact_paq_rec();
