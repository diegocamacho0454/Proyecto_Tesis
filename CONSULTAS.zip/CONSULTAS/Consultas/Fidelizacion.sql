-- 4. Reporte de bono o paquete a Hotrating  
 
EN BSCS sacamos el c�digo del paquete 
 
SELECT * FROM sysadm.inh_aprov_hotrating
WHERE CO_ID in(SELECT CO_ID
                    FROM CONTR_SERVICES A, DIRECTORY_NUMBER B
                    WHERE A.DN_ID = B.DN_ID  AND A.CS_DEACTIV_DATE IS NULL
                    AND B.DN_NUM IN ('&min'))
ORDER BY F_INICIO desc;
 
 
Se ejecuta el procedimiento:
-----procedimiento para desactivar paquete de voz----------
sysadm.pkg_bonos_y_paquetes.p_desactivar_paquete
 
