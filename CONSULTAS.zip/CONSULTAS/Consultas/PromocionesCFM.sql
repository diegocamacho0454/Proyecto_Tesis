SELECT ca.customer_id, cs.co_id, dn.dn_num 
FROM CONTRACT_ALL ca, contr_services cs, directory_number dn 
WHERE ca.co_id = cs.co_id 
AND cs.dn_id = dn.dn_id 
AND substr(cs.cs_stat_chng, -1) <> 'd' 
AND dn.dn_num IN (

'3128619379',
'3104257904',
'3106321434',
'3113497363',
'3113497370',
'3113497594',
'3113627623',
'3146181964',
'3147942021',
'3217779656',
'3234639472',
'3234640727',
'3234643207',
'3234643210'

)

;



select *
    from sysadm.perm_usuarios      p,  
         sysadm.perm_camp_usuarios c,  
         sysadm.perm_campana       a  
   where p.customer_id IN (
'230205200',
'230231310',
'230231275',
'230231225',
'230231250',
'236273936',
'230231237',
'230231264',
'230231184',
'230231348',
'230231327',
'230231360',
'230231338',
'230231286'

)  
     and p.id = c.id_usuario    
     and c.id_campana  = a.id    
     
;



----- promocion otorgada
select * from sysadm.perm_historico_beneficios a where a.id_usuario IN (        
 
'3973008',
'3973015',
'3973011',
'3973006',
'3973012',
'3973014',
'3973010',
'3973020',
'3973009',
'3973017',
'3973019',
'3973016',
'3973018',
'3973013'

)    




----------- descripci+on 

-------------------------------------------
select *
    from sysadm.perm_usuarios      p,  
         sysadm.perm_camp_usuarios c,  
         sysadm.perm_campana       a  
   where p.customer_id IN (

'230205200',
'230231310',
'230231275',
'230231225',
'230231250',
'236273936',
'230231237',
'230231264',
'230231184',
'230231348',
'230231327',
'230231360',
'230231338',
'230231286'


)  
     and p.id = c.id_usuario    
     and c.id_campana  = a.id    
     
;
