------ Lineas con ERROR *225#

SELECT FUNC_CAP_CO_ID_GSM (i.CO_ID,'MIN',303) MIN, i.co_id, i.text04,
i.text23,
i.text30 FROM info_contr_text i where i.co_id in (322473124);



-------------ESTADO 22-----------------------
        select a.co_id, func_cap_co_id_GSM(co_id,'MIN',NULL) MIN,   func_cap_co_id_GSM(co_id,'IMSI',NULL) IMSI, 
        func_cap_co_id_GSM(co_id,'HLR',NULL)  HLR,          func_cap_co_id_GSM(co_id,'SERV',3013) ACT, 
        func_cap_co_id_GSM(co_id,'RCAT',NULL) RC,           func_cap_co_id_GSM(co_id,'PLPR',NULL) TipoPlan,
        func_cap_co_id_GSM(co_id,'CIC',NULL) CIC,           a.status , func_cap_co_id_GSM(co_id,'MIN',NULL) MIN,a.ref_text ,a.userid, a.insert_date, a.ts, a.* 
        from sysadm.MDSRRTAB a where co_id in (select co_id  FROM contr_services where dn_id in (
        select dn_id from directory_number where dn_num  in ('3228700552'))) order by REQUEST desc;
