SELECT a.dn_num, b.co_id, b.cs_seqno, b.tmcode, b.cs_stat_chng, b.cs_deactiv_date, d.customer_id, d.custcode
  FROM directory_number a, contr_services b, contract_all c, customer_all d
WHERE a.dn_num = '3213771556'
   AND b.dn_id = a.dn_id
   AND c.co_id = b.co_id
   AND d.customer_id = c.customer_id
  ORDER BY nvl(b.cs_deactiv_date,SYSDATE) DESC ;
---------------------------------------------------------------------------------------------------------------------

SELECT *
          FROM CUSTOMER_ALL 
          WHERE CUSTCODE = '1.16127147' 
-------------------------------------------------------------------------------------------------------------------------

  select c.customer_id, c.ccbill, c.ccemail, b.PAYMNTRESP, a.CHECK01
    from SYSADM.CCONTACT_ALL c, SYSADM.CUSTOMER_ALL b, SYSADM.INFO_CUST_CHECK a
     where c.customer_id ='&customer_id'
     and b.customer_id = '&customer_id'
     and a.customer_id = '&customer_id'
