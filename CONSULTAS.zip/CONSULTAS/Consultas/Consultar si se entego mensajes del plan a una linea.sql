-- validar si se entrego mensajes del plan (se cambia el TMCODE)-----
select x.fuom un_gratis, x.*
from mpulkfum x where spcode = 4103 and sncode =3004 and x.fucode in
(select a.fucode from mpufutab a where a.shdes in
(select b.shdes from mputmtab b where b.tmcode = 22535)
);



-------- LDI

--------------------- llamadas LDI ------------------
SELECT *FROM RTX WHERE R_P_CUSTOMER_ID = '270732051'  AND O_P_NUMBER LIKE '%00444593989617568%' AND SNCODE = '3013';
