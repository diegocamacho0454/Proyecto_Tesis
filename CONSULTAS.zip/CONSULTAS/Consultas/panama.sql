
---- intentos sms eleg
select * from inh_smo.registro_elegidos_sms rr
where rr.origen in ('3214444922');
