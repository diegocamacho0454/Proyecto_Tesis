----------------Validacion Listas Negras BSCS-----------------

select * from esn_robados where esn like ('89571015019011819411%');
select * from esn_robados where esn in ('89571015019011819411');
/*
