-- Bloque Monitoreo tablas @activa
DECLARE
 
  ECODE NUMBER;
  EMESG VARCHAR2(200);
 
  CURSOR ACTIVACION IS
    SELECT RPAD(ESTADO, 7) AS ESTADO,
           RPAD(COUNT(*), 7) AS CANTIDAD,
           RPAD(A.RTAR, 7) AS RTAR
      FROM ACTIVACION@ACTIVA.WORLD A
     WHERE A.FECREGIS >= SYSDATE - 5
       AND (SUBSTR(A.ESTADO, 2, 1) = '0' OR SUBSTR(A.ESTADO, 2, 1) = '2')
     GROUP BY ROLLUP(ESTADO, RTAR);
 
  CURSOR ACTINCLUSION IS
    SELECT RPAD(ESTADO, 7) AS ESTADO,
           RPAD(COUNT(*), 7) AS CANTIDAD,
           RPAD(A.RTAR, 7) AS RTAR
      FROM ACTINCLUSION@ACTIVA.WORLD A
     WHERE A.FECREGIS >= SYSDATE - 5
       AND (SUBSTR(A.ESTADO, 2, 1) = '0' OR SUBSTR(A.ESTADO, 2, 1) = '2')
     GROUP BY ROLLUP(ESTADO, RTAR);
 
  CURSOR ACTIVACIONPRE IS
    SELECT RPAD(ESTADO, 7) AS ESTADO,
           RPAD(COUNT(*), 7) AS CANTIDAD,
           RPAD(A.RTAR, 7) AS RTAR
      FROM ACTIVACIONPRE@ACTIVA.WORLD A
     WHERE A.FECREGIS >= SYSDATE - 5
       AND (SUBSTR(A.ESTADO, 2, 1) = '0' OR SUBSTR(A.ESTADO, 2, 1) = '2')
     GROUP BY ROLLUP(ESTADO, RTAR);
 
BEGIN
  DBMS_OUTPUT.PUT_LINE('HORA DE EJECUCION: ' ||
                       TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI:SS') || '
');
 
  BEGIN
  
    DBMS_OUTPUT.PUT_LINE('                         MONITOREO PARA LA TABLA ACTINCLUSION            
    ');
  
    FOR I IN ACTINCLUSION LOOP
      IF I.ESTADO IS NULL AND I.CANTIDAD >= 500 THEN
        DBMS_OUTPUT.PUT_LINE('SE PRESENTA ENCOLAMIENTO CONTACTAR N3, LA CANTIDAD ES:  ' ||
                             TO_CHAR(I.CANTIDAD, '999,999,999,999') || '
');
      ELSIF I.ESTADO IS NOT NULL AND I.RTAR IS NOT NULL THEN
        DBMS_OUTPUT.PUT_LINE('EL ESTADO ES :  ' || I.ESTADO || '        ' ||
                             '  LA CANTIDAD ES:  ' ||
                             TO_CHAR(I.CANTIDAD, '999,999,999,999') ||
                             '                   EL RTAR ES: ' || I.RTAR);
      END IF;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE(' ');
  EXCEPTION
    WHEN OTHERS THEN
    
      ECODE := SQLCODE;
      EMESG := SQLERRM;
      DBMS_OUTPUT.PUT_LINE('ERROR:2' || '|' || '--' || TO_CHAR(ECODE) || '--' ||
                           EMESG);
    
  END;
 
  BEGIN
    DBMS_OUTPUT.PUT_LINE('                         MONITOREO PARA LA TABLA ACTIVACION            
  ');
    FOR I IN ACTIVACION LOOP
      IF I.ESTADO IS NULL AND I.CANTIDAD >= 500 THEN
        DBMS_OUTPUT.PUT_LINE('
' ||
                             'SE PRESENTA ENCOLAMIENTO CONTACTAR N3, LA CANTIDAD ES:  ' ||
                             TO_CHAR(I.CANTIDAD, '999,999,999,999') || '
');
      ELSIF I.ESTADO IS NOT NULL AND I.RTAR IS NOT NULL THEN
        DBMS_OUTPUT.PUT_LINE('EL ESTADO ES :  ' || I.ESTADO || '        ' ||
                             '  LA CANTIDAD ES:  ' ||
                             TO_CHAR(I.CANTIDAD, '999,999,999,999') ||
                             '                   EL RTAR ES: ' || I.RTAR);
      END IF;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE(' ');
  EXCEPTION
    WHEN OTHERS THEN
    
      ECODE := SQLCODE;
      EMESG := SQLERRM;
      DBMS_OUTPUT.PUT_LINE('ERROR:2' || '|' || '--' || TO_CHAR(ECODE) || '--' ||
                           EMESG);
    
  END;
 
  BEGIN
    DBMS_OUTPUT.PUT_LINE('                         MONITOREO PARA LA TABLA ACTIVACIONPRE            
  ');
    FOR I IN ACTIVACIONPRE LOOP
      IF I.ESTADO IS NULL AND I.CANTIDAD >= 500 THEN
        DBMS_OUTPUT.PUT_LINE('
SE PRESENTA ENCOLAMIENTO CONTACTAR N3, LA CANTIDAD ES:  ' ||
                             TO_CHAR(I.CANTIDAD, '999,999,999,999') || '
');
      ELSIF I.ESTADO IS NOT NULL AND I.RTAR IS NOT NULL THEN
        DBMS_OUTPUT.PUT_LINE('EL ESTADO ES :  ' || I.ESTADO || '        ' ||
                             '  LA CANTIDAD ES:  ' ||
                             TO_CHAR(I.CANTIDAD, '999,999,999,999') ||
                             '                  EL RTAR ES: ' || I.RTAR);
      END IF;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE(' 
');
  EXCEPTION
    WHEN OTHERS THEN
    
      ECODE := SQLCODE;
      EMESG := SQLERRM;
      DBMS_OUTPUT.PUT_LINE('ERROR:2' || '|' || '--' || TO_CHAR(ECODE) || '--' ||
                           EMESG);
    
  END;
 
  DBMS_OUTPUT.PUT_LINE('HORA DE FINALIZACION: ' ||
                       TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI:SS') || '
');
EXCEPTION
  WHEN OTHERS THEN
  
    ECODE := SQLCODE;
    EMESG := SQLERRM;
    DBMS_OUTPUT.PUT_LINE('ERROR:2' || '|' || '--' || TO_CHAR(ECODE) || '--' ||
                         EMESG);
  
END;
 
