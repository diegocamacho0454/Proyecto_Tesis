mo--Consultar el estado de la linea Actual.
SELECT a.*, rowid FROM ACTINCLUSION@ACTIVA A WHERE A.CODMIN IN ('3105388903','3118054131','3118056633','3208385123','3134918906');

SELECT a.Nombres as Nombre, a.CODMIN as MIN, a.Estado, a.fecregis, text3 as Coordinador, COLGAR_A_MAESTRA,DISTRIBUIDOR1  
FROM ACTINCLUSION@ACTIVA A WHERE A.CODMIN   IN ('3108315491','3122443682','3146498624') order by fecregis desc;


--------inclusiones/eclusiones masivas consulta 
SELECT a.Nombres as Nombre, a.CODMIN as MIN, a.Estado, a.fecregis, text3 as Coordinador, COLGAR_A_MAESTRA,DISTRIBUIDOR1  
FROM ACTINCLUSION@ACTIVA A WHERE A.CODMIN   IN ('3103615632',	
'3108770073',	
'3117243579',	
'3117243601',	
'3117244818',	
'3146514874',	
'3208598997'	



) order by fecregis desc;

SELECT a.Nombres as Nombre, a.CODMIN as MIN, a.Estado, a.fecregis, text3 as Coordinador, COLGAR_A_MAESTRA,DISTRIBUIDOR1  
FROM ACTINCLUSION@ACTIVA A WHERE A.CODMIN   IN ('3133931045') order by fecregis desc;







select cc.*, rowid  from ccontact_all cc where CUSTOMER_ID in ('154639605')

--Modificar campos--
SELECT ccfname, cclname, ccaddr1,  cccity, rowid  FROM ACTINCLUSION@ACTIVA A WHERE A.CODMIN IN (
'3105790344'
);


SELECT a.Nombres, a.CODMIN, a.Estado, rowid FROM ACTINCLUSION@ACTIVA A WHERE A.CODMIN IN ('3114884216'
);
--FECREGIS
--COLGAR_A_MAESTRA
---ESTADO - ACTIVADA

--Modificar datos faltantes -- llenar campos faltantes con 1
SELECT a.*,
rowid FROM CCONTACT_ALL a 
WHERE CUSTOMER_ID IN ('139488891')
order by CCSEQ;
--Modificar datos faltantes, esta bn
SELECT a.*, rowid FROM CCONTACT_ALL a WHERE CUSTOMER_ID IN (5812380);
SELECT customer_ID,ccseq,ccfname, cclname, ccaddr1, cccity, rowid FROM CCONTACT_ALL a WHERE CUSTOMER_ID IN (5812380);

--ejecutar en bscs  Para obtener iddistribuidor 
select * from ORIGINAL_DEALER where co_id in (SELECT CO_ID
                    FROM CONTR_SERVICES A, DIRECTORY_NUMBER B
                    WHERE A.DN_ID = B.DN_ID  AND A.CS_DEACTIV_DATE IS NULL
                    AND B.DN_NUM IN (3215883614));

 -------DEALER - CONSULTA -------------------------------------------------------
select * from ORIGINAL_DEALER where co_id in (179501419);

select a.codmin, a.codigo_distribuidor
from activacion@activa a
 where a.codmin ='3133665272';

