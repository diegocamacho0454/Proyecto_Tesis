------- VERIFICACION CODIGO APN -------------
select * from sysadm.inh_datos_apn a
where a.desc_apn like '%estatico.claro.com.co%';  

--- SE REALIZA VALIDACION DE LAS IP DUPLICADAS


select c.*, i.ip, i.status
from sysadm.INH_DATOS_APN_contrato c, sysadm.INH_DATOS_APN_ip i 
where c.codigo_apn = i.codigo_apn
and c.codigo_ip = i.codigo_ip
--and i.ip like '%166.210.65.150%'
and c.codigo_apn = 575
and c.msisdn in  (
'3105936366',
'3105933187',
'3105937538',
'3105934201',
'3133035358',
'3133035381',
'3133035385',
'3133035394'


)
;

 Validar disponibilidad


select * from sysadm.INH_DATOS_APN_ip d
where d.codigo_apn = 575
and d.status = 1 and d.codigo_ip in( 
'747054',
'747055',
'747056',
'747057'
)

;   



--- no debe arrojar informacion
select * from sysadm.INH_DATOS_APN_contrato c 
where c.codigo_ip in ('747054',
'747055',
'747056',
'747057'
)

;   


Reserva codigo ip
/*
update sysadm.INH_DATOS_APN_ip d
set d.status = 1
where d.codigo_apn = 575
and d.codigo_ip in ('747054',
'747055',
'747056',
'747057'
)

*/

Asignacion IP
update sysadm.INH_DATOS_APN_contrato a set a.codigo_ip = 618250
--set a.status = '1' 
where  a.codigo_apn = 
and a.codigo_ip = '265695'
and a.msisdn = 3107512653




