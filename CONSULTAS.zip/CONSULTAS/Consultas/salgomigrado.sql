

select * from extranet.activacion_upgrade_saldo b
where b.id_activacion ='86774025';
