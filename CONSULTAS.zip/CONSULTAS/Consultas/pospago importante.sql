--consulta detalle de factura
select a.otxact   cnsc_detalle,
      a.otglsale cuenta,
      g.gladesc  descripcion,
      a.otmerch  valor
 from ordertrailer a, glaccount_all g
where a.otglsale = g.glacode
  and otxact = 1542421590;
----------------------------------------------------
-------------CONSULTA DESCRIPCION DE FACTURA-----------------
-- consulta de customer_id 1p
SELECT ca.customer_id, cs.co_id, dn.dn_num,cu.custcode
  FROM CONTRACT_ALL ca, contr_services cs, directory_number dn,customer_all cu
WHERE ca.co_id = cs.co_id
   AND cs.dn_id = dn.dn_id
   and cu.customer_id=ca.customer_id
  AND substr(cs.cs_stat_chng, -1) <> 'd'
   AND dn.dn_num in ('3118888847');


---consulta de cobros - 
select  AMOUNT,  REMARK,  GLCODE,  TAXCODE,  ENTDATE,  PERIOD,  USERNAME,  VALID_FROM,SEQNO
from fees f
where f.customer_id = '272284023';


Sysadm.Pkg_Conteodelineas

---consulta de customer_id maestra

SELECT Customer_id --Customer_id_high, custcode, csactivated  
FROM customer_all cu WHERE custcode = '1.14395761';

---custcode de equipos a cuotas
select * from sysadm.inh_rel_equ_ser s where '81001849' in (s.customer_id_equipo, s.customer_id_servicio);

select * from sysadm.inh_rel_equ_ser s where s.customer_id_equipo in('81001849')
or s.customer_id_servicio in('1.14395761')

select * from activacion_equipo@activa where customer_id in (237914677) and fecha_inicial is null ;

select valor_facturado, valor_pago_inicial, (valor_facturado - valor_pago_inicial) As ValorAdiferir
             from activacion_equipo@activa
where imei = '352818091045301';


Select f.customer_id, f.amount, f.remark, f.period, f.descripcion from inh_fees_auditoria@BSCSREP_REPLI.WORLD f where f.sub_customer_id in (88396194) and f.glcode = 1305050025;

select * from sysadm.inh_rel_ascard_ser;

select CUSTOMER_ID ,OHXACT documento ,OHENTDATE fecha_creac ,OHINVAMT valor ,OHOPNAMT pendiente ,OHSTATUS tipo_fact ,OHTOTAL_TAXES ,OHDUEDATE fecha_corte from orderhdr_all o where o.customer_id in (88396194) order by o.ohentdate desc;


SELECT * FROM customer_all cu WHERE cu.customer_id = '81001849';

Select * from fees f where f.customer_id in (237914677) and glcode = 1305050025;

select c.customer_id, c.billcycle from SYSADM.Customer_all c where c.customer_id in (237914677);

select CUSTOMER_ID ,OHXACT documento ,OHENTDATE fecha_creac ,OHINVAMT valor ,OHOPNAMT pendiente ,OHSTATUS tipo_fact ,OHTOTAL_TAXES ,OHDUEDATE fecha_corte 
from orderhdr_all o where o.customer_id in (237914677) order by o.ohentdate desc;


---consulta consecutivo de factura
SELECT o.ohxact consecutivo, customer_id, o.ohentdate fecha,
       o.ohinvamt vlr_pagar, o.ohstatus estado
  FROM sysadm.orderhdr_all o
WHERE customer_id = '74792833'
ORDER BY o.ohentdate DESC;


--consulta detalle de factura
select a.otxact   cnsc_detalle,
       a.otglsale cuenta,
       g.gladesc  descripcion,
       a.otmerch  valor
  from ordertrailer a, glaccount_all g
 where a.otglsale = g.glacode
   and otxact = 1542421590;




-------------CONSULTA PDF CONTRA TXT--------------------------------

select * from customer_all a where a.custcode = '8.21997240';

  select customer_id,remark,substr(TRIM(remark),-10),amount,entdate,valid_from --, username,period,length(remark)
  FROM sysadm.FEES 
  where customer_id in (257139109)
  AND entdate>= to_date ('05022017 00:00:00','ddmmyyyy hh24:mi:ss') 
  AND entdate<= to_date ('04032017 23:59:59','ddmmyyyy hh24:mi:ss')
--AND substr(TRIM(remark),-10)= '3102643221'
---AND length(remark)>69  --3146451332 
AND remark like '%repo%'



select * from inh_purging.fees_archiving a 
where a.customer_id in (257139109)
AND entdate>= to_date ('01012013 00:00:00','ddmmyyyy hh24:mi:ss') 
AND entdate<= to_date ('11102013 23:59:59','ddmmyyyy hh24:mi:ss')


select * from SYSADM.CAP_PCRF_EVENTO e where e.msisdn in ('&min') order by e.fecha_registro desc;


--Servicios registrados para pago en Maestra de Subcuenta-------splitbilling 
Select * from  split_contratos where co_id = &contrato 

select * from split_contratos where co_id = '106085720';


select * from  MPUSNTAB M       WHERE  UPPER(SNCODE) LIKE '%3013%'; 

3013
3288
6020

--Consulta de referencia de pago por customer_id:

select sysadm.pkg_bscs_ac.REFERENCIA_PAGO(1141451347) from dual
1433636639
1445484367
select * from inh_historico_imei
where IMEI ='359291054532108'


select * from inh_imei
where IMEI ='359291054532108'

select * from customer_all
where passportno ='1110452252'
and prgcode <>5


-----aceleracion---
Select f.customer_id, f.amount, f.remark, f.period, f.descripcion 
from inh_fees_auditoria f 
where f.sub_customer_id in (1141451347) and f.glcode = 1305050025;




---forma de pago actual---
select * from sysadm.PAYMENT where customer_id = '257139109';
----historico de cambio de forma de pago----
select * from sysadm.BANK_ACCT_HIST where customer_id = '257139109';



select * from user_role_privs;
select * from all_all_tables;

---equipos a cuotas 

select * from sysadm.inh_equipo_financiado
where passportno = '7141202';


-----Promocion

select *
    from sysadm.perm_usuarios      p,  
         sysadm.perm_camp_usuarios c,  
         sysadm.perm_campana       a  
   where p.customer_id IN (

'38613826'
         
)  
     and p.id = c.id_usuario    
     and c.id_campana  = a.id    
     
;


Select * from bmh_request where action_cd in ('h')
and eff_date between
TO_DATE('01/01/2018 00:00:00','DD/MM/YYYY HH24:MI:SS')
AND TO_DATE('13/03/2018 23:59:00','DD/MM/YYYY HH24:MI:SS');


co_id in ('175067990')
