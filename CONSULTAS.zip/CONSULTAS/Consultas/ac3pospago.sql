select * from activacion_equipo@activa where customer_id in ( 
'232655324' 
);
