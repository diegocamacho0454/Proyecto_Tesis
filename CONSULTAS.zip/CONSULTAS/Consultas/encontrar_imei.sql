Pues en BSCS consulto a la tabla INH_IMEI: 


      select a.co_id, func_cap_co_id_GSM(co_id,'MIN',NULL) MIN,   func_cap_co_id_GSM(co_id,'IMSI',NULL) IMSI, 
        func_cap_co_id_GSM(co_id,'HLR',NULL)  HLR,          func_cap_co_id_GSM(co_id,'SERV',3013) ACT, 
        func_cap_co_id_GSM(co_id,'RCAT',NULL) RC,           func_cap_co_id_GSM(co_id,'PLPR',NULL) TipoPlan,
        func_cap_co_id_GSM(co_id,'CIC',NULL) CIC,           a.status , func_cap_co_id_GSM(co_id,'MIN',NULL) MIN,a.ref_text ,a.userid, a.insert_date, a.ts, a.* 
        from sysadm.MDSRRTAB a where co_id in (select co_id  FROM contr_services where dn_id in (
        select dn_id from directory_number where dn_num  in ('3202528828'))) order by REQUEST desc;
        


-- Obtener IMEI a trav�s del MIN
select *  from INH_IMEI i where i.customer_id in (SELECT customer_id FROM CONTRACT_ALL U where co_id in
(SELECT co_id  FROM contr_services s where S.DN_ID in (SELECT C.DN_ID FROM directory_number c
 where c.dn_num = '&min')  AND substr(cs_stat_chng, -1) <> 'd'));-- Obtener MIN asociado al IMEI
SELECT dn_num FROM directory_number  where DN_ID = (select DN_ID  FROM contr_services  where co_id =
(select co_id  FROM CONTRACT_ALL U  where customer_id in (select customer_id from INH_IMEI i
 where imei = ('&imei') ) )  AND substr(dn_id, -1) <> ' '  AND substr(cs_stat_chng, -1) <> 'd');-- Valida IMEI a trav�s del Customer_Id
 select * from INH_IMEI where customer_id = '162524549';
New
12:58
select* from INH_IMEI where imei in('869325032287311');
select * from esn_robados where esn = '869325032287311';
SELECT * FROM sysadm.inh_imei WHERE imei in ('869325032287311');
SELECT * FROM inh_historico_imei WHERE imei in ('869325032287311');
select equipment_id,customer_id,rec_version,imei from equipment where imei in('869325032287311');
