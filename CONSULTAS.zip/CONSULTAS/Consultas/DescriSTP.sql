select h.hlrcode, h.hlnom, h.alias_conm, h.global_title 
from inh_hlr h
order by 1 
;

----- NRN - 
select p.sncode NRN , p.indicador NRN_PM, p.descripcion DESTINO 
from inh_param_servicios p 
where p.tipo_proc = 15;
