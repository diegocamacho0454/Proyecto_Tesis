SELECT ca.customer_id, cs.co_id, dn.dn_num,cu.custcode  FROM CONTRACT_ALL ca, contr_services cs, directory_number dn,customer_all cu WHERE ca.co_id = cs.co_id   AND cs.dn_id = dn.dn_id and cu.customer_id=ca.customer_id  AND substr(cs.cs_stat_chng, -1) <> 'd'
AND dn.dn_num in ('3203211860');

SELECT TMCODE,M.SNCODE,M.DES,C.SPCODE,S.DES,CS_SEQNO,CS_STAT_CHNG FECHA, C.ROWID,
(SELECT DES FROM MPUTMTAB WHERE TMCODE = C.TMCODE AND STATUS = 'W') PLAN_TARIFARIO,C.*
FROM CONTR_SERVICES C, MPUSNTAB M, MPUSPTAB S WHERE M.SNCODE = C.SNCODE AND S.SPCODE = C.SPCODE
AND  CO_ID in ('123539121')ORDER BY C.CS_SEQNO    DESC, 2, C.SNCODE;

-------------------------------------------------------------------------
-- Elegidos ----

SELECT a.rowid, a.* FROM EX_DESACTIVSERVICIO a WHERE CO_ID IN (SELECT CO_ID  FROM CONTR_SERVICES WHERE DN_ID IN (
SELECT DN_ID FROM DIRECTORY_NUMBER WHERE DN_NUM  IN ('&MIN')));
SELECT A.*, ROWID  FROM MPUFFTAB A           WHERE CO_ID IN (SELECT CO_ID  FROM CONTR_SERVICES WHERE DN_ID IN (
SELECT DN_ID FROM DIRECTORY_NUMBER WHERE DN_NUM  IN ('&MIN')));
SELECT A.*, ROWID  FROM INH_ELEGIDOS_NEW.INH_ELEGIDOS A WHERE CO_ID IN (SELECT CO_ID  FROM CONTR_SERVICES WHERE DN_ID IN (
SELECT DN_ID FROM DIRECTORY_NUMBER WHERE DN_NUM  IN ('&MIN'))) ; 
SELECT *           FROM RED_INT                         WHERE CO_ID IN (SELECT CO_ID  FROM CONTR_SERVICES WHERE DN_ID IN (
SELECT DN_ID FROM DIRECTORY_NUMBER WHERE DN_NUM  IN ('&MIN')));

-------------------------------------------------------------------------
      --MICROCELDAS QUE SOPORTA UN PLAN
SELECT t.tmcode, t.spcode, t.prepago, t.tecnologia, t.microcelda
FROM INH_TMSP_PREP T WHERE TMCODE =  22365;



      --proceso almacenado
INH_ELEGIDOS_NEW.PKG_ELEGIDOS.Eliminar_Contrato

--SELECT *           FROM  sysadm.inh_eleg5_log  l        WHERE CO_ID IN (SELECT CO_ID  FROM CONTR_SERVICES WHERE DN_ID IN (
--SELECT DN_ID FROM DIRECTORY_NUMBER WHERE DN_NUM  IN ('&MIN')));


---elimnacion de microcelda
--DELETE from  MPUFFTAB A 
--where destination = 573114224504
--AND CO_ID =148488166
--AND SHDES = 'ELMG1'


SELECT * FROM CICLOP.CAMBIO_PLAN_SINFIN@PLATAFORMA_PREPAGO WHERE MIN in ('&MIN');


SELECT ca.customer_id, cs.co_id, dn.dn_num 
FROM CONTRACT_ALL ca, contr_services cs, directory_number dn 
WHERE ca.co_id = cs.co_id 
AND cs.dn_id = dn.dn_id 
AND substr(cs.cs_stat_chng, -1) <> 'd'  
AND dn.dn_num IN('3114853806')


----DATOS DEMOGRAFICOS-------

select * from ccontact_all c
where c.customer_id IN (264586345);
