/*\*Validacion de las lineas que estan ejecutandose*\
----select count(*) from activacion a
select a.fecregis,a.estado,a.codmin, a.* from activacion a
where a.Estado in ('100')
and a.fecregis between
TO_DATE('20/03/2020 00:00:00','DD/MM/YYYY HH24:MI:SS')
AND TO_DATE('20/03/2020 23:59:00','DD/MM/YYYY HH24:MI:SS')



Select count (*)
from activacion a --rowid,
--where estado in ('100')
where a.text1 in ('EUO3769B')---usuario
--and tipo_documento in ('NITCEDULA')
and a.fecregis between TO_DATE('20/03/2020 07:00:00','DD/MM/YYYY HH24:MI:SS')
AND TO_DATE('20/03/2020 16:59:00','DD/MM/YYYY HH24:MI:SS')
ORDER BY a.FECREGIS DESC;

Select count (*)
from activacion a --rowid,
where a.text1 in ('EUO3769B')---usuario
and estado in ('ACTIVADO')
--and tipo_documento in ('NITCEDULA')
and a.fecregis between TO_DATE('20/03/2020 07:00:00','DD/MM/YYYY HH24:MI:SS')
AND TO_DATE('20/03/2020 16:59:00','DD/MM/YYYY HH24:MI:SS')
ORDER BY a.FECREGIS DESC;

/*Verificar si las lineas estan activas*/

SELECT * FROM activacion ap;

Select ESTADO, TEXT1,codminext from activacion ap
where ap.codminext in (

)

