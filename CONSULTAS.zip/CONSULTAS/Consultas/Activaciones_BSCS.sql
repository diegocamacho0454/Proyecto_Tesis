select * from sysadm.storage_medium where SM_SERIALNUM like ('89571015021101640889%');
