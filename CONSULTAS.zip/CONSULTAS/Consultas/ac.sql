--Obtener spcode:
Select * from mpusptab
Where des like '%DATOS GPRS%';
