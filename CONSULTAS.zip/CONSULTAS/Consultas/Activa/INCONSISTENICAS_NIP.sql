--inconsistencias NIP--

select * from pn_solicitud_nip_mines 
where min in ('3148419130','3106607889','3104911049'); --, '3014959105','3214996889');

select * from pn_solicitud_nip_mines psnm
where psnm.id_solicitud in ('7023873');

--validar el estado de los NIP--
select ps.id_solicitud_nip,
       ps.id_estado, 
       ps.estado_abd,
       ps.fecha_creacion,
       ps.fecha_respuesta,
       psnm.min,
       ps.aplicacionorigen,
       ps.rowid
  from pn_solicitud_nip ps, pn_solicitud_nip_mines psnm
 where ps.id_solicitud_nip = psnm.id_solicitud
   and id_solicitud_nip in ('7024070','7027734','7023873')
 order by min, fecha_creacion asc;
 --for update;
 

select *from pn_estados;

select *from pn_tipo_estados;

select *from pn_estados_abd;


 select* 
 from pn_solicitud_nip
 where id_solicitud_nip in ('6931674')--;
for update;


select *
from pn_solicitud_nip_min_reenvio
where min in ('3208639579');
--for update;
--id_estado = 19
--cant_envio = 1
--estado_abd = null




