---- entidades financieras -- Para error en consulta reconocer -- OK

select * from credito where numero_documento = '17555132';
select * from reconocer_cliente where numero_documento = '17555132'; 
select * from extranet.log_entfin where passportno = '17555132';
select * from extranet.evidente where numero_documento = '17555132';

---------------------------------------------------------------------------------

---BUSCAR ESTADO CONSULTA EVIDENTE ----
select * from evidente
where numero_documento = '53773867'
order by fecha_consulta Desc;
 
--Consulta de credito
SELECT nombre, apellido, tipo_documento, numero_documento, fecha_consulta, producto 
FROM CREDITO C
where c.numero_documento = '53773867' order by fecha_consulta DESC;
 
select * from extranet.reconoce


