---- Validar campa�a activa --- campo aplica en 9 validar con el grupo prom el aprovisionamiento de la campa�a----- de no salir nada validar en poliexp con la primera consulta 
select c.*, c.rowid
from extranet.cpng_campanaxactivacion c
where c.idactivacion in (select a.id_activacion from ACTIVACION a where a.codmin in ('&codmin'));
