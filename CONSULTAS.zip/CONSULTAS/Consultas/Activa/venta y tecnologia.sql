----Se valida en la consulta en la base de datos POLIEXP: Donde nos  indica el estado de una reserva ejecutada 
----para realizar procedimiento de reposici�n por modulo Poliedro
----�  IDRESERVER: Identificador de la reserva o reposici�n.
--�  CONTRACTID: Contrato de la l�nea. 
---�  IDSTATE : Estado de la reserva, tenemos los siguientes:
----0: incompleta
----1: Vencida
----2 Finalizada
----3: Anulada
----4: Transaccional

---Numero de reserva
select t.idreserver, t.idstate, t.reservedate, t.executedate, t.maturitydate, t.quotanumber, t.equipmentnewname, t.*, t.rowid 
from tecnologia.reservation t 
where idreserver in ('T69486'); --23569133

---Cuenta 

select t.idreserver, t.idstate, t.reservedate, t.maturitydate, t.quotanumber, t.equipmentnewname, t.*, t.rowid 
from tecnologia.reservation t 
where t.customerid= '78414372'
or t.contractid = '78414372';

---Numero de Documento
select t.rowid, t.* from tecnologia.reservation t where documentnumber = 457585;

----Modificaci�n del estado de la reserva, se maneja igual que reposiciones para habilitar
select r.idreserver, r.idstate, r.reservedate, r.maturitydate, rowid from tecnologia.reservation r where idreserver in ('T130072');

----Si sale registro validamos con el campo IDRESERVER en la base de datos POLIEXP la consulta:
-------------�    El campo ERROR � Describe el error que ocurri� ejecutando el proceso.
-------------�    El campo IDERROR � Identificador del error causado al ejecutar un proceso.

---Log de la reserva
Select r.* from tecnologia.REPLACEMENTPROCESS r Where r.IDRESERVER in ('T130072'); --

---Informaci�n de los seralies ingresados
select r.statusreplacement, r.* from tecnologia.replacement r where r.idreserver in ('T17528');

----Cr�dito A donde se fue
select * from tecnologia.financed_replacement where idreserver in ('T17528');
