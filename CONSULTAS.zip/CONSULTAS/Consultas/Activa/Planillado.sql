-- consulta de planillado-----
  
select s.estado,s.planilla, s.fecregis, rowid, s.* from servicios s 
where s.minentra in ('3213242631')order by s.fecregis Desc;--, '3133344725') 
--where s.planilla in ('17031198') order by s.fecregis Desc;
 
--- Consulta planillado para Reposicion ----
select s.estado, s.planilla, s.fecregis, s.equipo, s.vr_equipo, s.iva_equipo, s.* from servicios s
where s.planilla = '17224893'
--where s.minentra in ('3114412941')--, '3217420643' '3207000467','3206054107',)--
and s.fecregis between
TO_DATE('11/05/2018 00:00:00','DD/MM/YYYY HH24:MI:SS')
AND TO_DATE('11/05/2018 23:59:59','DD/MM/YYYY HH24:MI:SS') --where s.coddistri in ('D2360.00004')*/
--and s.planilla not in '0'
ORDER BY s.fecregis DESC ;



--- Consulta planillado para Activaciones ----
select a.planilla,a.codigo_distribuidor,a.fecregis,a.fecbscs,a.fecplanilla,a.codmin,a.nombres,a.apellido,a.numero_documento,a.equipo,a.iva_equipo,a.total_venta,a.*
from activacion a 
--where a.codminext='3213242631' 
where a.planilla= '17224893'--'16812773'
--and a.codigo_distribuidor = 'D3623.00001'
--and ESN like ('8957101501811603196%')
--where a.codmin in ('3104107261')
and a.fecbscs >= to_date('11/05/2018 00:00:00','dd/mm/yyyy hh24:mi:ss') 
and a.fecbscs <= to_date('11/05/2018 23:59:59','dd/mm/yyyy hh24:mi:ss')--and a.planilla not in ('0')*/
order by a.fecplanilla asc;


----CONSULTAS PARA VALORES 0 EN TABLAS DE PLANILLADO. 
--============================Servicios===================================
select tpp.tipo_pago id_TpPago, tpp.nombre nombre_TpPago, total.valorpago valor
  from tp_pago tpp
left outer join (select tp.id_tp_pago, tp.nombre, sum(pa.valor_pago) as valorPago
                                    from tp_pago tp
                left join pagos pa on tp.tipo_pago = pa.tipo_pago
                join(SELECT s.id_pago
                        FROM SERVICIOS s
                     WHERE s.PLANILLA = 'C17210084'--V_NPLANILLA
                     group by id_pago) a on (pa.sec = a.id_pago)
                group by tp.id_tp_pago, tp.nombre) total on tpp.id_tp_pago = total.id_tp_pago
order by id_TpPago;

SELECT * FROM pagos where sec = 146202077   -- 140434840 138953405 138956032

SELECT * FROM Pagos where codmin in ('3112285134');

--============================Activaciones===================================
select tpp.tipo_pago id_TpPago, tpp.nombre nombre_TpPago, total.valorpago valor
  from tp_pago tpp
left outer join (select tp.id_tp_pago, tp.nombre, sum(pa.valor_pago) as valorPago
                   from tp_pago tp
                left join pagos pa on tp.tipo_pago = pa.tipo_pago
                join ( select id_pago
                          from activacion
                       where planilla = '17198695'--'C8981758'--V_NPLANILLA
                       group by id_pago) a on (pa.sec = a.id_pago)
                group by tp.id_tp_pago, tp.nombre) total on tpp.id_tp_pago = total.id_tp_pago
order by id_TpPago;

select * from pagos where sec in ('146202077');
