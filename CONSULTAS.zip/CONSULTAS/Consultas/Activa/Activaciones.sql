--Consulta activacion líneas
Select ap.nombres,ap.codigo_distribuidor,ap.codmin,ap.codminext,ap.estado,ap.fecregis,ap.fecbscs,ap.id_activacion,ap.esn,ap.imei,ap.* 
from activacion ap
where ap.codmin in ('3015594478');--(('3102466434'),('3187167719'),('3178944856'),('3164726078'),('3152961973'));
--where ESN like ('8957101501712888511%');
--where imei in ('357714082497798');
--
 --pospago
--where ESN in ('3204714623');

-------------------------------------------------------------------------------------------------




--------------------------------------------------------------------------------------------------
 
Select * from activacion_procesos a where a.id_activacion ='45620113';

----------------------------------------------------------------------------------------------------
-- Activacion lineas-- Errores en conteo de lineas 

SELECT act.id_activacion, act.fecregis, act.estado, act.* FROM activacion act
WHERE act. numero_documento ='45620113';

------------------------------------------------------------------------------------------------------

--Consulta lineas activadas den Prepago
--Select ap. estado from activacion ap
 
Select ap.nombres,ap.codigo_distribuidor,ap.codmin,ap.estado,ap.fecregis,ap.fecbscs,ap.id_activacion from activacion ap
where ap.codminext in ('3136221482');
 
------------------------------------------------------------------------------------------------------- 
--Consulta lineas de prepago
Select * from activacionpre ap
where ap.codmin in ('3136221482');
--where ap.ICCID like ('8957101501712888511%'); --('8957101501805220031');
--where AP.Iccid like ('895710150171288851%');--http://123mic/sm9/index.do?#
--where ap.imei in ('357714082497798');

--------------------------------------------------------------------------------------------------------8957101501811566283
 
SELECT * FROM PREPAGO_GSM PG WHERE PG.IMEI in ('357714082497798');

-------------------------------------------------------------------------------------------------------
 
SELECT PG.*, rowid FROM PREPAGO_GSM PG where imei in ('357714082497798');

---Consultas lineas activas en IVR
Select ic.co_id,ic.* from IVR_CDR IC
where dn_num in ('95400437');
--Where IC.dn_num in ('1070591399');
--where IC.iccid like ('89571015018089375322');
--where ic.sm_serialnum in ('5018089375322');

------------------------------------------------------------------------------------------------------------

--Consulta servicios (para cambios de ICCID, IMEI, Reposiciones)
select s.estado, s.planilla, s.fecregis, s.* from servicios s
Where s.minentra in ('3136221482')order by s.fecregis; 









