--ANULACI�N DE DIGITACI�N--

select id_activacion,codmin, a.esn, estado,fecregis,fecbscs, a.nombres, a.apellido,a.rowid, a.*
from activacion a
where codmin in (
'3182754894'
)and
estado not in ('ACTIVADO','ANULADO','ACTIVADOC','ACTIVADOR','ACTIVADOGPR');
--for update; --ANULADO



select id_activacion,codmin, estado,fecregis,fecbscs,rowid, a.*
from activacionpre a
where codmin in (
'3182754894'
) and
estado not in ('ACTIVADO','ANULADO');


--for update; --ANULADO
  
select id_actinclusion,codmin, a.producto, a.esn, estado,fecregis,fecbscs, a.nombres, a.apellido, rowid, a.*
from actinclusion a
where codmin in (
'3182754894'
)
and
estado not in ('ACTIVADO','ANULADO','INCLUIDO','ACTIVADOCA');


--for update --ANULADO

select id_activacion,codmin, a.esn, estado,fecregis,fecbscs, a.nombres, a.apellido, rowid, a.*
from activacion a
where codminext in (
'3182754894'
)
and estado not in ('ACTIVADO','ANULADO');







--for update �ANULADO

--ID_ACTIVACI�N--
select *
from pn_solicitudactivacion
where id_activacion in (
'3133861423',
'3142966941',
'3123120102',
'3108807666',
'3506314844',
'3174425857',
'3133861423'
);


select ps.fecha_portacion,ps.id_solicitud,ps.nombre,ps.id_estado,ps.estado_abd,ps.id_tipo_solicitud,ps.fecha_ventana_cambio,ps.id_proceso,
ps.fecha_solicitud,ps.fecha_respuesta
from pn_solicitud ps
where id_solicitud in 
('12474181',
'12498179',
'12427854',
'12447453',
'12474118');

--ESTADOS--
select *from pn_estados;

--TIPO DE ESTADOS--
select *from pn_tipo_estados;

--ESTADOS ABD--
select *from pn_estados_abd;

select *
from pn_solicitud ps
where id_solicitud in ('10918019');
