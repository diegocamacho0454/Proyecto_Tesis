--Port out abierta--
select * from pn_solicitud_mines 
where min in ('3182754894');

select * from pn_solicitud

select ps.id_solicitud, rowid, ps.nombre,ps.id_estado,ps.estado_abd,ps.id_tipo_solicitud,ps.fecha_ventana_cambio,ps.id_proceso,
ps.fecha_solicitud,ps.fecha_respuesta
from pn_solicitud ps
where id_solicitud in (18612548,18647420);--;
--for update;

select *from pn_estados;
select *from pn_tipo_estados;
select *from pn_estados_abd;


select *
from pn_solicitud ps
where id_solicitud in (12463747);


----Si encuentra registro se deja el campo id_estado en 5 en la tabla pn_solicitud y el estado_ABD Nulo ----
----------No tiene registro el campo id estado 69 en la tabla pn_solicitud y el estado_ABD Nulo. -----------
select * from pn_solicitud_documentos
where id_solicitud in ('12663454');
