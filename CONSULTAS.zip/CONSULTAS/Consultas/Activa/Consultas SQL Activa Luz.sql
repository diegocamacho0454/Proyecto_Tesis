--Consulta activacion l�neas
Select ap.nombres,ap.codigo_distribuidor,ap.codmin,ap.codminext,ap.estado,ap.fecregis,ap.fecbscs,ap.id_activacion,ap.esn,ap.imei,ap.* 
from activacion ap
--where ESN like ('8957101501712615363%');
--where imei in ('352017077291290');
where ap.codmin in ('3114946155'); --pospago
--where ESN in ('3204714623');



select a.fecregis, a.estado, a.producto, a.codmin, a.nombres, a.apellido, a.planilla, a.* 
from activacion a where a.codminext ='3136392733';
 
Select * from activacion_procesos a where a.id_activacion ='104083980';

-- Activacion lineas-- Errores en conteo de lineas 

SELECT act.id_activacion, act.fecregis, act.estado, act.* FROM activacion act
WHERE act. numero_documento ='1072421382';
 
 -- Centros de costo
 select * from tabcomapdistribuidores where coddistribuidor in ('MAY25.00115');
 
 select* from distribuidores where codigo in ('D2164.00007');
 
--Consulta lineas activadas den Prepago
--Select ap. estado from activacion ap
 
Select ap.nombres,ap.codigo_distribuidor,ap.codmin,ap.estado,ap.fecregis,ap.fecbscs,ap.id_activacion from activacion ap
where ap.codminext in ('3136392733');
 
--Consulta lineas de prepago
Select * from activacionpre ap
where ap.codmin in ('3136392733');
--where ap.ICCID in ('8957101501803461337'); --('8957101501805220031');
--where AP.Iccid like ('8957101501803461337%');
--where ap.imei in ('352623094000786')
 
SELECT * FROM PREPAGO_GSM PG WHERE PG.IMEI in ('357714080828317');
 
SELECT PG.*, rowid FROM PREPAGO_GSM PG where imei in ('357714080828317')

---Consultas lineas activas en IVR
Select ic.co_id,ic.* from IVR_CDR IC
--Where IC.dn_num in ('1070591399');
where IC.iccid like ('8957101501811603196%');
--where ic.sm_serialnum in ('4016072428132279569070');
 
 
 
---- entidades financieras -- Para error en consulta reconocer -- OK
select * from credito where numero_documento = '11413694';
select * from reconocer_cliente where numero_documento = '11413694'; 
select * from extranet.log_entfin where passportno = '11413694';
select * from extranet.evidente where numero_documento = '11413694';
 
 
--Solicitud de autoricacion cartera por radicado
select * from AUTCAR_SOLAUT a
where a.numsol='900999'
 
---BUSCAR DOCUMENTOS INVALIDOS ----
select * from docs_invalidos
where numero_documento like '%85475601%'

---Consultas empleadas para validar diferencia entre fecha SAP en poliedro y fecha Nao en AC

--SQL que valida si la fecha esta configureada en la tabla DIAS
SELECT to_char(MAX(fecha),'dd/mm/yyyy') AS FechaPrevHab
      FROM dias
WHERE fecha <= to_date('18/04/2017', 'dd/mm/yyyy') --Preferiblemente fecha del sd
AND tipdia = 1; --Tipo de d�a: 1 Laboral, 2 s�bado, 3 domingo, 4 Feriado

--SQL obtiene los 15 dias posterierores de forma descendente
SELECT ROWNUM AS DIAX, FECHA
      FROM DIAS 
WHERE Fecha > TO_DATE('18/04/2017', 'dd/mm/yyyy') --Preferiblemente fecha del sd
AND TIPDIA = 1 
AND ROWNUM <= 15 
ORDER BY DIAX DESC;


 
----Puntos Colpatria
select * from rep_clientes_bancos where documento ='%416885737%';
 
 
select * from doc_invalidos_1
where numero_documento like '%416885737%';
 
Select * from credito
where numero_documento in ('416885737')order by fecha_consulta Desc;
 
---BUSCAR ESTADO CONSULTA EVIDENTE ----
select * from evidente
where numero_documento = '1020793483'
order by fecha_consulta Desc;
 
--Consulta de credito
SELECT nombre, apellido, tipo_documento, numero_documento, fecha_consulta, producto 
FROM CREDITO C
where c.numero_documento = '11413694' order by fecha_consulta DESC;
 
select * from extranet.reconoce


 
----CONSULTAS PARA VALORES 0 EN TABLAS DE PLANILLADO. 
--============================Servicios===================================
select tpp.tipo_pago id_TpPago, tpp.nombre nombre_TpPago, total.valorpago valor
  from tp_pago tpp
left outer join (select tp.id_tp_pago, tp.nombre, sum(pa.valor_pago) as valorPago
                                    from tp_pago tp
                left join pagos pa on tp.tipo_pago = pa.tipo_pago
                join(SELECT s.id_pago
                        FROM SERVICIOS s
                     WHERE s.PLANILLA = 'C16442250'--V_NPLANILLA
                     group by id_pago) a on (pa.sec = a.id_pago)
                group by tp.id_tp_pago, tp.nombre) total on tpp.id_tp_pago = total.id_tp_pago
order by id_TpPago;

SELECT * FROM pagos where sec = 137191725   -- 140434840 138953405 138956032

SELECT * FROM Pagos where codmin in ('3114791724');

--============================Activaciones===================================
select tpp.tipo_pago id_TpPago, tpp.nombre nombre_TpPago, total.valorpago valor
  from tp_pago tpp
left outer join (select tp.id_tp_pago, tp.nombre, sum(pa.valor_pago) as valorPago
                   from tp_pago tp
                left join pagos pa on tp.tipo_pago = pa.tipo_pago
                join ( select id_pago
                          from activacion
                       where planilla = '16812736'--'C8981758'--V_NPLANILLA
                       group by id_pago) a on (pa.sec = a.id_pago)
                group by tp.id_tp_pago, tp.nombre) total on tpp.id_tp_pago = total.id_tp_pago
order by id_TpPago;

select * from pagos where sec in ('146202077');

---PERMISOS USURIOS POLIEDRO ----
Select * from usuario U
where u.codusuario like ('%ICF1080B%'); --ecm3682f
 
--Consulta distribuidores
Select * from distribuidores d 
where d.codigo = ('CAC11.00007')
 
 
--Consulta servicios (para cambios de ICCID, IMEI, Reposiciones)
select s.estado, s.planilla, s.fecregis, s.* from servicios s
Where s.minentra in ('3136392733')order by s.fecregis  
 
--Consultar su el distribuidor tiene permisos para Generar volante
Select * from extranet.dist_recaudo
where CODDISTRIBUIDOR = 'D1135.00001'
 
-- Upgrade no traslada recargaeste lo tenemos mas actualizado con correo de andrea
---•  Verificar en la Base de Datos de ACTIVA en la tabla ACTIVACION el campo ID_ACTIVACION
select a.codmin,a.estado,a.id_activacion
from activacion a
where a.codmin ='3113037738'
-- •  De aquí tomamos el ID_ACTIVACION y verificamos en la tabla ACTIVACION_UPGRADE_SALDO, en esta tabla consultamos el saldo que reporto la plataforma prepago en su momento.
select * from extranet.activacion_upgrade_saldo b
where b.id_activacion ='5681885'
o  Si el saldo no es el indicado en la reclamación, se le debe escalar  a la gerencia Prepago, ya que poliedro toma lo retornado por ellos,
o  Si el saldo es el correcto se debe escalar a la gerencia de Postpago, ya que ellos deben tomar la información que nosotros tenemos en esta tabla.
 
--Reportes nota debito
SELECT D.* FROM REPOSICIONES_REPORTES D
WHERE D.ID_CUENTA_COBRO = 5786
 
---*****************Portabilidad
Select Id_activacion, ID_solicitud, Msisdn, Producto, tipo_producto, activa_tercero from pn_solicitudactivacion
where msisdn in '3173923938'
 
Select min, estado_min, id_solicitud, id_tramite from pn_solicitud_mines
where min in '3004053727'
 
Select * from pn_solicitud
where id_solicitud in '12119579';
--Where numero_doc in '9002654298'
Select * from pn_tipo_estados;
Select * from pn_estados;
Select * from pn_estados_abd
 
--Validacion de elegidos de migración en activa que son reportados a pospago o no
select a.codmin,a.estado,a.id_activacion
from activacion a
where a.codmin ='3134921040'
 
--si se encuentran los elegidos en la tabla se escala a pospago si no se enucentran se escalan a prepago
select * from elegidos_plan 
where id_activacion in ('101927672')
 
 
-- consulta de planillado-----
  
select s.estado,s.planilla, s.fecregis, rowid, s.* from servicios s 
where s.minentra in ('3108675553')order by s.fecregis Desc;--, '3133344725') 
--where s.planilla in ('17031198') order by s.fecregis Desc;
 
--- Consulta planillado para Reposicion ----
select s.estado, s.planilla, s.fecregis, s.equipo, s.vr_equipo, s.iva_equipo, s.* from servicios s
--where s.planilla = 'C16442250'
where s.minentra in ('3114412941')--, '3217420643' '3207000467','3206054107',)--
and s.fecregis between
TO_DATE('20/03/2018 00:00:00','DD/MM/YYYY HH24:MI:SS')
AND TO_DATE('25/03/2018 23:59:59','DD/MM/YYYY HH24:MI:SS') --where s.coddistri in ('D2360.00004')*/
--and s.planilla not in '0'
ORDER BY s.fecregis DESC ;



--- Consulta planillado para Activaciones ----
select a.planilla,a.codigo_distribuidor,a.fecregis,a.fecbscs,a.fecplanilla,a.codmin,a.nombres,a.apellido,a.numero_documento,a.equipo,a.iva_equipo,a.total_venta,a.*
from activacion a 
where a.codminext='3108675553' 
--where a.planilla= '16665340'--'16812773'
--where a.codigo_distribuidor = 'CAC23.00012'
--where a.codmin in ('3104107261')
/*and a.fecbscs >= to_date('17/11/2017 00:00:00','dd/mm/yyyy hh24:mi:ss') 
and a.fecbscs <= to_date('30/11/2017 23:59:59','dd/mm/yyyy hh24:mi:ss')--and a.planilla not in ('0')*/
order by a.fecplanilla asc;
 
----------consulta de modificacion de datos..-------
 
Select * from extranet.tab_soluciones
--where registro in '';
where distribuidor in 'D1491.00001';
 
 
--//////////////////////////////////////////////////////////////////////////////////////////////////////////
--consulta poliedro bloqueo internet - IND1394729
---Validación estado servicios en poliedro para reposiciones
SELECT *--count(1) --INTO nmExistServ
                FROM contr_services a
               WHERE co_id = '44409131' AND
                (substr(a.cs_stat_chng, -1) != 'd' OR
                substr(a.cs_pending_state, -1)!= 'd') AND
                sncode = 6731;
 
Validar los Servicios con SNCODE= 6731 -6732
 
 
 
 
 
 
---error hallando ICCID - IND1395698
--Buen día PTI
 
---Verificar el estado el ICCID --- Pendiente por privilegios
Select 
sm_serialnum , sm_status , sm_entdate , sm_moddate 
from storage_medium 
where sm_serialnum in ('351871089645724');
 
--- Para consultar el ICCID                             _______________________________
 
Select cd_seqno ,co_id , cd_activ_date , cd_validfrom , cd_entdate , cd_deactiv_date , cd_moddate , 
decode(substr(cd_sm_num,8,1),0,'Oriente',1,'Occidente',2,'Costa') Zona, 
''''||cd_sm_num||''''||',' , ''''||port_id||''''||',' , 
cd_status , cd_pending_state 
from contr_devices a 
where co_id in (251739544) 
 
order by CO_ID,cd_seqno asc 
 
 
-------------------consulta del de creacion de un codigo de distibuidor--------
select * from EXTRANET.DIST_RECAUDO DD
WHERE dd.coddistribuidor in ('D3162.00002')
 
---------------------------------------------------------
/* Consulta datos solicitud Autorización cartera */
 
select * from AUTCAR_SOLAUT a
where a.numsol='900999'
 
/* Registro documentos adjuntos a solicitud Autorización cartera */
 
SELECT * FROM AUTCAR_DOCADJSOL
WHERE NUMSOL='900999'
 
 
Select * from tbl_beneficio where IDRESERVER= '8046439';  
 
; 
 
--REINSTALACIÓN
 
--En la tabla de activaciones se valia si la reinstalacion se tramito o no y en que estado se encuentra.
 
--Con este script se consulta la tabla de activaciones 
 
select a.fecregis, a.estado, a.producto, a.codmin, a.nombres, a.apellido, a.planilla, a.* from activacion a where a.codmin ='3212729427'
 
 
-- ESTADO 20----
 
select a.fecregis, a.estado, a.producto, a.codmin, a.nombres, a.apellido, a.planilla, a.* from activacion a where a.codmin ='3208473438';
select a.fecregis, a.estado, a.producto, a.codmin, a.nombres, a.apellido, a.planilla, a.* from activacion a where a.estado ='20';
 
Select * from activacion_log where id_activacion = '101927672'
 
select * from TBL_CONFIG_PASS
 
select * from activacion_log a where a.codmin = '3006770005';
