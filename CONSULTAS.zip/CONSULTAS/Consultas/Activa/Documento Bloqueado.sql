------ Evidente 

select e.numero_documento,e.fecha_consulta,e.usuario,e.codigo_distribuidor,e.respuesta
from evidente e
where e.numero_documento = '17555132'
order by e.fecha_consulta desc;



--- DOCUMENTO NO APLICA PARA ACTIVACI�N

select di.fecha_bloqueo,di.estado,di.numero_documento,di.cod_causal,ci.nom_causal,di.usuario_poliedro
from doc_invalidos_1 di,causal_invalidos ci
where di.cod_causal = ci.cod_causal and
di.numero_documento = '17555132' and
di.estado in ('BLOQ ACTIVACIONES','BLOQ COMPLETO') and
di.activo = 'V';


-- Documento no v�lido

select * from doc_invalidos_1
where numero_documento like '%17555132%';
