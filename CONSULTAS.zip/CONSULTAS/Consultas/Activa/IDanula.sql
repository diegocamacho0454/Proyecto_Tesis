--------------- Tabla para ingresar Id anular ------- 1�
select text1, text2, text3
from cambio_operador
--where text2 is null
--for update;
  
------ Validar resultados -----
select text1 as id_solicitud, text2 as resultado, text3 as digitaciones_anuladas
from cambio_operador;


----- Eliminar tablas procesadas ----- 2�
delete from cambio_operador;
select text1 as id_solicitud, text2 as resultado, text3 as digitaciones_anuladas from cambio_operador;



---------------- Proceso de anulaci�n ----------------- 3�
Declare
  v_id_solicitud  number(10);
  v_id_activacion number(20);
  v_producto      varchar2(4000);
  v_id_estado     number(2);
  v_estado_abd    number(2);
  v_anulado       number(1);
  v_respuesta     varchar2(4000);
  v_respuesta2    varchar2(4000);
  cursor vcursor is
    select ps.id_solicitud, ps.id_estado, ps.estado_abd
      from pn_solicitud ps
     where ps.id_solicitud in (select text1 from cambio_operador where text2 is null)
     order by ps.id_solicitud;
  cursor vcursor2(solicitud number) is
    select id_activacion, tipo_producto
      from pn_solicitudactivacion
     where id_solicitud = solicitud;

begin

  v_anulado := 9;

  open vcursor;
  loop
    fetch vcursor
      into v_id_solicitud, v_id_estado, v_estado_abd;
    exit when vcursor%notfound;
  
    v_respuesta  := null;
    v_respuesta2 := null;
  
    if v_id_estado = 9 then
      v_respuesta := 'Solicitud previamente anulada';
    elsif v_estado_abd is null then
      update pn_solicitud ps
         set ps.id_estado = 9
       where ps.id_solicitud = v_id_solicitud;
      commit;
    
      open vcursor2(v_id_solicitud);
      loop
        fetch vcursor2
          into v_id_activacion, v_producto;
        exit when vcursor2%notfound;
      
        v_respuesta2 := v_respuesta2 || ' ' || v_id_activacion;
      
        if v_producto = 'PREPAGO' then
        
          update activacionpre
             set estado = 'ANULADO'
           where id_activacion = v_id_activacion
             and estado not in ('ANULADO', 'ACTIVADO');
          commit;
        
        elsif v_producto = 'POSTPAGO' then
        
          update activacion
             set estado = 'ANULADO'
           where id_activacion = v_id_activacion
             and estado not in ('ANULADO', 'ACTIVADO');
          commit;
        
        end if;
      
      end loop;
    
      close vcursor2;
    
      v_respuesta := 'Solicitud anulada correctamente';
    elsif v_estado_abd is not null then
      v_respuesta := 'Solicitud ya se envi� al ABD';
    end if;
  
    update cambio_operador
       set text2 = v_respuesta, text3 = substr(v_respuesta2, 1, 255)
     where text1 = v_id_solicitud;
    commit;
  end loop;
  close vcursor;

end;
