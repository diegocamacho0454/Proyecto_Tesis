-----Creaci�n de equipo a credito en Ascard - Activaciones --------------------------------------------
Select ap.fecregis, ap.estado, ap.fecbscs, ap.id_activacion, ap.esn, ap.equipo, ap.iva_equipo, ap.total_venta, ap.* from activacion ap---@activa.world ap
where ap.codmin in ('3208439571'); 

----Grupo afinidad 1 se crea en Ascard x proceso de activaci�n ----------------------------------------
select * from activacion_procesos
where id_activacion in ('95400437');

--------------------------------------------------------

select valor_facturado, valor_pago_inicial, (valor_facturado - valor_pago_inicial) As ValorAdiferir
             from activacion_equipo
where imei = '352005090536288';

--------------------------------------------------------

select * from Usuario
where codusuario='ICO5974A';
--where coddistri like ('CVC12.0119%');
