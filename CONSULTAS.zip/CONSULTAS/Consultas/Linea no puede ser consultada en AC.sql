select * from contract_history  c   
where c.co_id in ('257869183')        
order by c.co_id, c.ch_seqno desc 


update contract_history h
set h.ch_reason = 32
where h.co_id = '257869183'
and h.request = 2749625481
and ch_reason is null
