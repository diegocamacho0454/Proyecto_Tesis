(SELECT x.cd_port_num
        FROM sysadm.contr_devices x 
       WHERE x.co_id = cs.co_id 
         AND x.cd_seqno = (SELECT MAX(y.cd_seqno) 
                             FROM sysadm.contr_devices y 
                            WHERE y.co_id = x.co_id))imsi,
      (SELECT x.cd_sm_num
        FROM sysadm.contr_devices x 
       WHERE x.co_id = cs.co_id 
         AND x.cd_seqno = (SELECT MAX(y.cd_seqno) 
                             FROM sysadm.contr_devices y 
                            WHERE y.co_id = x.co_id)) iccid,
      (SELECT tm.des
          FROM mputmtab tm
         WHERE tm.tmcode = cs.tmcode
           AND tm.vscode = (SELECT MAX(x.vscode)
                              FROM mputmtab x
                             WHERE x.tmcode = tm.tmcode)) tmdes,
      sysadm.func_cap_co_id(cs.co_id, 'PLPR', NULL) TipoPlan,
      cu.billcycle,
      (SELECT x.billcycle_desc 
        FROM sysadm.billcycles x 
          WHERE x.billcycle = cu.billcycle) billcycle_desc,
     cc.ccfname, cc.cclname,
      ch.ch_reason causal_activ,
      (SELECT x.rs_desc FROM sysadm.reasonstatus_all x WHERE x.rs_id = ch.ch_reason) causal_activ_desc,
      ch.entdate fec_activ, ch.userlastmod usuario_activ,
      cd.ch_reason causal_desac,
      (SELECT x.rs_desc FROM sysadm.reasonstatus_all x WHERE x.rs_id = cd.ch_reason) causal_desac_desc,
      cd.entdate fec_desac, cd.userlastmod usuario_desac,
      (SELECT po.destino
          FROM sysadm.cap_ported_out po
         WHERE po.co_id = cs.co_id 
           AND po.fecha = (SELECT MAX(x.fecha) FROM cap_ported_out x WHERE x.co_id = po.co_id)
      ) destino
 FROM sysadm.directory_number dn, sysadm.contr_services cs,
      sysadm.contract_all ca, sysadm.customer_all cu,
      sysadm.contract_history ch, sysadm.contract_history cd, 
      sysadm.ccontact_all cc
WHERE dn.dn_num = '&MSISDN'
  AND cs.dn_id = dn.dn_id
  AND ca.co_id = cs.co_id
  AND cu.customer_id = ca.customer_id
  AND ch.co_id(+) = cs.co_id
  AND ch.ch_seqno(+) = 2
  AND cd.co_id(+) = cs.co_id
  AND cd.ch_status(+) = 'd'
  AND cc.customer_id (+) = cu.customer_id
  and cc.ccbill (+) = 'X'
ORDER BY NVL(cd.entdate, SYSDATE) DESC, cs.co_id, cs_seqno DESC ;
