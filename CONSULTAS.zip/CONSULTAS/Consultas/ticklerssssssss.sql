jajajajajaja
-- consulta de customer_id 1p
SELECT ca.customer_id, cs.co_id, dn.dn_num,cu.custcode
 FROM CONTRACT_ALL ca, contr_services cs, directory_number dn,customer_all cu
WHERE ca.co_id = cs.co_id
  AND cs.dn_id = dn.dn_id
  and cu.customer_id=ca.customer_id
 AND substr(cs.cs_stat_chng, -1) <> 'd'
  AND dn.dn_num in ('3222800496');

---verificar casos con cierre de ticklers
SELECT A.*, ROWID  FROM TICKLER_RECORDS A               
WHERE CUSTOMER_ID = '178106466' 
--AND A.TICKLER_CODE NOT IN 'COMENTS'
ORDER BY TICKLER_NUMBER DESC;



-- consulta de customer_id 1p
SELECT ca.customer_id, cs.co_id, dn.dn_num,cu.custcode
 FROM CONTRACT_ALL ca, contr_services cs, directory_number dn,customer_all cu
WHERE ca.co_id = cs.co_id
  AND cs.dn_id = dn.dn_id
  and cu.customer_id=ca.customer_id
 AND substr(cs.cs_stat_chng, -1) <> 'd'
  AND dn.dn_num in ('3138805630');---verificar casos con cierre de ticklers
SELECT A.*, ROWID  FROM TICKLER_RECORDS A
--WHERE CUSTOMER_ID = '321257314'
WHERE CO_ID ='282163783'
--AND A.TICKLER_CODE NOT IN 'COMENTS'
ORDER BY TICKLER_NUMBER DESC;-- validaselect *from curr_co_device c
where c.co_id = '25911686';
