sysadm.PKG_PERSONALIZA_SOLUCION_USR.PRC_CONSULTA_OFERTA

sysadm.PKG_PERSONALIZA_SOLUCION_USR.PRC_CONSULTA_MOV


----------Mirar si el plan soporta Un servicio----16137---
select lk.tmcode,
  (select des from mputmtab tm where tm.tmcode = lk.tmcode and tm.status = 'W') PLAN,lk.vscode, lk.vsdate, lk.status, lk.spcode,
  (select des from mpusptab sp where sp.spcode = lk.spcode) Paquete ,lk.sncode,
  (select des from mpusntab sn where sn.sncode = lk.sncode) Servicio,lk.accessfee
  from mpulktmb lk
  where lk.tmcode in (25668)
 and   sncode in (13070,
13071,
13072,
13073,
12903,
12557,
12859,
12561,
12904,
12860,
12564,
12861,
12862,
13031,
12858,
12558,
12555
)
   --and spcode = 6920
    and lk.vscode = (select max(lk1.vscode) from mpulktmb lk1 where lk1.tmcode = lk.tmcode and lk1.vsdate < sysdate)
  order by lk.tmcode, lk.spcode, lk.sncode, lk.accessfee;
