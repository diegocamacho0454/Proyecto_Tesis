-------------ESTADO 22-----------------------
        select a.co_id, func_cap_co_id_GSM(co_id,'MIN',NULL) MIN,   func_cap_co_id_GSM(co_id,'IMSI',NULL) IMSI, 
        func_cap_co_id_GSM(co_id,'HLR',NULL)  HLR,          func_cap_co_id_GSM(co_id,'SERV',3013) ACT, 
        func_cap_co_id_GSM(co_id,'RCAT',NULL) RC,           func_cap_co_id_GSM(co_id,'PLPR',NULL) TipoPlan,
        func_cap_co_id_GSM(co_id,'CIC',NULL) CIC,           a.status , func_cap_co_id_GSM(co_id,'MIN',NULL) MIN,a.ref_text ,a.userid, a.insert_date, a.ts, a.* 
        from sysadm.MDSRRTAB a where co_id in (select co_id  FROM contr_services where dn_id in (
        select dn_id from directory_number where dn_num  in ('3143194232'))) order by REQUEST desc;
        
------------- CONTR_DEVICES ---------- Para la ultima secuencia cd_activ_date - cd_moddate (null)

Select cd_seqno , co_id , cd_port_num , cd_activ_date , cd_validfrom, cd_entdate , cd_deactiv_date , cd_moddate ,
decode(substr(cd_sm_num,8,1),0,'Oriente',1,'Occidente',2,'Costa') Zona,
''''||cd_sm_num||''''||',' , ''''||port_id||''''||','  , 
cd_status ,  cd_pending_state, rowid
from contr_devices a
where co_id in (192357895)
order by CO_ID,cd_seqno asc;

---- STORAGE_MEDIUM ----- Para la sim activa (a) SM_MODDATE debe ser NULL
Select  
sm_serialnum , sm_status , sm_entdate , sm_moddate, rowid
from storage_medium 
where sm_serialnum in ('89571012014054564266'); 

---- PORT ---- Para la sim activa (a) PORT_DEACTIV_DATE - PORT_MODDATE deben ser NULL
select port_id , port_num , port_status , port_activ_date , port_deactiv_date , port_entdate , port_moddate, rowid
from port p
where port_id  in('210666611');


/*
update port p
set p.port_status = 'a'
where p.port_id = '127860676'
and p.port_status = 'd'
*/

/*
Update  storage_medium 
set sm_status = 'a'
where sm_serialnum = '89571010012015866947'
and sm_status = 'd'

*/
