---Validar cual es el customer_id  del cliente 

-- consulta de customer_id 1p 
SELECT ca.customer_id, cs.co_id, dn.dn_num 
FROM CONTRACT_ALL ca, contr_services cs, directory_number dn 
WHERE ca.co_id = cs.co_id 
AND cs.dn_id = dn.dn_id 
AND substr(cs.cs_stat_chng, -1) <> 'd'  
AND dn.dn_num IN('3125176530');

-------------------Validar el registro de pagos ----------------

-- Registro de pagos
select *
from cashreceipts
where customer_id = '230994467'
order by Carecdate desc;
--caentdate, Carecdate, cachkamt, cabankname 
