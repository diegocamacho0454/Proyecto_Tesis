----------------Factura electronica-----------------

SELECT * FROM SYSADM.INH_FAC_ELEC e
WHERE e.min = '3136688146'        
;

SELECT * FROM SYSADM.INH_FAC_ELEC_TRANSAC FET 
WHERE CUST_CODE IN ('1.05755105') 
ORDER BY fecha_transaccion DESC
;
---------------- hallar customer_id------------------------
SELECT *
          FROM CUSTOMER_ALL 
          WHERE CUSTCODE = '1.13648027';
          
----------- Cambio de email en factura electronica-----------------          
          
          select c.customer_id, c.ccbill, c.ccemail, b.PAYMNTRESP, a.CHECK01
    from SYSADM.CCONTACT_ALL c, SYSADM.CUSTOMER_ALL b, SYSADM.INFO_CUST_CHECK a
     where c.customer_id ='&customer_id'
     and b.customer_id = '&customer_id'
     and a.customer_id = '&customer_id';
     ---for update
     
     select a.CHECK01,a.*,rowid from SYSADM.INFO_CUST_CHECK a where a.customer_id = '197880023';
