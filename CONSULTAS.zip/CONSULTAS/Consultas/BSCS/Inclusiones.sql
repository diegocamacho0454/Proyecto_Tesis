---------------- DATOS LINEA -----------------
select ca.customer_id, cs.co_id, dn.dn_num 
from contract_all ca, contr_services cs, directory_number dn 
where ca.co_id = cs.co_id 
and cs.dn_id = dn.dn_id 
and substr(cs.cs_stat_chng, -1) <> 'd' 
and dn.dn_num in (
'3203013348'
);

--Consultar el estado de la linea Actual.
SELECT a.Nombres as Nombre, a.CODMIN as MIN, a.Estado,a.esn, a.fecregis, text3 as Coordinador, COLGAR_A_MAESTRA,DISTRIBUIDOR1 
FROM ACTINCLUSION@ACTIVA A WHERE A.CODMIN   IN ('3205024557') order by fecregis desc;

SELECT a.fecbscs,  a.Nombres as Nombre, a.CODMIN as MIN, a.Estado, a.fecregis, text3 as Coordinador, COLGAR_A_MAESTRA,DISTRIBUIDOR1,rowid  
FROM ACTINCLUSION@ACTIVA A WHERE A.CODMIN   IN ('3205024557') order by fecregis desc;

SELECT a.Nombres as Nombre, a.CODMIN as MIN, a.Estado, a.fecregis, text3 as Coordinador, COLGAR_A_MAESTRA,DISTRIBUIDOR1,a.esn  
FROM ACTINCLUSION@ACTIVA A WHERE A.CODMIN   IN ('3205024557') order by fecregis desc;

SELECT a.Nombres as Nombre, a.CODMIN as MIN, a.Estado, a.fecregis, text3 as Coordinador, COLGAR_A_MAESTRA,DISTRIBUIDOR1  
FROM ACTINCLUSION@ACTIVA A WHERE A.CODMIN   IN (

'3117135506') order by fecregis desc;

select cc.*, rowid  from ccontact_all cc where CUSTOMER_ID in ('154639605');

----------------Consulta de incluido------------------------
SELECT a.Nombres, a.CODMIN, a.Estado, rowid FROM ACTINCLUSION@ACTIVA A WHERE A.CODMIN IN ('3205024557');
--FECREGIS
--COLGAR_A_MAESTRA
---ESTADO - ACTIVADA

--Modificar datos faltantes -- llenar campos faltantes con 1
SELECT a.*,
rowid FROM CCONTACT_ALL a 
WHERE CUSTOMER_ID IN ('139488891')
order by CCSEQ;
--Modificar datos faltantes, esta bn---- error -4
SELECT a.*, rowid FROM CCONTACT_ALL a WHERE CUSTOMER_ID IN (35436584);
SELECT customer_ID,ccseq,ccfname, cclname, ccaddr1, cccity, rowid FROM CCONTACT_ALL a WHERE CUSTOMER_ID IN (35436584);

--ejecutar en bscs  Para obtener iddistribuidor 
select * from ORIGINAL_DEALER where co_id in (SELECT CO_ID
                    FROM CONTR_SERVICES A, DIRECTORY_NUMBER B
                    WHERE A.DN_ID = B.DN_ID  AND A.CS_DEACTIV_DATE IS NULL
                    AND B.DN_NUM IN ('3057227804'));

 -------DEALER - CONSULTA -------------------------------------------------------
select  a.codmin, a.codigo_distribuidor, fecha_venta
from activacion@activa a
 where a.codmin ='3004412805';

---------RECHAZO POR DATOS INCORRECTOS----------------------
/*--- se debe validar que no tenga acrivo el servicio de �	Datos Compartidos Padre.
                                                         �	Serv Gesti�n de Actividades
                                                         
y luego ejecutar el siguiente test para desactivar servicio */


sysadm.pkg_bscs_ac.desactivar_servicio;


--- Volver a activar servicio ----

sysadm.pkg_bscs_ac.activar_servicio;                                                         

 
---------------VERIFICAR INCLUSIONES Y EXCLUSIONES --------------------------------------- 
 
 SELECT a.Nombres as Nombre, a.CODMIN as MIN, a.Estado, a.fecregis, text3 as Coordinador, COLGAR_A_MAESTRA, DISTRIBUIDOR1
FROM ACTINCLUSION@ACTIVA A WHERE A.CODMIN IN (
'3044619002'
)
--and estado = ('90')
order by fecregis desc;
