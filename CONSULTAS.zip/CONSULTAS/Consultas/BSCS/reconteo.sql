/*SELECT * FROM CONTRACT_ALL WHERE CUSTOMER_ID = 33209846;
SELECT DN_ID FROM CONTR_SERVICES WHERE CO_ID = 28276207;
SELECT * FROM DIRECTORY_NUMBER WHERE DN_ID = 37754162;*/
 --CONTRATO
-----------------------------------------
select b.dn_num, a.CO_ID, a.CS_ACTIV_DATE, a.TMCODE, a.CS_STAT_CHNG
  from contr_services a
  JOIN (select dn_num, dn_id
          from directory_number
         where dn_num in ('&min')) b on (a.DN_ID = b.DN_ID)
 order by cs_seqno asc;

select *
  from contr_services
 where co_id in
       (select a.CO_ID
          from contr_services a
          JOIN (select dn_num, dn_id
                 from directory_number
                where dn_num in ('&min')) b on (a.DN_ID = b.DN_ID));

--ELEGIDOS
select a.*, a.rowid
  from mpufftab a
 where co_id in (SELECT co_id
                   FROM contr_services a, directory_number b
                  WHERE a.dn_id = b.dn_id
                    AND b.dn_num in ('&min')
                    and cs_deactiv_date IS NULL);
                    
--REDINT
SELECT i.fecha_creacion,i.*
  FROM sysadm.red_int i
  where co_id in (SELECT co_id
                            FROM contr_services a, directory_number b
                           WHERE a.dn_id = b.dn_id
                             AND b.dn_num in ('&min')
                             and cs_deactiv_date IS NULL) 
 ORDER BY i.fecha_creacion desc ;
                     
--HISTORIA CONTRATO
-----------------------------------------

select *
  from contract_history H
 where co_id IN ((select a.CO_ID
              from contr_services a
              JOIN (select dn_num, dn_id
                     from directory_number
                    where dn_num in ('&min')) b on (a.DN_ID =
                                                         b.DN_ID)));

--CICLO

SELECT AL.BILLCYCLE,AL.*
  FROM CUSTOMER_ALL AL
 WHERE CUSTOMER_ID IN
       (SELECT CUSTOMER_ID
          FROM CONTRACT_ALL
         WHERE CO_ID IN (
                         SELECT CO_ID
                           FROM contr_services a, directory_number b
                          WHERE a.dn_id = b.dn_id
                            AND b.dn_num in ('&min')
                            AND SUBSTR(a.cs_stat_chng, -1) = 'a'
                            )
                            );

--TICKLER
SELECT *
  FROM TICKLER_RECORDS
 WHERE CUSTOMER_ID in
       (SELECT CUSTOMER_ID
          FROM CONTRACT_ALL
         WHERE CO_ID in (SELECT co_id
                           FROM contr_services a, directory_number b
                          WHERE a.dn_id = b.dn_id
                            AND b.dn_num in ('&min')
                         /*and cs_deactiv_date IS NULL*/
                         ))
ORDER BY TICKLER_NUMBER desc;

--SELECT * FROM INH_CICLOS C WHERE C.CICLO = '07'
/*
/*select CO_ID, TMCODE, SPCODE, A.SNCODE, CS_STAT_CHNG, DES
  from contr_services A, MPUSNTAB B
 where CO_ID = 7868930
   AND A.SNCODE = B.SNCODE


select *
  from contract_history H
 where co_id IN (17982438)
   AND CH_SEQNO IN (SELECT MAX(CH_SEQNO)
                      FROM contract_history H1
                     WHERE H.CO_ID = H1.CO_ID)



select *
  from reasonstatus_all
 where rs_id IN (32,5,6,190)
 
select * from contract_all where  co_id IN (37200413)

SELECT * FROM customer_all WHERE customer_id = 34144613

--minutos que tiene un plan
SELECT * FROM NEW12X12.INH_DETMINPLANES WHERE tmcode in (5936)

TMCODE  5938
MINCOMCEL  1393
MINFIJOS  
MINOTROS  431
MINPROCOMCEL  0



SELECT DN.DN_NUM, D.CUSTCODE
  FROM DIRECTORY_NUMBER DN
  JOIN (SELECT DISTINCT C.CUSTCODE, C.CUSTOMER_ID, C.CO_ID, CS.DN_ID
          FROM CONTR_SERVICES CS
          JOIN (SELECT B.CUSTCODE, B.CUSTOMER_ID, CT.CO_ID
                 FROM CONTRACT_ALL CT
                 JOIN (SELECT * --CUSTOMER_ID, AL.CUSTCODE
                        FROM CUSTOMER_ALL AL
                       WHERE AL.CUSTCODE IN ('8.21768260')) B ON (CT.CUSTOMER_ID =
                                                                              B.CUSTOMER_ID)) C ON (CS.CO_ID =
                                                                                                   C.CO_ID)) D ON (DN.DN_ID =
                                                                                                                  D.DN_ID)
                                                                          


SELECT * FROM INH_CICLOS
WHERE CICLO =  '11'
                            
  SELECT c.dn_num,A.CUSTCODE
    FROM CUSTOMER_ALL A
    JOIN (SELECT CO_ID,CUSTOMER_ID FROM CONTRACT_ALL) B ON (A.CUSTOMER_ID = B.CUSTOMER_ID)
    JOIN (SELECT dn_num,CO_ID
            FROM contr_services a, directory_number b
           WHERE a.dn_id = b.dn_id
             AND b.dn_num in ('3142371420')
             AND SUBSTR(a.cs_stat_chng, -1) = 'a') C ON (C.CO_ID = B.CO_ID)


  /*SELECT NVL(SUM(duracion), 0), NVL(SUM(valor_total), 0)
    FROM dwh.LLAMADASDOC1_0104@dwh
   WHERE tele_num = 3206886801 --:vcCodMin 
     AND upper(servicio_voz) = 'VOZ'
     AND servicio_voz in ('voz', 'Eleg_SinCosto', 'Eleg_ConCosto')
     AND length(telefono) >= 4
     AND valor_total = 0
     AND SUBSTR(telefono, 1, 3) IN
         ('*12', '310', '311', '312', '313', '314', '320', '321')
     AND INSTR('||vcElegidos||', TELEFONO) = 0
   ORDER BY duracion, valor_total;


SELECT * FROM INH_CICLOS WHERE CICLO = '27'


                    

                    
--MICROCELDA
select TMCODE, SPCODE, MICROCELDA
    from inh_tmsp_prep
   where tmcode IN (6790)
select * from mpusntab where sncode = 3104   


SELECT * FROM CASHRECEIPTS WHERE CUSTOMER_ID IN (69820012)  ORDER BY CAENTDATE ASC

SELECT * FROM BC_SHIFT WHERE customer_id IN (34144613)  

SELECT * FROM sysadm.mpufftab WHERE co_id=69820012

SELECT * FROM sysadm.red_int  WHERE co_id in (69820012)  ORDER BY fecha_creacion asc  



----------------------------------------------------------------------------  

select a.*, a.rowid            
from mpufftab a
 where co_id in (SELECT co_id
                   FROM contr_services a, directory_number b
                  WHERE a.dn_id = b.dn_id
                    AND b.dn_num in ('3206886802')
                    and cs_deactiv_date IS NULL)


----------------------------------------------------------------------------   
--PLAN
select * from mputmtab where tmcode = 7276--2103--2691
select * from ex_descplanes where descripcion like '%Sin Fin 190 WB Elegido Fijo Abierto:%'
select * from mpulktmb where tmcode = 2102

SELECT VSDATE, TMCODE, VSCODE, ACCESSFEE, SPCODE, SNCODE, b.ROWID
  FROM MPULKTMB b
 WHERE TMCODE IN (7400)
   AND SNCODE = 3013

SELECT * FROM new12X12.inh_detminplanes WHERE tmcode = 7400


select * from CUSTOMER_ALL
where s.pas
select * from CONTRACT_ALL 
select *


 
SELECT *
  FROM TICKLER_RECORDS
 WHERE CUSTOMER_ID in
       (SELECT CUSTOMER_ID
          FROM CONTRACT_ALL
         WHERE CO_ID in (SELECT co_id
                          FROM contr_services a, directory_number b
                         WHERE a.dn_id = b.dn_id
                           AND b.dn_num in ('3104259146')
                           /*and cs_deactiv_date IS NULL))
 ORDER BY TICKLER_NUMBER desc
