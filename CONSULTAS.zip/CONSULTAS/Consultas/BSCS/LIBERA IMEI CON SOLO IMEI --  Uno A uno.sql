DECLARE

v_IMEI            varchar2(20) := TRIM('&imei'); --014017000959898
INCIDENTE         varchar2(20) := TRIM('&incidente');  --SD1569419 
v_largotick VARCHAR2(200);
exc_salir    EXCEPTION;

v_iccid           varchar2(100);
d_fecha_desacti   date;
n_puerto          number;
v_actufecha       varchar2(200);
v_actpuerto       varchar2(200);
v_inghisto        varchar2(200);
n_codcausal       number;
n_sechist         number;
v_min             varchar2(20);
v_user_des        varchar2(20);
n_est_puerto      varchar2(20);
v_estado          varchar2(50);
v_est             varchar2(50);
v_causal          varchar2(200);
n_inserhist       number :=0;
n_customer1       number;
n_customer2       number;
n_contrato        NUMBER;
d_fecha1          date;
d_fecha2          date;
d_fecha3          date;
cu_infoimei SYSADM.INH_IMEI%ROWTYPE; 
pvc_salida  VARCHAR2(200);  
v_respuesta  VARCHAR2(200);
  
BEGIN
  


  
/*for j in ( 
            SELECT T.COID , T.IMSI , T.INSTANCIA 
            FROM INH_TRABAJO_CAP T
            WHERE T.INSTANCIA = 160920150420 
            AND t.coid >= 3 
            AND t.coid < 80 
           
              ) loop    
     BEGIN  
     
            
     v_IMEI := j.imsi;*/
   
     v_respuesta :='LIBERADO'; 
     IF INCIDENTE IS NULL THEN
         v_respuesta := 'INGRESE EL NUMERO DEL IM.';
         RAISE exc_salir;
     END IF; 
     
 v_largotick := INCIDENTE||'-Se valida que el IMEI se relaciona con un CO_ID desactivado con causal 289 Migracion_AMDOCS.';

     
     BEGIN
      select i.customer_id,i.fec_regis
      into n_customer1,d_fecha1
      from inh_imei i
      where i.imei = v_IMEI; 
      
      
     EXCEPTION 
       WHEN too_many_rows THEN 
            v_respuesta := 'Varios IMEI en INH_IMEI';
            
       WHEN NO_DATA_FOUND THEN 
            v_respuesta := 'No existe el IMEI '||v_IMEI|| ' en la base de datos de BSCS, tabla INH_IMEI';
            
       WHEN OTHERS THEN
            v_respuesta := 'Error al consultar INH_IMEI';     
       
     END; 
     
      IF v_respuesta != 'LIBERADO' THEN
        RAISE exc_salir;
      END IF;       
     
      BEGIN
      select i.customer_id ,i.fec_activ
      into n_customer2 ,d_fecha2
      from inh_historico_imei  i
      where i.imei = v_IMEI 
      AND i.customer_id = n_customer1;   
      
     EXCEPTION 
       
       WHEN NO_DATA_FOUND THEN 
            n_inserhist :=1;
            WHEN OTHERS THEN
            DBMS_OUTPUT.put_line('Error al consultar INH_HISTORICO_IMEI ');     
     END;

     
          BEGIN
               SELECT ca.co_id 
               INTO n_contrato
               FROM contract_all ca 
               WHERE ca.customer_id = n_customer1;
         
              
      
           EXCEPTION 
             WHEN too_many_rows THEN 
                  v_respuesta := 'Varios registros en contract_all, Customer ' || to_char(n_customer1) ;
             
             WHEN NO_DATA_FOUND THEN 
                  v_respuesta := 'No existe contrato en contract_all, Customer ' || to_char(n_customer1);
             
             WHEN OTHERS THEN
                  v_respuesta := 'Error al consultar contract_all, Customer ' || to_char(n_customer1);     
           END;
       
     IF v_respuesta != 'LIBERADO' THEN
        RAISE exc_salir;
     END IF;  

     BEGIN
        SELECT ch.entdate,ch.userlastmod ,ch.ch_reason
        INTO   d_fecha3 ,v_user_des,n_codcausal
         FROM contract_history ch
             WHERE ch.co_id = n_contrato
               AND ch.ch_seqno = (SELECT MAX(ch1.ch_seqno)
                                    FROM contract_history ch1
                                   WHERE ch1.co_id = ch.co_id)
               AND ch.ch_status = 'd'
               --AND ch.userlastmod = 'MIGRACION_AMDOCS'
               AND ch.ch_reason = 289;  
     
      
                select *
                into cu_infoimei
                from inh_imei i
                where i.imei = v_IMEI;
                
                SELECT MAX(i.seq_id)+1
                INTO  n_sechist
                FROM sysadm.inh_historico_imei  i
                WHERE i.CUSTOMER_ID = n_customer1 ;
                 
                BEGIN   
                    SELECT s.sm_serialnum,cd.cd_deactiv_date,p.port_id,p.port_status
                    INTO   v_iccid ,d_fecha_desacti ,n_puerto,n_est_puerto
                    FROM  contr_devices    cd,
                          port             p,
                          storage_medium   s 
                    WHERE p.port_id = cd.port_id 
                    AND   s.sm_id = p.sm_id
                    AND   cd.co_id = n_contrato;
                    --AND   p.port_status = 'd';    
                    
                  /*  IF n_est_puerto != 'd' THEN     
                      
                       UPDATE  sysadm.port p 
                       SET     p.port_status = 'd'
                       WHERE   p.port_id =  n_puerto;
                       
                       IF SQL%ROWCOUNT = 1 THEN
                       v_actpuerto := '**Se actualiz� a desactivado el estado del puerto. (antes, ' || n_est_puerto || ')';      
                       ELSE 
                       v_respuesta := 'validar el estao del puerto ' || to_char(n_puerto);
                       RAISE exc_salir;  
                       END IF;
                       
                    END IF;*/  
                    
                    
                 EXCEPTION 
                   WHEN OTHERS THEN 
                       DBMS_OUTPUT.put_line('No se encontr� ICCID para el contrato ' || n_contrato);
                       v_iccid :='';
                 END;
                          
                 
                 BEGIN
                      UPDATE contr_devices d 
                          SET d.cd_deactiv_date = d_fecha3
                       WHERE d.port_id = n_puerto
                          AND d.cd_deactiv_date IS NULL;
                          
                       IF SQL%ROWCOUNT = 1 THEN
                       v_actufecha := '**Se actualiz� fecha desactivaci�n en CONTR_DEVICES, para el puerto '
                                      ||to_char(n_puerto); 
                       
                       ELSIF SQL%ROWCOUNT = 0 THEN
                       v_actufecha := '**Fecha de desactivaci�n ya ingresada en CONTR_DEVICES, para el puerto '
                                      ||to_char(n_puerto); 
                       
                       ELSE
                       ROLLBACK;
                       RAISE exc_salir;
                       END IF;      
                     
                 
                   EXCEPTION 
                   WHEN OTHERS THEN 
                       v_respuesta := 'Error al Actualizar CONTR_DEVICES para el puerto ' || to_char(n_puerto);
                       RAISE exc_salir;
                  END;
                                
                
                IF n_inserhist = 1 THEN
                   BEGIN
                   INSERT INTO sysadm.inh_historico_imei 
                   VALUES(n_customer1,v_IMEI,n_sechist,n_codcausal,d_fecha1,d_fecha3,v_iccid,user);  
                   
                   IF SQL%ROWCOUNT = 1 THEN
                   v_inghisto := 'Se guard� la informaci�n en INH_HISTORICO_IMEI';
                   ELSE 
                     DBMS_OUTPUT.put_line('NO INSERT� EN INH_HISTORICO_IMEI');
                   END IF;
                   EXCEPTION 
                      WHEN OTHERS THEN
                           DBMS_OUTPUT.put_line('ERROR AL INSERTAR EN INH_HISTORICO_IMEI');
                   END;     
                   
                ELSE
                    v_inghisto := 'Informaci�n ya exist�a en INH_HISTORICO_IMEI';
                END IF; 
               
               BEGIN
                     DELETE sysadm.inh_imei i 
                      WHERE  i.imei = v_IMEI; 
                 
               IF SQL%ROWCOUNT = 1 THEN 
                   
                   sysadm.procreartickler(n_customer1, n_contrato, 'COMENTS', NULL,
                                NULL, 'LIBERA IMEI', v_largotick,
                                pvc_salida, 'NO');
                    dbms_output.put_line('Incidente: ' ||INCIDENTE  );
                    dbms_output.put_line('Buenas tardes, Se realiz� la liberaci�n del IMEI: ');
                    dbms_output.put_line('fecha de desactivaci�n, contrato y usuario que desactiv�:'
                                          ||d_fecha3||','||n_contrato||','|| v_user_des); 
                    dbms_output.put_line('CUSTOMER_ID:  ' || cu_infoimei.CUSTOMER_ID );
                    dbms_output.put_line('IMEI:         ' || cu_infoimei.IMEI);
                    dbms_output.put_line('FEC_REGIS:    ' || cu_infoimei.FEC_REGIS);
                    dbms_output.put_line('USUARIO:      ' || cu_infoimei.USUARIO);
                    dbms_output.put_line('FEC_MOD:      ' || cu_infoimei.FEC_MOD); 
                    dbms_output.put_line('**' || v_inghisto);
                    dbms_output.put_line(v_actufecha);                     
                    --dbms_output.put_line(v_actpuerto);
                    IF pvc_salida = 1 THEN
                    dbms_output.put_line('**Tickler Ingresado. (' || pvc_salida||')' );
                    ELSE
                    dbms_output.put_line('**No inges� Tickler. (' || pvc_salida||')' );  
                    END IF;
                    --COMMIT;
               ELSE 
                   dbms_output.put_line('VALIDAR EL DELETE, BORRARIA => ' || SQL%ROWCOUNT ||' REGISTROS' );--COMMIT;
                   --ROLLBACK;
               END IF;        
               
               EXCEPTION 
                      WHEN OTHERS THEN
                           DBMS_OUTPUT.put_line('ERROR AL INSERTAR EN INH_IMEI');
               END;    
               
               
        
          EXCEPTION 
                   WHEN too_many_rows THEN 
                        DBMS_OUTPUT.put_line('Varios contract_history ');
                   
                   WHEN NO_DATA_FOUND THEN 
                        DBMS_OUTPUT.put_line('El contrato no est� en estado d y causal 289-Migracion_AMDOCS'); 
                        BEGIN
                        SELECT ch.ch_status,DECODE(ch.ch_status,
                                      'a','ACTIVO',
                                      's','SUSPENDIDO',
                                      'f','LIBRE',
                                      'Otro estado')
                                              ,( select r.rs_desc
                                               from reasonstatus_all r
                                               where r.rs_id = ch.ch_reason 
                                              ) causal  
                          INTO v_est,v_estado,v_causal  
                           FROM contract_history ch
                               WHERE ch.co_id = n_contrato
                                 AND ch.ch_seqno = (SELECT MAX(ch1.ch_seqno)
                                                      FROM contract_history ch1
                                                     WHERE ch1.co_id = ch.co_id);   
                                                     
                         EXCEPTION 
                            WHEN OTHERS THEN
                               DBMS_OUTPUT.put_line('Error al consultar estado en contract_history ');
                         END;                            
                                                     
                        
                             
                          DBMS_OUTPUT.put_line('Estado contrato: ' || v_estado ||' Causal: '|| v_causal );
                          IF v_est IN ('a','s') THEN
                                                   
                             BEGIN
                                   SELECT d.dn_num
                                   INTO v_min
                                   FROM sysadm.contr_services se
                                        ,sysadm.directory_number d
                                   WHERE se.dn_id = d.dn_id
                                   AND se.co_id = n_contrato
                                   AND se.sncode = 3013
                                   AND se.main_dirnum = 'X'
                                   AND se.cs_deactiv_date IS NULL;
                                   DBMS_OUTPUT.put_line('IMEI Relacionado con el MIN '||v_min ||', Contrato: ' 
                                                       || n_contrato ||' ,Customer: '|| n_customer1
                                                       || ', IMEI ' || v_IMEI );
                             EXCEPTION 
                               WHEN OTHERS THEN
                                  DBMS_OUTPUT.put_line('IMEI no Relacionado MIN'||v_min ||', Contrato: ' 
                                                       || n_contrato ||' ,Customer: '|| n_customer1
                                                       || ', IMEI ' || v_IMEI );
                             END;      
                             
                          END if; 
                        
                       WHEN exc_salir THEN
                             dbms_output.put_line('Salida: ' || v_respuesta);
                        WHEN OTHERS THEN
                         DBMS_OUTPUT.put_line('Error al consultar contract_history ' || sqlcode ||' '||sqlerrm );     
                      END;
                         

v_iccid           := NULL;
d_fecha_desacti   := NULL;
n_puerto          := NULL;
v_actufecha       := NULL;
v_actpuerto       := NULL;
v_inghisto        := NULL;
n_codcausal       := NULL;
n_sechist         := NULL;
v_min             := NULL;
v_user_des        := NULL;
n_est_puerto      := NULL;
v_estado          := NULL;
v_est             := NULL;
v_causal          := NULL;
n_inserhist       := NULL;
n_customer1       := NULL;
n_customer2       := NULL;
n_contrato        := NULL;
d_fecha1          := NULL;
d_fecha2          := NULL;
d_fecha3          := NULL;
cu_infoimei.CUSTOMER_ID :=NULL;
cu_infoimei.IMEI        :=NULL;
cu_infoimei.FEC_REGIS   :=NULL;
cu_infoimei.USUARIO     :=NULL;
cu_infoimei.FEC_MOD     :=NULL;
pvc_salida              :=NULL; 
v_respuesta             :=NULL;
v_largotick             :=NULL;

EXCEPTION 
   WHEN exc_salir THEN
        dbms_output.put_line('Salida: ' || v_respuesta);           
          
END;

/*end loop;

END;*/
