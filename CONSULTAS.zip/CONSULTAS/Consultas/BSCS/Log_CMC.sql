 SELECT /*+ index(r.inx_fecha_registro) */ dr.ticket, r.usuario, r.fecha_registro, dr.mincod, dr.contrato ,ndr.id_tipo_novedad, tn.nombre
          FROM SYSADM.REGISTRO R ,SYSADM.DETALLE_REGISTRO DR, SYSADM.NOVEDAD_DETALLE_REGISTRO NDR, SYSADM.TIPO_NOVEDAD TN
          WHERE R.ID_REGISTRO =DR.ID_REGISTRO
          AND ndr.id_tipo_novedad <> 21  --- Conciliacion Elegidos
          AND DR.ID_DETALLE = NDR.ID_DETALLE
          AND TN.ID_TIPO_NOVEDAD = NDR.ID_TIPO_NOVEDAD
          AND dr.ticket is not null
          AND r.usuario = 'CMC_BSCS'
          AND fecha_registro >= to_date('18122016','ddmmyyyy')
          AND fecha_registro <= to_date('18122016','ddmmyyyy');
          
          
          SELECT /*+ index(r.inx_fecha_registro) */ dr.ticket, r.usuario, r.fecha_registro, dr.mincod, dr.contrato ,ndr.id_tipo_novedad, tn.nombre
          FROM SYSADM.REGISTRO R ,SYSADM.DETALLE_REGISTRO DR, SYSADM.NOVEDAD_DETALLE_REGISTRO NDR, SYSADM.TIPO_NOVEDAD TN
          WHERE R.ID_REGISTRO =DR.ID_REGISTRO
          AND ndr.id_tipo_novedad <> 21  --- Conciliacion Elegidos
          AND DR.ID_DETALLE = NDR.ID_DETALLE
          AND TN.ID_TIPO_NOVEDAD = NDR.ID_TIPO_NOVEDAD
          AND dr.ticket is not null
          AND r.usuario = 'CMC_BSCS'
          AND r.fecha_registro >= to_date('29/12/2016 00:00:00','DD/MM/YYYY HH24:MI:SS')
          AND r.fecha_registro <= to_date('29/12/2016 23:59:59','DD/MM/YYYY HH24:MI:SS');

