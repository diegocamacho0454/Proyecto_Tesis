-----------------Customer ID-------------------------------------
SELECT a.dn_num, b.co_id, b.cs_seqno, b.tmcode, b.cs_stat_chng, b.cs_deactiv_date, d.customer_id, d.custcode
  FROM directory_number a, contr_services b, contract_all c, customer_all d
WHERE a.dn_num in (
'3136411111'

)
   AND b.dn_id = a.dn_id
   AND c.co_id = b.co_id
   AND d.customer_id = c.customer_id
   --AND b.cs_deactiv_date IS NULL 
  ORDER BY nvl(b.cs_deactiv_date,SYSDATE) DESC ;
  
---- aprovisionamiento promoci�n ----- 

select dnu.dn_num,
       cu.id_usuario,
       cu.id_campana,
       cu.fecha_inicio_prom,
       cu.fecha_registro_prom,
       cu.estado,
       u.ciclo,
       u.customer_id,
       pp.flag_convivencia,
       pp.flag_permanencia,
       pp.descripcion,
       aa.patron,
       bb.aplica_customer,
       pp.aplica_suspendidos,
       pp.aplica_desact_cartera,
       pp.aplica_con_iva      
  from sysadm.perm_camp_usuarios  cu,
       sysadm.perm_usuarios       u,
       sysadm.perm_campana        pp,
       sysadm.PERM_PERIODICIDAD   aa,
       sysadm.PERM_CAMP_BENEFICIO cb,
       sysadm.PERM_BENEFICIO      bb,
       sysadm.contr_services      se,
       sysadm.directory_number    dnu
 where cu.id_usuario = u.id
   and u.customer_id in ('39623021')
   and pp.id = cu.id_campana
   and cb.id_campana = pp.id
   and cb.id_beneficio = bb.id
   and bb.perioricidad = aa.id
   and u.co_id = se.co_id
   and se.dn_id = dnu.dn_id order by id_usuario desc;
 
 
   
---- entrega de la promoci�n--------
select * from sysadm.perm_historico_beneficios a where a.id_usuario in('5559110')
--and a.id_campana = '1581';
--and periodo_bonificado = '6' 
order by id_usuario desc ;

--------------- tickler promoci�n-------------------

SELECT y_coordinate,created_date, created_by, customer_id,tickler_code, tickler_number, short_description, long_description, co_id
    FROM tickler_records 
  WHERE customer_id in ('280511981')
  and TICKLER_CODE = 'DXCAMPAC' ;--DXCAMPAC,CAMPAACT



---- ruta log ---
   En la p�gina 8  del documento tener en cuenta que es En Comhp35 en la ruta:
/user1/users/INH_WORKARROUND/aplicaciones_back/AplicaCampanaPerm/log/201705
-  Luego digitar el comando siguiente:(el n�mero corresponde al customer_id a consultar)
grep 162408530 APLICACAMPANAPERM2017*.*

;

---- consultas activa----Rechazada por Datos Incorrectos
select a.esn,a.CODMIN min,a.fecbscs, a.trajo_equipo,a.codigo_distribuidor distribuidor,tipo_contrato, a.FECREGIS,a.planilla, a.ESTADO, a.id_activacion, a.imei,a.nombres,a.modelo_equipo Nombre_equipo,a.*,rowid
from ACTIVACION@ACTIVA.WORLD a
where codmin in ('3112842784');


--a.planilla in('16155228','16155248','16155213','16155268');
--where a.esn in('89571010005055415708');

SELECT A.CODMIN, A.CODIGO_DISTRIBUIDOR,A.TMCODE, A.FECBSCS, C.*
  FROM CPNG_CAMPANAXACTIVACION@ACTIVA.WORLD C, ACTIVACION@ACTIVA.WORLD A
WHERE A.ID_ACTIVACION = C.IDACTIVACION(+)
   AND A.CODMIN IN ('&CODMIN');

select* from extranet.cpng_campanaxactivacion@activa.world where idactivacion in ('96213992');



---estado de la linea---
SELECT *
  FROM contract_history h
WHERE co_id IN ((SELECT a.co_id
                   FROM contr_services a
                   JOIN (SELECT dn_num, dn_id
                          FROM directory_number
                         WHERE dn_num in ('3234191867')) b
                     ON (a.dn_id = b.dn_id)))order by ch_validfrom desc;

     select *
     from sysadm.perm_usuarios      p,   
          sysadm.perm_camp_usuarios c, 
          sysadm.perm_campana       a 
    where c.id_usuario in('202879922',
'198851291',
'192324336',
'192281047',
'171483811',
'158712975',
'153840076',
'122026001',
'97321037')  
      and p.id = c.id_usuario       
      and c.id_campana = a.id;
------validar si dos campa�as conviven-------      
      select *     from sysadm.perm_campana       a 
    where a.id IN ('1512'); 

   
------------cargue de la promoci�n-----------------

Select f.*, rowid  from fees f where f.customer_id in ('231691319')  and to_CHAR(f.entdate,'mmyy')=('&fecha');


---cargue ruta OCC
/user1/users/INH_WORKARROUND/CargaOcc/shell

-----Como esta dividido el pago de Spligt billing en una maestra---------------

Select * from  split_contratos where co_id in  ('210338064');

----------------------------------------------------------------------------
Select f.*, rowid from fees f where f.username in ('EUO7154A');


select * from sysadm.perm_camp_benef_vta_equipos a where a.co_id = 165230513;

-------------------------------------Validacion creacion nuevo CUSTCODE----------------------
select * from sysadm.inh_rel_equ_ser s where '36272456' in (s.customer_id_equipo, s.customer_id_servicio);



-------------verificaci�n facturas -----------------------

select * from orderhdr_all where customer_id in (116831954); 

select * from ordertrailer where otxact in ('720766841',
'714663781',
'708680847',
'702840824',
'686556025',
'680964412'
);  


select * from sysadm.perm_camp_benef_vta_equipos a where a.co_id = 134259120; 

---- bonificaci�n obsequio---------------

select  o.customer_id,
        cu.cscurbalance deuda_actual
       ,cu.prev_balance 
       ,o.ohxact doc_cobro
       ,o.ohstatus PS
       ,o.ohentdate fecha_genera
       ,o.ohduedate fecha_limit
       ,o.ohinvamt  valor_factura
       ,o.ohopnamt  valor_pendiente
       ,c.cadoxact
       ,c.cadamt
       ,ca.cachkamt
       ,ca.caentdate  
       ,ca.carecdate
       ,ca.cachkdate
       ,ca.causername 
       ,ca.cabankname
       ,decode(ca.carpp,null,'','ANULADO') Est_Pago
       ,ca.carpp
from sysadm.orderhdr_all      o
     ,sysadm.cashdetail       c
     ,sysadm.cashreceipts_all ca
     ,sysadm.customer_all     cu
where o.customer_id in (243743770)
--and   o.ohxact in (728908956,)
and o.ohxact = c.cadoxact
and c.cadxact = ca.caxact  
and cu.customer_id = o.customer_id
--and ca.carpp IS NULL
--and ca.cachkamt > 0 --is not null
order by o.ohentdate desc;

------validar log de balanceo por usuario-----
select * from SYSADM.LOG_BALANCEO where Customer_id ='243743770' order by fecha desc;
