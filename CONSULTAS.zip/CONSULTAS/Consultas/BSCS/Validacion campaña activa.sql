------Verificacion de campa�a tiene activa en BSCS--------------
select DISTINCT p.co_id,
                p.customer_id,
                c.fecha_registro_prom,
                c.fecha_inicio_prom,
                TO_CHAR(ADD_MONTHS(c.fecha_inicio_prom,(a.duracion)- 2), 'dd/mm/yyyy hh24:mi:ss') as vencimiento,
                p.ciclo,
                c.id_usuario,
                c.estado,
                c.id_campana,
                c.usuario_bd,
                dnu.dn_num,
                a.descripcion,
                a.duracion
                
  from sysadm.perm_usuarios      p,
       sysadm.perm_camp_usuarios c,
       sysadm.perm_campana       a,
       Sysadm.Directory_Number   dnu,
       sysadm.contr_services     se,
       sysadm.customer_all cu
where dnu.dn_num in ('3017083615')
and p.customer_id = cu.customer_id
   and p.id = c.id_usuario
   and c.id_campana = a.id
   and p.co_id = se.co_id
   and se.dn_id = dnu.dn_id;
