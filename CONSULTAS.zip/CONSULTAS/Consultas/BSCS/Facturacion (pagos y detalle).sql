
-------------CONSULTA DESCRIPCION DE FACTURA-----------------
-- consulta de customer_id 1p

SELECT ca.customer_id, cs.co_id, dn.dn_num
  FROM CONTRACT_ALL ca, contr_services cs, directory_number dn
WHERE ca.co_id = cs.co_id
   AND cs.dn_id = dn.dn_id
   AND substr(cs.cs_stat_chng, -1) <> 'd'
   AND dn.dn_num in ('&min');
      
---------------------FEES--------------------------
select * from sysadm.FEES where customer_id in ('144361651');
select * from sysadm.FEES_SDE where customer_id in ('260615112');


---consulta de cobros 
select * from fees f
where f.customer_id = '265630171';


---consulta de customer_id maestra

SELECT customer_id, customer_id_high, custcode FROM customer_all cu WHERE custcode = '8.22409062';

SELECT customer_id, customer_id_high, custcode  FROM customer_all cu WHERE cu.customer_id = '70506856';


------------------------------------DETALLE DE FACTURACION--------------------------------------------------
select customer_id,remark,substr(TRIM(remark),-10),amount,entdate,valid_from , username,period,length(remark)
FROM sysadm.FEES 
where customer_id in (11335649)
AND entdate>= to_date ('13042017 00:00:00','ddmmyyyy hh24:mi:ss') 
AND entdate<= to_date ('12052017 23:59:59','ddmmyyyy hh24:mi:ss')
AND remark like '%*#3%';

---consulta consecutivo de factura
SELECT o.ohxact consecutivo, customer_id, o.ohentdate fecha,o.ohinvamt vlr_pagar, o.ohstatus estado
FROM sysadm.orderhdr_all o
WHERE customer_id = '195193070'
ORDER BY o.ohentdate DESC;

--consulta detalle de factura
select a.otxact cnsc_detalle, a.otglsale cuenta,g.gladesc descripcion, a.otmerch valor 
from ordertrailer a, glaccount_all g 
where a.otglsale = g.glacode 
and otxact = 2162860939;

----------consulta consecutivo de factura--------------

SELECT o.ohxact consecutivo, customer_id, o.ohentdate fecha,
       o.ohinvamt vlr_pagar, o.ohstatus estado
  FROM sysadm.orderhdr_all o
WHERE customer_id = '185047357'
ORDER BY o.ohentdate DESC;

--consulta detalle de factura

select  
a.otxact cnsc_detalle, a.otglsale cuenta,g.gladesc descripcion, a.otmerch valor 
from ordertrailer a, glaccount_all g 
where a.otglsale = g.glacode 
and otxact = 709526695
order by valor desc;



select g.gladesc descripcion,sum(a.otmerch) valor
from ordertrailer a, glaccount_all g 
where a.otglsale = g.glacode 
and otxact = 1750878214
group by g.gladesc 
order by valor desc;



-------------CONSULTA PDF CONTRA TXT--------------------------------

select * from customer_all a where a.custcode = '1.01174978';

  select customer_id,remark,remark,amount,entdate,valid_from 
 -- customer_id,remark,substr(TRIM(remark),-10),amount,entdate,valid_from --, username,period,length(remark)
  FROM sysadm.FEES 
  where customer_id in (25883357)
  AND entdate>= to_date ('22032014 00:00:00','ddmmyyyy hh24:mi:ss') 
  AND entdate<= to_date ('21042014 23:59:59','ddmmyyyy hh24:mi:ss')
--AND substr(TRIM(remark),-10)= '3102643221'
---AND length(remark)>69  --3146451332 
AND remark like '%repo%'



select * from inh_purging.fees_archiving a 
where a.customer_id in (48214305)
AND entdate>= to_date ('01012013 00:00:00','ddmmyyyy hh24:mi:ss') 
AND entdate<= to_date ('11102013 23:59:59','ddmmyyyy hh24:mi:ss')


select ACCION, ESTADO, MSISDN, CICLO , RESPUESTA
from SYSADM.CAP_PCRF_EVENTO e 
where e.msisdn in ('&min') 
order by e.fecha_registro desc;


--Servicios registrados para pago en Maestra de Subcuenta
 
Select customer_id_high, co_id, sncode, fechadesde, porcentaje, firmaco
from  split_contratos 
where co_id = &contrato 


 select * from  MPUSNTAB M       WHERE  UPPER(SNCODE) LIKE '%8135%'; 


--Consulta de referencia de pago por customer_id:

select sysadm.pkg_bscs_ac.REFERENCIA_PAGO(79455327) from dual;

--------- valor de pagos realizados ---------------------
select * from cashreceipts_all where customer_id='183632713';

----Medio de pago de cancelacion de la factura------ 
select caentdate, Carecdate, cachkamt, cabankname
from cashreceipts
where customer_id = '183632713'
order by Carecdate desc;

-------------pagos realizados CFM a FAVOR----------------

SELECT * FROM CUSTOMER_aLL              WHERE CUSTOMER_ID = 167012682;

--------------validar si cliente pago-----------------------

Select * from BMH_REQUEST F where co_id in ('250951565'); 

---- validar el banco donde se realizo pago----------------

select * from  sysadm.bank_all;

----ciclos facturables----
select * from INH_CICLOS where estado= 'ACT';

