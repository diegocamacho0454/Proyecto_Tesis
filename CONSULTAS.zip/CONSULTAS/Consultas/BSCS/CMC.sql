--***************************************************************************************************
-- Valida y corrigue inconsistencias presentadas en varias tablas, entre otras tablas 
-- contr_services, contract_history, storage medium, port.

-- El objetivo es tramitar las inconsistencia que reportan a nuestra area como Linea No registra en QDN
-- transacciones sin fluir.

-- Rechazos RIH

--***************************************************************************************************
-- Luis Edgardo Morales. Sonda. Service Desk. 
-- 2014/06/18
--***************************************************************************************************


DECLARE
   TYPE ARREGLO IS TABLE OF VARCHAR2(20);
   arListado   ARREGLO := ARREGLO(    
&vArreglo
   );
   vcLinea     VARCHAR2(25);
   vcIngresa   VARCHAR2(3):= &Entrada;
   vcProceso   VARCHAR2(3):= &Proceso;
   nmTicket    NUMBER:= &Ticket;
   nmCoId      NUMBER;
   nmSeqNo     NUMBER;
   vcStatus    VARCHAR2(1);
   vcStaDes    VARCHAR2(255);
   vcNewStatus VARCHAR2(255);
   dtFecha     DATE;
   blEstado    BOOLEAN;
   nmRegistro  NUMBER;
   vcRespuesta VARCHAR2(255);
   VcRc        VARCHAR2(10);
   nmTpcp      NUMBER;
   nmTpmd      NUMBER;
   vcSmStatus  VARCHAR(1);
   nmTpCohis   NUMBER;
   nmSecSim    NUMBER;
   vccdsmnum   VARCHAR2(25);
   vcCiCod     NUMBER;
   vcCiNom     VARCHAR2(50);
   idRegistroSeq  NUMBER;
   idDetalleSeq   NUMBER;
   dtfechaHoy     DATE;
   vcuserent   VARCHAR2(20);
   vcterment   VARCHAR2(30);
   nmDnid      NUMBER;
   nmvarlin     NUMBER;
   NmAmdocs    NUMBER;
   vcdesAmd    VARCHAR2(30);
   
--***************************************************************************************************
-- INICIA VALIDACIONES
--***************************************************************************************************
 

 -- Validacion de datos historicos
    
   PROCEDURE prcValidarHistorico(nmCoId   IN NUMBER,
                                 vcStatus OUT VARCHAR2,
                                 dtFecha  OUT DATE) IS
   BEGIN
   
      vcStatus := NULL;
      dtFecha  := NULL;
      
      SELECT a.ch_status , a.entdate
        INTO vcStatus, dtFecha
        FROM sysadm.contract_history a
       WHERE a.co_id = nmCoId
         AND a.ch_seqno = (SELECT MAX(b.ch_seqno)
                             FROM sysadm.contract_history b
                            WHERE b.co_id = a.co_id);
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         NULL;
   END;

-- busqueda del contrato activo por Min.
   
   PROCEDURE prcBuscarDatos(vcMsisdn IN VARCHAR2,
                            nmCoId   OUT NUMBER,
                            nmSeqNo  OUT NUMBER) IS
   BEGIN
      nmCoId  := NULL;
      nmSeqNo := NULL;
      

      SELECT cs.co_id, cs.Cs_Seqno , cs.dn_id
        INTO nmCoId, nmSeqNo , nmDnid
        FROM sysadm.directory_number dn, sysadm.contr_services cs
        WHERE dn.dn_num = vcMsisdn
        AND cs.dn_id = dn.dn_id
        AND (substr(cs.cs_stat_chng, -1) <> 'd' or substr(cs.cs_stat_chng, -1) IS NULL);
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
      NULL;
      WHEN TOO_MANY_ROWS THEN
            DBMS_OUTPUT.put_line(vcMsisdn||' '||nmCoId||' '||'Min asignado a varias lineas Dn_id : '||' '||nmDnid);       
            Nmvarlin := 1;
   END;


-- busqueda del contrato activo por contrato.
  
   PROCEDURE prcBuscarDatos1(vcCoId IN VARCHAR2,
                            nmCoId   OUT NUMBER,
                            nmSeqNo  OUT NUMBER) IS
   BEGIN
      nmCoId  := NULL;
      nmSeqNo := NULL;
      

      SELECT cs.co_id, cs.Cs_Seqno
        INTO nmCoId, nmSeqNo
        FROM sysadm.directory_number dn, sysadm.contr_services cs
        WHERE cs.co_id = vcCoId
        AND cs.dn_id = dn.dn_id
        AND (substr(cs.cs_stat_chng, -1) <> 'd' or substr(cs.cs_stat_chng, -1) IS NULL);
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
     NULL;
      WHEN TOO_MANY_ROWS THEN
            DBMS_OUTPUT.put_line(vcCoId||' '||nmCoId||' '||'Min asignado a varias lineas Dn_id : '||' '||nmDnid);       
            Nmvarlin := 1;
   END;

-- busqueda de lineas Amdocs

   PROCEDURE prcBuscaAmdocs(vcMsisdn IN VARCHAR2,
                            nmCoId   OUT NUMBER,
                            NmAmdocs OUT NUMBER,
                            vcdesAmd OUT VARCHAR2) IS
   BEGIN

      SELECT a.co_id , a.ch_reason, 'Linea Migrada a AMDOCS'
      INTO nmCoId, NmAmdocs, vcdesAmd   
      FROM CONTRACT_HISTORY a 
      WHERE a.ch_reason = '289'
      AND ch_seqno = (SELECT max(ch_seqno)
                      FROM contract_history b
                      WHERE a.co_id = b.co_id)
      AND co_id in (SELECT co_id
                    FROM contr_services
                    WHERE dn_id in (SELECT dn_id
                                    FROM directory_number
                                    WHERE dn_num in (vcMsisdn)));
           EXCEPTION
      WHEN NO_DATA_FOUND THEN
      NULL;
      WHEN TOO_MANY_ROWS THEN
  
          DBMS_OUTPUT.put_line('Min asignado a varias lineas Dn_id : '||' '||nmDnid);       
                      
          
   END;


--***************************************************************************************************
--                                    INICIO PROCEDIMIENTO
--***************************************************************************************************

BEGIN
/*  
   idRegistroSeq := null;
   SELECT sysadm.registro_seq.nextval into idRegistroSeq FROM dual;
   
   INSERT INTO SYSADM.REGISTRO (ID_REGISTRO,USUARIO,MAQUINA,FECHA_REGISTRO,MINES_PROCESADOS) 
   VALUES (idRegistroSeq,vcuserent,vcterment,sysdate,&vArreglo); 
 
   COMMIT;    
*/
   nmRegistro := 0;

 --  SELECT sysadm.registro_seq.nextval into idRegistroSeq FROM dual;

  
   FOR i IN arListado.first .. arListado.last

   LOOP

-- Se valida si la linea fue migrada a Amdocs.

   prcBuscaAmdocs(arListado(i),NmAmdocs,NmAmdocs,vcdesAmd);             

              
-- Traemos las variables de entorno de la sesion.  
 
    SELECT sysdate 
    INTO dtfechaHoy 
    FROM dual;
    
    SELECT user 
    INTO vcuserent
    FROM dual;
    
    SELECT sys_context('USERENV', 'TERMINAL') 
    INTO vcterment
    FROM dual;
    
 --   SELECT sysadm.registro_seq.nextval INTO idRegistroSeq FROM dual;   
 
    Nmvarlin := 0;
    
    IF vcIngresa = 'MIN' THEN
      prcBuscarDatos(arListado(i), nmCoId, nmSeqNo);
    ELSE  
     prcBuscarDatos1(arListado(i), nmCoId, nmSeqNo);
    END IF; 

      IF nmCoId IS NOT NULL THEN
        
--       idDetalleSeq := null;
--       SELECT detalle_registro_seq.nextval into idDetalleSeq FROM dual;

       
      IF VCINGRESA = 'MIN' THEN
        
         NULL;
                
--       INSERT INTO SYSADM.DETALLE_REGISTRO (ID_DETALLE, ID_REGISTRO, MINCOD, CONTRATO, TICKET) 
--       VALUES (idDetalleSeq, idRegistroSeq, arListado(i), nmCoId , nmTicket);    

--        COMMIT;  
               
      ELSE
          
          NULL;
        
--        INSERT INTO SYSADM.DETALLE_REGISTRO (ID_DETALLE, ID_REGISTRO, MINCOD, CONTRATO, TICKET) 
--         VALUES (idDetalleSeq, idRegistroSeq, nmCoId, nmCoId , nmTicket);
         
--         COMMIT;

      END IF;

     prcValidarHistorico(nmCoId, vcStatus, dtFecha);

commit;

   nmTpcp  := NULL;
   nmTpmd  := NULL;
   
--***************************************************************************************************
-- Inicio validaciones para procesos RIH
--***************************************************************************************************
    
   IF vcProceso = 'RIH' THEN
          
-- Valida el ciclo de la linea para el proceso RIH

   SELECT a.billcycle, b.billcycle_desc 
   INTO vcCiCod , vcCiNom 
   FROM customer_all a , billcycles b , contract_all c
   WHERE c.co_id = nmCoId
   AND   a.billcycle = b.billcycle
   AND   a.customer_id = c.customer_id;

DBMS_OUTPUT.put_line('Min '||arListado(i)||' ; '||nmCoId||' ; '||'ciclo ; '||vcCiCod||' ; '|| vcCiNom);      
 
   END IF;                        

--***************************************************************************************************
-- Fin validaciones para procesos RIH
--***************************************************************************************************

-- Valida si tiene transacciones pendientes en mdsrrtab y cap_masivos.

    SELECT count(*) 
    INTO nmTpmd
    FROM MDSRRTAB
    WHERE co_id =  nmCoId
    AND STATUS IN (2,22);
    
    SELECT count(*) 
    INTO nmTpcp
    FROM CAP_MASIVOS
    WHERE co_id =  nmCoId
    AND estado not in ( '2','Q','F','T'); 

-- Valida que el campo ch_pending  este nulo y lo actualiza.

   SELECT count(*) 
   INTO nmTpCohis
   FROM CONTRACT_HISTORY
   WHERE co_id = nmCoId
   AND ch_pending is not null;

   IF vcProceso <> 'RIH' THEN 

            
      IF nmTpcp <> 0 or nmTpmd <> 0 then

       DBMS_OUTPUT.put_line(arListado(i)||' '||nmCoId||' '||'transacciones pendientes');

       ELSIF Nmvarlin = 0 THEN

       DBMS_OUTPUT.put_line(arListado(i)||' '||nmCoId);         

       END IF;

   END IF;           

  
   IF nmTpCohis <> 0 THEN

   UPDATE CONTRACT_HISTORY
   SET ch_pending = NULL
   WHERE co_id = nmCoId
   AND ch_pending IS NOT NULL;

   END IF;

-- Entra colocando las columnas cs_pending_state y cs_pending_param en null.

    UPDATE sysadm.contr_services csa
    SET csa.cs_pending_state = null,
        csa.cs_pending_param = null
    WHERE csa.co_id = nmCoId
    AND  (csa.cs_pending_state IS NOT NULL
    or    csa.cs_pending_param IS NOT NULL );


        IF ( (vcStatus = 'a' or vcStatus = 's')  AND  nmTpmd = 0 and nmTpcp = 0) THEN          

---- *********  Inicia Validaciones de la Contr_services  ****** ---------    


 FOR r IN (SELECT a.sncode, a.cs_stat_chng, a.cs_pending_state, a.cs_activ_date , a.cs_sparam1 , a.tmcode , a.co_id , a.rowid
           FROM sysadm.contr_services a
           WHERE a.co_id = nmCoId
           AND a.cs_seqno = nmSeqNo
           AND (substr(a.cs_stat_chng, -2) IN ('s|') 
           OR substr(a.cs_stat_chng, -1) IN ('s') 
           OR substr(a.cs_stat_chng, -1) IN ('|') 
           OR ( a.cs_sparam1 = '0' AND a.cs_activ_date is NULL)
           OR a.cs_stat_chng is null
           OR a.cs_activ_date is NULL 
           OR a.cs_sparam1 = '0')
           AND a.cs_pending_state IS NULL
        UNION 
          SELECT a.sncode, a.cs_stat_chng, a.cs_pending_state, a.cs_activ_date , a.cs_sparam1 ,a.tmcode , a.co_id , a.rowid
          FROM sysadm.contr_services a
          WHERE a.co_id = nmCoId
          AND a.cs_seqno <> nmSeqNo
          AND a.cs_activ_date is NULL
        UNION    
          SELECT a.sncode, a.cs_stat_chng, a.cs_pending_state, a.cs_activ_date , a.cs_sparam1 , a.tmcode , a.co_id , a.rowid
           FROM sysadm.contr_services a
           WHERE a.co_id = nmCoId
           AND a.cs_seqno = nmSeqNo
           AND  substr(a.cs_stat_chng, -1) IN ('a'))           

          LOOP

          IF substr(r.cs_stat_chng, -1) = '|' THEN

            vcNewStatus := r.cs_stat_chng ||to_char(dtFecha, 'rrmmdd') || vcStatus;
            
            UPDATE sysadm.contr_services a
            SET a.cs_stat_chng = vcNewStatus
            WHERE a.rowid = r.rowid;     
      
--           DBMS_OUTPUT.put_line(' Cadena termina en pipe (|) ' );                            
 
          ELSIF substr(r.cs_stat_chng, -1) = 's' and vcStatus = 'a' THEN -- Cadena Suspendida linea activa.

--DBMS_OUTPUT.put_line('MIN  :'||arListado(i)||' '||'CO_ID   : ' || nmCoId ||' '||vcStatus|| ' '||vcStaDes||' '||' Cadena estado suspendida ');

           vcNewStatus := r.cs_stat_chng || '|' ||to_char(dtFecha, 'rrmmdd') || vcStatus;


           UPDATE sysadm.contr_services a
            SET a.cs_stat_chng = vcNewStatus
            WHERE a.rowid = r.rowid;


--            DBMS_OUTPUT.put_line(' Cadena estado suspendida ' );

 
          ELSIF substr(r.cs_stat_chng, -1) = 'a' and vcStatus = 's' THEN -- Cadena activa linea suspendida.

--DBMS_OUTPUT.put_line('MIN  :'||arListado(i)||' '||'CO_ID   : ' || nmCoId ||' '||vcStatus|| ' '||vcStaDes||' '||' Cadena estado suspendida ');

           vcNewStatus := r.cs_stat_chng || '|' ||to_char(dtFecha, 'rrmmdd') || vcStatus;
                

            UPDATE sysadm.contr_services a
            SET a.cs_stat_chng = vcNewStatus
            WHERE a.rowid = r.rowid;


         ELSIF r.cs_sparam1 = '0' AND r.cs_activ_date is NULL THEN -- RC Incorrecto Y Fecha de activacion nula

--            DBMS_OUTPUT.put_line(' RC Incorrecto y Fecha de activacion nula' ||'    Act: ' || vcRc ); 
            
                                                
            UPDATE sysadm.contr_services a
            SET a.cs_activ_date = dtFecha
            WHERE a.rowid = r.rowid;
      
            SELECT   distinct(sp.params)
            INTO     vcRc 
            FROM     mputmtab mp, services_params sp
            WHERE    mp.status = 'W' 
            AND      mp.tmcode = sp.tmcode 
            AND      mp.tmcode in ( r.tmcode);


            UPDATE sysadm.contr_services a
            SET a.cs_sparam1 = vcRc
            WHERE a.rowid = r.rowid;


          ELSIF r.cs_stat_chng IS NULL THEN -- Cadena nula
                  
            vcNewStatus := to_char(dtFecha, 'rrmmdd') || vcStatus;  
          
--            DBMS_OUTPUT.put_line(' Cadena nula ' );

            UPDATE sysadm.contr_services a
            SET a.cs_stat_chng = vcNewStatus
            WHERE a.rowid = r.rowid;

--            DBMS_OUTPUT.put_line(' Cadena nula  ' ); 

          ELSIF r.cs_activ_date IS NULL THEN -- Fecha de activacion nula
         
--            DBMS_OUTPUT.put_line(' Fecha de activacion nula ' ||'    Act: ' || dtFecha);     

            UPDATE sysadm.contr_services a
            SET a.cs_activ_date = dtFecha
            WHERE a.rowid = r.rowid;

          ELSIF r.cs_sparam1 = '0' THEN -- RC Incorrecto

            vcRc   := NULL;
             
--            DBMS_OUTPUT.put_line(' RC Incorrecto 1' ||'    Act: ' || vcRc||' TMCODE '||R.tmcode );  
          
            SELECT  distinct(sp.params)
            INTO   vcRc 
            FROM  mputmtab mp, services_params sp
            WHERE   mp.status = 'W' 
            AND     mp.tmcode = sp.tmcode 
            AND     mp.tmcode in ( r.tmcode);

            UPDATE sysadm.contr_services a
            SET a.cs_sparam1 = vcRc
            WHERE a.rowid = r.rowid;

            END IF; 
            COMMIT;                     
        END LOOP;
     END IF;
 
---- *********  Finaliza.  Validaciones de la Contr_services  ****** ---------    
 
---- *********  Inicia. Validacion de contr_devices , storage_medium , port. ****** ---------         

-- Desactiva las simcar anteriores a la ultima secuencia.

      
           SELECT a.cd_seqno , a.cd_sm_num
           into nmSecSim , vccdsmnum
           from contr_devices a 
           WHERE cd_seqno =  ( SELECT max(cd_seqno)
                               FROM contr_devices b
                               WHERE a.co_id = b.co_id)         
           AND a.co_id = nmCoId;


 --DBMS_OUTPUT.put_line('Sec de la sim '|| nmCoId ||' ' ||nmSecSim ||' ' || vcSmStatus); 

      FOR Y IN (SELECT   a.cd_seqno, a.cd_sm_num , a.port_id
                from contr_devices a 
                WHERE cd_seqno <> nmSecSim         
                AND a.co_id = nmCoId) 
      LOOP

      IF vccdsmnum <> y.cd_sm_num THEN

      UPDATE storage_medium c
      SET c.sm_status = 'd'
      WHERE c.sm_serialnum = y.cd_sm_num;

      UPDATE port c
      SET c.port_status = 'd'
      WHERE c.port_id = y.port_id;
    
      END IF;

      END LOOP; 

--    IF  nmCtaSer = 1 THEN
   
      FOR x IN (SELECT cd_activ_date , cd_validfrom , cd_entdate , cd_deactiv_date , cd_moddate ,
                b.cd_sm_num , b.port_id , cd_pending_state ,b.rowid
                FROM contr_devices b
                WHERE b.co_id = nmCoId )
     
      LOOP

---- ********* Deja consistente la tabla contr_devices

      IF x.cd_deactiv_date IS NULL AND x.cd_moddate IS NOT NULL THEN
      
         UPDATE contr_devices cd
         SET cd.cd_moddate = NULL
         WHERE co_id = nmCoId
         AND cd_deactiv_date IS NULL
         AND cd.rowid = x.rowid;
               
     END IF;
                 
          IF x.cd_pending_state IS NOT NULL  THEN
         
             UPDATE contr_devices cd
             SET cd.cd_pending_state = NULL
             WHERE co_id = nmCoId
             AND cd_pending_state IS NOT NULL
             AND cd.rowid = x.rowid;
               
          END IF;
                        
         
---- ********* Deja consistente la tabla contr_devices

          IF x.cd_activ_date IS NULL AND x.cd_validfrom IS NOT NULL THEN
          
            UPDATE contr_devices a 
            SET cd_activ_date = x.cd_validfrom
            WHERE co_id = nmCoId
            AND a.rowid = x.rowid;
            
            UPDATE contr_devices a 
            SET cd_entdate = x.cd_validfrom
            WHERE co_id = nmCoId
            AND a.rowid = x.rowid;
                 
          END IF;
          
---- ********* Deja consistente la tabla storage_medium  
 
          update storage_medium c
          set c.sm_entdate = ( select sm_moddate 
                     from storage_medium d
                     where c.sm_serialnum = d.sm_serialnum
                     and d.rowid = c.rowid)
          where c.sm_serialnum = x.cd_sm_num
          and c.sm_status = 'a'
          and c.sm_moddate is not null;


          update storage_medium a
          set sm_moddate = null
          where sm_serialnum = x.cd_sm_num
          and sm_status = 'a'
          and sm_moddate is not null;

---- ********* Deja consistente la tabla port

          update port
          set port_deactiv_date = null
          where port_id = x.port_id
          and port_status in ('a')
          and port_deactiv_date is not null;
          
          update port a
          set port_entdate = ( Select port_moddate
                     from port b
                      where a.port_id = b.port_id
                     and a.rowid = b.rowid)
          where port_id = x.port_id
          and port_status = 'a' 
          and port_moddate is not null;
          
          
          update port a
          set port_moddate = null
          where port_id = x.port_id
          and port_status = 'a';        

          update port a
          set port_activ_date = ( Select port_entdate
                        from port b
                        where a.port_id = b.port_id
                      and a.rowid = b.rowid)
          where port_id = x.port_id
          and port_status = 'd' 
          and  port_activ_date is null;


          update port a
          set port_activ_date = ( Select port_entdate
                        from port b
                        where a.port_id = b.port_id
                      and a.rowid = b.rowid)
          where port_id = x.port_id
          and port_status = 'd' 
          and  port_entdate is not null;
          
          
          update port a
          set port_deactiv_date = ( Select port_moddate
                        from port b
                        where a.port_id = b.port_id
                      and a.rowid = b.rowid)
          where port_id = x.port_id
          and port_status = 'd' 
          and  port_entdate is not null;
          

          COMMIT;
      END LOOP;  


      ELSIF NmAmdocs = 289 THEN

DBMS_OUTPUT.put_line(arListado(i)||' '||nmCoId||' '||vcdesAmd);       

      ELSE

DBMS_OUTPUT.put_line('Min '||' '||arListado(i)||' '||'CO_ID   : ' || nmCoId||'  '||' Linea desactivada � Cambio de Min !!!'); 
 

       END IF;

END LOOP;

COMMIT;

DBMS_OUTPUT.put_line('------------------- PROCESO TERMINADO -------------------------');
DBMS_OUTPUT.put_line('---------------------------------------------------------------');  
EXCEPTION
 WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Error en Entrada '||vcIngresa||SQLCODE||'='||substr(SQLERRM, 1, 500));
END;
