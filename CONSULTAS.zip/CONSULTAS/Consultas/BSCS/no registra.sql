/*select CODMIN,trajo_equipo, tipo_contrato, FECREGIS, ESTADO, IMEI
from ACTIVACION@activa
where codmin in ('3166935311');*/

select a.CODMIN, a.trajo_equipo, a.tipo_contrato, a.FECREGIS, a.ESTADO, a.id_activacion, a.IMEI 
from ACTIVACION@activa a
where codmin in (
);


SELECT * from sysadm.inh_promocion_cfm_pol WHERE co_id IN (SELECT co_id
                                                        FROM contr_services   a,
                                                             directory_number b
                                                       WHERE a.dn_id = b.dn_id
                                                         AND b.dn_num in ('3113501276','3114228880'));

                            
------------------------Promociones------------------------------

select *
     from sysadm.perm_usuarios      p,
          sysadm.perm_camp_usuarios c,
          sysadm.perm_campana       a,
          Sysadm.Directory_Number dnu,
          sysadm.contr_services      se
    where p.customer_id in ('39030546')
      and p.id = c.id_usuario
      and c.id_campana = a.id
      and p.co_id=se.co_id
      and se.dn_id = dnu.dn_id
      and c.id_campana = 1650;
---activacion de campa�a-----
SELECT CUSTOMER_ID,
       --TICKLER_NUMBER,
       TICKLER_CODE,
       --TICKLER_STATUS,
       --CREATED_BY,
       CREATED_DATE,
       --CLOSED_DATE,
       SHORT_DESCRIPTION,
       LONG_DESCRIPTION,
       X_COORDINATE
       --Y_COORDINATE
FROM TICKLER_RECORDS
WHERE TICKLER_CODE IN ('CAMPAACT')
--anD TICKLER_RECORDS.SHORT_DESCRIPTION IN ('NAVEGACION POR DEMAN')
--and follow_up_date BETWEEN
  --  TO_DATE('&FECHAINICIAL:00:00:00','dd/mm/yyyy:hh24:mi:ss') and
  --  TO_DATE('&FECHAFINAL:23:59:59','dd/mm/yyyy:hh24:mi:ss')
AND TICKLER_RECORDS.CUSTOMER_ID in ('21697465');
