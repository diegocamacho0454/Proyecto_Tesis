-----------Consulta de cargue de OCCs-------------

SELECT f.seqno, f.*
                                    FROM sysadm.FEES f
                                    WHERE f.customer_id in
  (
'79229260',
'254936440',
'20128513'

)
AND f.entdate>= to_date ('31102019 00:00:00','ddmmyyyy hh24:mi:ss') 
AND f.entdate<= to_date ('12122019 00:00:00','ddmmyyyy hh24:mi:ss');
