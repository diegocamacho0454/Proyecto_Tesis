SELECT *
  FROM inh_prom_ejeusuarios  
WHERE co_id -- = 66466390;
       IN ((SELECT a.co_id
             FROM contr_services a
             JOIN (SELECT dn_num, dn_id
                    FROM directory_number
                   WHERE dn_num in ('3128931665')) b
               ON (a.dn_id = b.dn_id)));



select costcenter_id from customer_all where customer_id = 12668054;

select * from sysadm.costcenter where cost_id = 100038;

--ONG

select * from TAX_EXEMPT
where customer_id = 139842524; 

