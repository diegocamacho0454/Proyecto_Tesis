-----Validacion trazabilidad Roaming-----


select * from sysadm.roaming_autorizacion r
where r.co_id = 292896420;

select * from sysadm.roaming_autorizacion_hist r
where r.co_id = 292896420;
