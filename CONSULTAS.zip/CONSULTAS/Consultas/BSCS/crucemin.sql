---------- CRUCE DE MINES ----------
SELECT TAREA_ID,
       PROCESO_STATUS,
       FECHA_INICIO,
       PROCESO_ERRORES,
       USUARIORED,
       DESC_CORTA,
       DESC_USUARIO
  FROM sysadm.ex_batch_Tareas
 WHERE usuariored = 'ICO6496A';

-- and proceso_errores like '%3127587110%' ORDER BY TAREA_ID desc; 

---------- CAMBIO DE MIN ----------
select * from SYSADM.INH_INFO_CAMBIOMIN where co_id = '238336113';

----consulta para validar zona del min-----

select n.dn_num,n.hlcode zona_min, p.hlcode zona_iccid,s.sm_serialnum sm_iccid,c.port_id puerto,c.cd_port_num imsi,
     sysadm.fnc_buscar_dnhlcode(c.co_id) Zona_IMSI
from contr_devices     c
   ,port             p
   ,storage_medium   s
   ,contr_services   se
   ,directory_number n  
where n.dn_num =any('3223676834') 
--c.co_id = 178084075
and c.cd_deactiv_date is null
and  p.port_id = c.port_id
and  s.sm_id = p.sm_id
and  se.co_id = c.co_id
and  se.dn_id = n.dn_id
and  se.cs_deactiv_date is null;

---------VALIDAR ZONA-----------------

SELECT a.dn_num, a.dn_status, a.dn_status_requ, a.hlcode  
FROM directory_number a 
WHERE a.dn_num IN ('3223676834');

---proceso para cambio de Zona min portado---
sysadm.pkg_util_sop.pr_soporte_cambio_zona_min;

-----validar HLR---
select h.stp, h.hlrcode, h.hlnom, h.alias_conm, h.global_title
  from inh_hlr h --where global_title in ('573206004014');
 order by 1;
----destino port out---
select p.sncode NRN, p.indicador NRN_PM, p.descripcion DESTINO
  from inh_param_servicios p
 where p.tipo_proc = 15;

select *
  from inh_mindescuento
 where co_id in (select co_id
                   from contr_services a
                  where dn_id in (select dn_id
                                    from directory_number
                                   where dn_num in ('3133628167'))
                    and substr(a.cs_stat_chng, -1) <> 'd');
