select * from sysadm.INH_DATOS_APN_contrato co
where co.msisdn in ('3102577348')
and codigo_apn = '270';

--pruebas de Log's en APN's

Select * from inh_datos_apn_log_1 where codigo_apn = 743;

Select a.* from Sysadm.INH_DATOS_APN_AUDITA a where MSISDN = 3112081255 and codigo_apn in ('727', '704', '743');




--- cambiar status apn---
/*UPDATE sysadm.INH_DATOS_APN_contrato co
SET co.status = 1
where codigo_apn = 270
and co.msisdn in ('3102577348');
*/

select*
from sysadm.INH_DATOS_APN_contrato co
where codigo_apn = 270
and co.msisdn in ('3102577348')
;

select c.*, i.ip, i.status
from sysadm.INH_DATOS_APN_contrato c, sysadm.INH_DATOS_APN_ip i 
where c.codigo_apn = i.codigo_apn
and c.codigo_ip = i.codigo_ip
and c.codigo_apn = 270
and c.msisdn in (

'3102594586'

);



---- Borrar registros 

/*delete from sysadm.INH_DATOS_APN_contrato c 
where c.codigo_apn = 719
and c.codigo_ip in ('953192');

--; */

select *
from sysadm.INH_DATOS_APN_contrato c 
where c.codigo_apn = 270
and c.codigo_ip in ('1252267');


------- VERIFICACION RANGO IP -------------
select* from sysadm.INH_DATOS_APN_ip i 
where i.codigo_apn = 226
and i.ip like '10.93.94.1%';

select* from sysadm.INH_DATOS_APN_ip i
where i.codigo_apn = 920
and  i.ip between '10.93.94.1'and'10.93.94.254';

----Validar el valor maximo del codigo_IP-----

select * from sysadm.INH_DATOS_APN_ip i 
WHERE codigo_ip = (SELECT MAX(codigo_ip) FROM sysadm.INH_DATOS_APN_ip i)
ORDER BY codigo_ip;


/*delete from sysadm.INH_DATOS_APN_ip i
where i.codigo_apn = 719;*/

select * from sysadm.INH_DATOS_APN_ip d --- 
where d.codigo_apn = 9
and d.status = 0 
and d.codigo_ip in('167194');

------- reserva IP --------------
/*
update sysadm.INH_DATOS_APN_ip d
set d.status = 1
where d.codigo_apn = 9
and d.codigo_ip in ('994289');*/



select * from sysadm.INH_DATOS_APN_contrato c  
where c.codigo_ip in ('994289',
'994295',
'994297');

------NIT APN------
select * from sysadm.INH_DATOS_APN_nit n
where n.codigo_apn = 719
and n.nit in ('830025600')
;

/*DELETE from sysadm.INH_DATOS_APN_nit n
where n.codigo_apn = 719
and n.nit in ('900122930');
*/

--CAMBIO APN DINAMICA A FIJA---

/*update sysadm.INH_DATOS_APN
set ip_fija = 1
where codigo_apn = 80*/

select * from sysadm.INH_DATOS_APN n
where n.desc_apn like '%elechuila.claro.com.co%'

/*delete from sysadm.INH_DATOS_APN n
where  n.codigo_apn = '719'*/




----------Cambio c�digo IP-------------
/*
update sysadm.INH_DATOS_APN_contrato
set codigo_ip ='994289'  
where codigo_apn = 9
and MSISDN = 3232103909
*/
;

select c.*, i.ip, i.status
from sysadm.INH_DATOS_APN_contrato c, sysadm.INH_DATOS_APN_ip i 
where c.codigo_apn = i.codigo_apn
and c.codigo_ip = i.codigo_ip
and i.ip like '%10.93.94.1%';
and c.codigo_apn = 49
and c.msisdn in ('3103775498');

---------------- APN -----------------
select c.*, i.ip, i.status
from sysadm.INH_DATOS_APN_contrato c, sysadm.INH_DATOS_APN_ip i
where c.codigo_apn = i.codigo_apn
and c.codigo_ip = i.codigo_ip
and c.codigo_apn = 226
and c.codigo_ip in ('467185');


