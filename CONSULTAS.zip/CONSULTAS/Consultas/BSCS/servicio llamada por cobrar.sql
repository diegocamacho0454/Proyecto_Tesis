----------- llamadas por cobrar-----

Select * from mpulktmb 
where tmcode in ('19580')
and sncode in ('8256')
and spcode in ('4103')         
order by 1 desc          

;

 
--Obtener sncode:

Select * from mpusntab n
where des like '%cobrar%'; 
--where n.sncode in ('9872')
order by 1 asc;

--Obtener spcode:
Select * from mpusptab
Where des like '%DATOS GPRS%';  
where spcode IN ('4103') ;
