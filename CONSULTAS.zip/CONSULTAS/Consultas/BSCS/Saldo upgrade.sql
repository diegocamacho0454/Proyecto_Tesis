Select * from inh_upgamx_tabcontrol where msisdn = '3114489624';

-- Upgrade no traslada recarga

-- Verificar en la Base de Datos de ACTIVA en la tabla ACTIVACION el campo ID_ACTIVACION

select  a.codmin,a.estado,a.id_activacion
from activacion a
where a.codmin ='3114489624';

/*De aqu� tomamos el ID_ACTIVACION y verificamos en la tabla ACTIVACION_UPGRADE_SALDO, 
en esta tabla consultamos el saldo que reporto la plataforma prepago en su momento.*/

select * from extranet.activacion_upgrade_saldo b
where b.id_activacion ='115528365'
;

--Si el saldo no es el que se visualiza en CMAX, se le debe escalar  a GSAC_POLIEDRO.
--Si el saldo es el correcto se debe escalar a GFPT_SERV_INCONS
