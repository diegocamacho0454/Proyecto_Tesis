--Validacion inicial de Min's cargados

Select count(*) from fpbmh.inh_validacion_mines;

--Validar PORT IN efectuadas

SELECT COUNT(1)
FROM FPBMH.INH_VALIDACION_MINES A, DIRECTORY_NUMBER B
WHERE B.DN_NUM = A.MSISDN;

--validar PORT OUT efectuadas

select COUNT(1)
from sysadm.cap_ported_out a
where trunc(a.fecha) = trunc (sysdate);
