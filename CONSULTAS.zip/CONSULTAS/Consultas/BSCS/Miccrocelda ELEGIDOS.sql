---------------- DATOS LINEA -----------------
select ca.customer_id, cs.co_id, dn.dn_num 
from contract_all ca, contr_services cs, directory_number dn 
where ca.co_id = cs.co_id 
and cs.dn_id = dn.dn_id 
and substr(cs.cs_stat_chng, -1) <> 'd' 
and dn.dn_num in (

'3206268575'

);

---------------- SERVICIOS  -----------------
select m.sncode,
       m.DES,
       m.sncode,
       c.spcode,
       c.tmcode,
       cs_seqno,
       cs_stat_chng,
       (select des
          from MPUTMTAB
         where tmcode = c.tmcode
           and status = 'W') Plan_Tarifario,
       C.*
  from CONTR_SERVICES C, MPUSNTAB M
  where m.sncode = c.sncode
  and co_id = 292987234
  order by c.cs_seqno DESC, 2, c.sncode;

---------------- MICROCELDAS  -----------------
SELECT t.tmcode, t.spcode, t.prepago, t.tecnologia, t.microcelda
FROM INH_TMSP_PREP T WHERE TMCODE = 23116;

---------------- TEST -----------------
INH_ELEGIDOS_NEW.PKG_ELEGIDOS.Eliminar_Contrato;

---------------- ELEGIDOS -----------------
SELECT A.*, ROWID  FROM INH_ELEGIDOS_NEW.INH_ELEGIDOS A WHERE CO_ID = '292987234';
