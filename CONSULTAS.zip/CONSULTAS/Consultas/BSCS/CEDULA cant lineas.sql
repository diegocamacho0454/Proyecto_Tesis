---- Consultar la cedula de la cantidad de l�neas ---
Select * from sysadm.inh_equipo_financiado where passportno in (1004047183);

---
INSERT INTO sysadm.inh_equipo_financiadoHIS(SELECT * FROM sysadm.inh_equipo_financiado e WHERE e.repof_id IN(5699830));
---
DELETE sysadm.inh_equipo_financiado e  WHERE e.repof_id IN (5699830);
