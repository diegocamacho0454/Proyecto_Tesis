/* Se debe validar en las dos consultas si no arroja informacion en las dos se cierra*/

-----Validar documento----------
select * from billing.TMCODEVSCAMP
WHERE TMCODE  IN ' ';

--------Validar documento tenga info--------

select * from billing.Base_Usuarios_Hogar d
where d.documento = '13468078';
