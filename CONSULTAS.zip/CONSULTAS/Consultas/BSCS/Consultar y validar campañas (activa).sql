--- consultas activa----
select a.CODMIN, a.trajo_equipo, a.tipo_contrato, a.FECREGIS, a.ESTADO, a.id_activacion, a.imei
from ACTIVACION@activa a
where codmin in (

'3214074122'




);

---- Validar campa�a activa
select c.*, c.rowid
from extranet.cpng_campanaxactivacion@activa.world c
where c.idactivacion in ( 

'101428651'

);
