-----------------------consultar todas las l�neas que est�n inscritas en una maestra.---------------

SELECT  customer_id FROM CUSTOMER_ALL a WHERE a.custcode in ('8.22002551')

; 



select * from sysadm.customer_all a where a.customer_id_high = '115312655' and a.cstype='a'; 


from customer_all ca, contract_all co, contr_services cs, directory_number dn
where ca.customer_id in ('50984780')--= &customer_id
and co.customer_id = ca.customer_id
and cs.co_id = co.co_id
and dn.dn_id = cs.dn_id;

---------------------------------------------------------------------------
SELECT '&nit', A.CO_ID, C.DN_NUM, A.CUSTOMER_ID   
  FROM SYSADM.CONTRACT_ALL     A,
       SYSADM.CONTR_SERVICES   B,
       SYSADM.DIRECTORY_NUMBER C, 
       INH_TMSP_PREP           D
WHERE B.DN_ID = C.DN_ID
   AND B.CO_ID = A.CO_ID
   AND A.TMCODE = D.TMCODE
   AND PREPAGO NOT IN (0, 3)
   AND SUBSTR(B.CS_STAT_CHNG, -1) <> 'd'
   AND CUSTOMER_ID IN
       (SELECT CUSTOMER_ID
          FROM SYSADM.CUSTOMER_ALL
         WHERE CUSTOMER_ID_HIGH IN (SELECT CUSTOMER_ID
                                      FROM SYSADM.CUSTOMER_ALL
                                     WHERE PASSPORTNO = '&nit'
                                       AND CSLEVEL = 10)
        UNION ALL 
        SELECT CUSTOMER_ID
          FROM SYSADM.CUSTOMER_ALL
         WHERE CUSTOMER_ID_HIGH IS NULL
           AND PASSPORTNO = '&nit'
           AND CSLEVEL = 40);

---------------------

SELECT /*+RULES*/ CUSTOMER_ALL.paymntresp SPLITB, MAX(CCONTACT_ALL.CCSEQ) VER, DIRECTORY_NUMBER.DN_NUM MIN, CCONTACT_ALL.ccline2 NOMBRE, CUSTOMER_ALL.CUSTCODE CUSTCODE, contr_services.cs_stat_chng FECHAS_CAMBIOS,
    --(substr(contr_services.cs_stat_chng,case when length(contr_services.cs_stat_chng) < 31 then length(contr_services.cs_stat_chng)*-1 else -31 end)) FECHA_CAMBIOS,
    MAX(MPULKTMB.ACCESSFEE) CFM, mputmtab.des DES_PLAN, contract_all.CO_CRD_CLICKS_DAY MINUTOS, CUSTOMER_ALL.PREV_BALANCE CARGOS_MESE_ANTER,CUSTOMER_ALL.CUSTOMER_ID CUSTOMER_ID, CONTR_SERVICES.co_id CO_ID, contr_services.tmcode TMCODE, contr_services.spcode  PQTE, CCONTACT_ALL.ccline4 DIR,  CCONTACT_ALL.ccline5 ciudad, CUSTOMER_ALL.billcycle CICLO, CUSTOMER_ALL.PASSPORTNO NIToCC, CUSTOMER_ALL.CUSTOMER_ID_HIGH
    FROM  DIRECTORY_NUMBER DIRECTORY_NUMBER, MPUTMTAB MPUTMTAB, CONTRACT_ALL CONTRACT_ALL, CONTR_SERVICES CONTR_SERVICES, CUSTOMER_ALL CUSTOMER_ALL, CCONTACT_ALL CCONTACT_ALL, MPULKTMB MPULKTMB
    WHERE    DIRECTORY_NUMBER.DN_ID = CONTR_SERVICES.DN_ID AND CONTR_SERVICES.TMCODE = MPUTMTAB.TMCODE
    AND CONTR_SERVICES.CO_ID = CONTRACT_ALL.CO_ID AND CONTRACT_ALL.CUSTOMER_ID = CUSTOMER_ALL.CUSTOMER_ID
    AND CONTRACT_ALL.CUSTOMER_ID = CCONTACT_ALL.CUSTOMER_ID
    AND MPULKTMB.tmcode = CONTR_SERVICES.tmcode AND MPULKTMB.spcode = CONTR_SERVICES.spcode
    AND MPULKTMB.SNCODE = CONTR_SERVICES.SNCODE
    AND CCONTACT_ALL.CCBILL='X'
    AND ((SUBSTR(contr_services.cs_stat_chng,-1) IN ('a')) OR (SUBSTR(contr_services.cs_stat_chng,-7) LIKE ('0503%d')) OR (SUBSTR(contr_services.cs_stat_chng,-7) LIKE ('0504%d')))
    AND CUSTOMER_ALL.passportno in ('800251569')
    GROUP BY  CUSTOMER_ALL.paymntresp,CCONTACT_ALL.CCSEQ, DIRECTORY_NUMBER.DN_NUM, CCONTACT_ALL.ccline2, CUSTOMER_ALL.CUSTCODE,
    mputmtab.des, contr_services.cs_stat_chng, contract_all.CO_CRD_CLICKS_DAY, CUSTOMER_ALL.PREV_BALANCE, CUSTOMER_ALL.CUSTOMER_ID,
    CONTR_SERVICES.co_id, contr_services.tmcode, contr_services.spcode, CCONTACT_ALL.ccline4, CCONTACT_ALL.ccline5,CUSTOMER_ALL.billcycle,  
    CUSTOMER_ALL.PASSPORTNO, CUSTOMER_ALL.CUSTOMER_ID_HIGH
    ORDER BY  DIRECTORY_NUMBER.DN_NUM, contr_services.cs_stat_chng  asc
    
    ;

-- Referencia de Equipo ---
SELECT * FROM SYSADM.INH_REL_EQU_SER S WHERE S.CUSTOMER_ID_SERVICIO in
(
 '238488756',
'238607700',
'236788391',
'177137477'
)
; 

--- Validar el OCC creado con el periodo y valor de la cuota --- 
SELECT * FROM SYSADM.FEES f WHERE F.CUSTOMER_ID = '238587466' 
; --- EQUIPO 

