--------------------------------------- REVISION DE LA LINEA -------------------------------------------------------
SELECT A.CO_ID, FUNC_CAP_CO_ID_GSM(CO_ID,'MIN',3005) MIN,   FUNC_CAP_CO_ID_GSM(CO_ID,'IMSI',3005) IMSI,
FUNC_CAP_CO_ID_GSM(CO_ID,'HLR',NULL)  HLR,          FUNC_CAP_CO_ID_GSM(CO_ID,'SERV',3013) ACT,
FUNC_CAP_CO_ID_GSM(CO_ID,'RCAT',NULL) RC,           FUNC_CAP_CO_ID_GSM(CO_ID,'PLPR',NULL) TIPOPLAN,
FUNC_CAP_CO_ID_GSM(CO_ID,'CIC',3005) CIC,           A.STATUS  ,A.REF_TEXT, A.USERID, A.INSERT_DATE, A.TS, A.*, rowid 
FROM SYSADM.MDSRRTAB A WHERE CO_ID   IN (SELECT CO_ID  FROM CONTR_SERVICES WHERE DN_ID IN (
SELECT D.DN_ID FROM DIRECTORY_NUMBER D WHERE DN_NUM  IN ('3215097514'))) ORDER BY REQUEST DESC;  

------- cd deact u MON_DATE NO VACIOS ------
Select cd_seqno ,co_id , cd_port_num, cd_activ_date , cd_validfrom , cd_entdate , cd_deactiv_date , cd_moddate ,
decode(substr(cd_sm_num,8,1),0,'Oriente',1,'Occidente',2,'Costa',4,'Oriente') Zona,
''''||cd_sm_num||''''||',' , ''''||port_id||''''||','  , 
cd_status ,  cd_pending_state 
from contr_devices a 
where co_id in (296684514)           
--WHERE cd_sm_num like '8957101101510974590%' -- modem hitts
--and cd_pending_state is not null
--and cd_activ_date is null
order by CO_ID,cd_seqno asc;

--------- storage medium --------

 Select  
             sm_id, sm_serialnum , sm_status , sm_entdate , sm_moddate
             from storage_medium
             where sm_serialnum in (
'89571015022049050520',
'89571015022053405099'

   )
Order by SM_STATUS ASC

;
             



---- PORT ---- Para la sim activa (a) PORT_DEACTIV_DATE - PORT_MODDATE deben ser NULL

       select port_id , p.sm_id, port_num , port_status , port_activ_date , port_deactiv_date , port_entdate , port_moddate
       from port p
       where port_id  in(
'330359807',
'330795264'

)
ORDER BY PORT_STATUS ASC



Update contract_history set CH_REASON=32 WHERE REQUEST='2550742230' AND CO_ID='31203451';
