------------------------  CONSULTA DE LINEAS QUE TIENEN CAMPA�A----------------------------------------

DECLARE
    TYPE ARREGLO IS TABLE OF VARCHAR2(20);
    ARLISTADO     ARREGLO:= ARREGLO(&ARREGLO);
    VC_MIN        VARCHAR2(10);
    NMCOID        NUMBER;
    NMCAMPANA     NUMBER;
    VC_FEC_INICIO DATE;
    VC_FEC_VENCE  DATE;
    VC_DFALTANTES NUMBER;
    VC_PATRON     NUMBER;
    NMESTADO      NUMBER;
    NMID          NUMBER;
    NMPATRON      NUMBER;
    VC_COUNT      NUMBER;
BEGIN
 dbms_output.enable(null);
 
    DBMS_OUTPUT.PUT_LINE('LINEA' || ',' || 'CO_ID' || ',' ||
                         'CODIGO DE LA CAMPA�A' || ',' ||
                         'DURACION CAMPA�A' || ',' || 'FECHA INICIO' || ',' ||
                         'ESTADO ACTUAL' || ',' || 'FECHA VENCIMIENTO' || ',' ||
                         'ANALISIS'||'DIAS');
    FOR I IN ARLISTADO.FIRST .. ARLISTADO.LAST LOOP
    VC_MIN:= ARLISTADO(I);
        BEGIN      
              SELECT COUNT(1) 
                            INTO VC_COUNT
              FROM (SELECT  
                     DISTINCT U.CO_ID,
                                CU.ID_CAMPANA,
                                TRUNC(CU.FECHA_INICIO_PROM) FECHA_INICIO,
                                AA.ID,
                                CU.ESTADO
              --INTO VC_COUNT
              FROM SYSADM.PERM_CAMP_USUARIOS  CU,
                   SYSADM.PERM_USUARIOS       U,
                   SYSADM.PERM_CAMPANA        PP,
                   SYSADM.PERM_PERIODICIDAD   AA,
                   SYSADM.PERM_CAMP_BENEFICIO CB,
                   SYSADM.PERM_BENEFICIO      BB,
                   SYSADM.CONTR_SERVICES      SE,
                   SYSADM.CUSTOMER_ALL        CA,
                   SYSADM.DIRECTORY_NUMBER    DNU
             WHERE DNU.DN_NUM = ARLISTADO(I)
               AND CU.ID_USUARIO = U.ID
               AND U.CUSTOMER_ID = CA.CUSTOMER_ID
               AND PP.ID = CU.ID_CAMPANA
               AND CB.ID_CAMPANA = PP.ID
               AND CB.ID_BENEFICIO = BB.ID
               AND BB.PERIORICIDAD = AA.ID
               AND U.CO_ID = SE.CO_ID
               AND SE.DN_ID = DNU.DN_ID
               AND CU.ESTADO = 1)DATOS;
        IF VC_COUNT >0 THEN
            FOR COUNT_C IN 1 .. VC_COUNT LOOP
            
                SELECT DATOSS.CO_ID,DATOSS.ID_CAMPANA,DATOSS.FECHA_INICIO,DATOSS.ID,DATOSS.ESTADO 
                INTO NMCOID, NMCAMPANA, VC_FEC_INICIO, NMID, NMESTADO
                FROM (
                SELECT DATOS.*,ROWNUM AS FILA FROM (SELECT  
                       DISTINCT U.CO_ID,
                                CU.ID_CAMPANA,
                                TRUNC(CU.FECHA_INICIO_PROM) FECHA_INICIO,
                                AA.ID,
                                CU.ESTADO
                FROM SYSADM.PERM_CAMP_USUARIOS  CU,
                   SYSADM.PERM_USUARIOS       U,
                   SYSADM.PERM_CAMPANA        PP,
                   SYSADM.PERM_PERIODICIDAD   AA,
                   SYSADM.PERM_CAMP_BENEFICIO CB,
                   SYSADM.PERM_BENEFICIO      BB,
                   SYSADM.CONTR_SERVICES      SE,
                   SYSADM.CUSTOMER_ALL        CA,
                   SYSADM.DIRECTORY_NUMBER    DNU
             WHERE DNU.DN_NUM = ARLISTADO(I)
               AND CU.ID_USUARIO = U.ID
               AND U.CUSTOMER_ID = CA.CUSTOMER_ID
               AND PP.ID = CU.ID_CAMPANA
               AND CB.ID_CAMPANA = PP.ID
               AND CB.ID_BENEFICIO = BB.ID
               AND BB.PERIORICIDAD = AA.ID
               AND U.CO_ID = SE.CO_ID
               AND SE.DN_ID = DNU.DN_ID
               AND CU.ESTADO = 1)DATOS)DATOSS
               WHERE FILA =COUNT_C;  
           
        BEGIN
            SELECT COUNT(1)
              INTO VC_COUNT
              FROM (SELECT TRIM(COLUMN_VALUE) PATRON
                      FROM SYSADM.PERM_PERIODICIDAD AA,
                           XMLTABLE(('"' || REPLACE(PATRON, ',', '","') || '"'))
                     WHERE AA.ID = NMID);
            FOR I IN 1 .. VC_COUNT LOOP
                IF I = VC_COUNT THEN      
                    SELECT DATOS.PATRON
                      INTO NMPATRON
                      FROM (SELECT TRIM(COLUMN_VALUE) PATRON, ROWNUM AS FILA
                              FROM SYSADM.PERM_PERIODICIDAD A,
                                   XMLTABLE(('"' ||
                                            REPLACE(PATRON, ',', '","') || '"'))
                             WHERE A.ID = NMID) DATOS
                     WHERE DATOS.FILA = VC_COUNT;
                
                    SELECT ADD_MONTHS(TO_DATE(VC_FEC_INICIO, 'DD/MM/YY'),
                                      NMPATRON) FECHA_VENCE,
                           (ADD_MONTHS(TO_DATE(VC_FEC_INICIO, 'DD/MM/YY'),
                                       NMPATRON) - TRUNC(SYSDATE)) DIAS_FALTANTES
                      INTO VC_FEC_VENCE, VC_DFALTANTES
                      FROM DUAL;
                END IF;
            END LOOP;
        END;
    
        IF NMCOID IS NOT NULL AND VC_DFALTANTES <= 0 AND NMESTADO = 1 THEN
        
            DBMS_OUTPUT.PUT_LINE(ARLISTADO(I) || ',' || NMCOID || ',' ||
                                 NMCAMPANA || ',' || NMPATRON || ',' ||
                                 TO_CHAR(VC_FEC_INICIO, 'DD/MM/YYYY') || ',' ||
                                 NMESTADO || ',' ||
                                 TO_CHAR(VC_FEC_VENCE, 'DD/MM/YYYY') || ',' ||
                                 'CAMPA�A VENCIDA SE DEBE DESACTIVAR');
            ELSIF NMCOID IS NOT NULL AND VC_DFALTANTES > 0 AND NMESTADO = 1 THEN  
            DBMS_OUTPUT.PUT_LINE(ARLISTADO(I) || ',' || NMCOID || ',' ||
                                 NMCAMPANA || ',' || NMPATRON || ',' ||
                                 TO_CHAR(VC_FEC_INICIO, 'DD/MM/YYYY') || ',' ||
                                 NMESTADO || ',' ||
                                 TO_CHAR(VC_FEC_VENCE, 'DD/MM/YYYY') || ',' ||
                                 VC_DFALTANTES);
            
ELSIF VC_FEC_INICIO IS NULL THEN 
             DBMS_OUTPUT.PUT_LINE(VC_MIN || ',' || NMCOID || ',' ||
                                 NMCAMPANA || ',' || NMPATRON || ',' ||
                                 TO_CHAR(VC_FEC_INICIO, 'DD/MM/YYYY') || ',' ||
                                 NMESTADO || ',' ||
                                 TO_CHAR(VC_FEC_VENCE, 'DD/MM/YYYY') || ',' ||
                                 'FECHA INICIO VACIA');
        END IF;
 END LOOP;
 ELSE  DBMS_OUTPUT.PUT_LINE(VC_MIN ||',,,,,,,'||
                                 'NO TIENE CAMPA�A');
 END IF;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
              NMCOID:= NULL;
        END;
    END LOOP; 
END;
