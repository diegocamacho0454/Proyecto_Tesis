---------------- DATOS LINEA -----------------
select ca.customer_id, cs.co_id, dn.dn_num 
from contract_all ca, contr_services cs, directory_number dn 
where ca.co_id = cs.co_id 
and cs.dn_id = dn.dn_id 
and substr(cs.cs_stat_chng, -1) <> 'd' 
and dn.dn_num in (
'3215097514'
);


---- validacion de suspension linea  por legalizacion --------------

select co_id, text04, text23, text30, rowid FROM info_contr_text i where i.co_id in ('296684514');

Select func_cap_co_id_gsm(i.CO_ID,'MIN',3013)MIN, i.co_id i.text04, i.text23, i.text30 from info_contr_text i 
where i.co_id in (296684514);
