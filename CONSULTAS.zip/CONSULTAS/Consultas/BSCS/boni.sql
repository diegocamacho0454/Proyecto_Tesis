select * from cashreceipts_all where customer_id='236120516';
