select * from sysadm.inh_datos_apn_contrato where codigo_apn = 7 and codigo_ip =9428  ;

---Extracion de Informacion APN's vs NIT--------
select * from sysadm.inh_datos_apn a, sysadm.inh_datos_apn_nit co where a.Codigo_apn = co.codigo_apn;

select * from sysadm.inh_datos_apn a, sysadm.inh_datos_apn_nit co where a.Codigo_apn = co.codigo_apn;

------- VERIFICACION CODIGO APN -------------
select * from sysadm.inh_datos_apn a, sysadm.inh_datos_apn_nit co, sysadm.INH_DATOS_APN_contrato ca, sysadm.INH_DATOS_APN_ip i
where a.codigo_apn = co.codigo_apn
and a.desc_apn like '%static.comcel.com.co';
--and ca.msisdn in ( '3115610158' );

------listado de ip por min--------------------------------
select c.*, i.*
from sysadm.INH_DATOS_APN_contrato c, sysadm.INH_DATOS_APN_ip i
where c.codigo_apn = i.codigo_apn
and c.codigo_ip = i.codigo_ip
and c.codigo_apn = 49
and c.msisdn in (
'3124500518'

);

--- SE REALIZA VALIDACION DE LAS IP DUPLICADAS
select c.*, i.ip, i.status
from sysadm.INH_DATOS_APN_contrato c, sysadm.INH_DATOS_APN_ip i 
where c.codigo_apn = i.codigo_apn
and c.codigo_ip = i.codigo_ip
--and i.ip like '%10.85.49.33%'
and c.codigo_apn = 49
and c.codigo_ip in (
'166818',
'167873'

)
for update;
--and c.msisdn in  ('3132966046');

-----Validar disponibilidad-----------
select * from sysadm.INH_DATOS_APN_ip d
where d.codigo_apn = 49
and d.status = 0
;   

----***********************--
--- no debe arrojar informacion
select * from sysadm.INH_DATOS_APN_contrato c 
where c.codigo_ip in (
'167873'



);   


-------Reserva codigo ip
/*
update sysadm.INH_DATOS_APN_ip d
set d.status = 1
where d.codigo_apn = 49
and d.codigo_ip in (
'167873'

);

*/

----Validar cambio de status--------
select * from sysadm.INH_DATOS_APN_ip d
where d.codigo_apn = 49
--and d.status = 0
and d.codigo_ip in (
'167873'


)
;   


-------Asignacion nueva IP-----------------------
update sysadm.INH_DATOS_APN_contrato a set a.codigo_ip = '167873'
--set a.status = '1' 
where  a.codigo_apn = '49'
and a.codigo_ip = '166818'
and a.msisdn = '3124500518';


Select a.*, rowid from sysadm.INH_DATOS_APN_contrato a where a.msisdn = '3213819674';
