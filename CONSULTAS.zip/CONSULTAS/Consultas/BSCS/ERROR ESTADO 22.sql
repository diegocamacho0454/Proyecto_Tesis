--------------------------- REVISION DE LA LINEA ------------------------------------------------------------
SELECT A.CO_ID, FUNC_CAP_CO_ID_GSM(CO_ID,'MIN',3005) MIN,   FUNC_CAP_CO_ID_GSM(CO_ID,'IMSI',3005) IMSI,
FUNC_CAP_CO_ID_GSM(CO_ID,'HLR',NULL)  HLR,          FUNC_CAP_CO_ID_GSM(CO_ID,'SERV',3013) ACT,  --3013 --0001
FUNC_CAP_CO_ID_GSM(CO_ID,'RCAT',NULL) RC,           FUNC_CAP_CO_ID_GSM(CO_ID,'PLPR',NULL) TIPOPLAN,
FUNC_CAP_CO_ID_GSM(CO_ID,'CIC',3005) CIC,           A.STATUS  ,A.REF_TEXT, A.USERID, A.INSERT_DATE, A.TS, A.*, rowid 
FROM SYSADM.MDSRRTAB A WHERE CO_ID   IN (SELECT CO_ID  FROM CONTR_SERVICES WHERE DN_ID IN (
SELECT D.DN_ID FROM DIRECTORY_NUMBER D WHERE DN_NUM  IN ('3138884302'))) ORDER BY REQUEST DESC;
        

Select cd_seqno , co_id , cd_port_num , cd_activ_date , cd_validfrom, cd_entdate , cd_deactiv_date , cd_moddate ,
decode(substr(cd_sm_num,8,1),0,'Oriente',1,'Occidente',2,'Costa',4,'Oriente') Zona,
''''||cd_sm_num||''''||',' , ''''||port_id||''''||','  , 
cd_status ,  cd_pending_state, rowid
from contr_devices a
where co_id in (236934140)
order by CO_ID,cd_seqno asc;   




---- STORAGE_MEDIUM ----- Para la sim activa (a) SM_MODDATE debe ser NULL
Select sm_serialnum , sm_status , sm_entdate , sm_moddate,rowid
from storage_medium 
where sm_serialnum in ('89571014017062216603');



---- PORT ---- Para la sim activa (a) PORT_DEACTIV_DATE - PORT_MODDATE deben ser NULL
select port_id , port_num , port_status , port_activ_date , port_deactiv_date , port_entdate , port_moddate, rowid
from port p
where port_id  in('254390479');

select * from contr_devices where cd_sm_num in('89571014017062216603');



SELECT * FROM sysadm.inh_imei WHERE imei in ('358651084091295');


/*
update port p
set p.port_status = 'a'
where p.port_id = '218598289'
and p.port_status = 'd'
*/

/*
Update  storage_medium 
set sm_status = 'a'
where sm_serialnum = '89571010015099827917'
and sm_status = 'd'

  


