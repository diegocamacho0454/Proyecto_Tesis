DECLARE TYPE ARREGLO IS TABLE OF VARCHAR2(25);
arListado ARREGLO := ARREGLO(&MIN); 
NmHlr NUMBER; BEGIN FOR i IN arListado.first .. arListado.last LOOP 
select sysadm.pkg_mdscongif.fngethlr (arListado(i)) 
INTO NmHlr from dual; dbms_output.put_line(''||' '||arListado(i)||' '||NmHlr); END LOOP; END;
