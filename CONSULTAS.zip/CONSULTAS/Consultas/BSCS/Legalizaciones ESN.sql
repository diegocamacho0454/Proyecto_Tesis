
--***************************************************************************************************

-- El objetivo es complementar la informacion de Legalizaciones.

--***************************************************************************************************
-- Luis Edgardo Morales. Hitss. Service Desk. 
-- 2014/07/14
--***************************************************************************************************

DECLARE
   TYPE ARREGLO IS TABLE OF VARCHAR2(25);
   arListado   ARREGLO := ARREGLO(    
&vArreglo
   );

   VcSimE    VARCHAR2(25);  
   VcSimS   VARCHAR2(25);  

   
 
BEGIN
  
   FOR i IN arListado.first .. arListado.last
     
       LOOP 
       
        FOR X IN (SELECT '89'||arListado(i) VcSimE
                  FROM DUAL)
   
             LOOP

                  SELECT x.VcSimE||FUN_DIG_ICCID(x.VcSimE) 
                  INTO VcSimS
                  FROM DUAL;
             
             END LOOP;

dbms_output.put_line(VcSimS);

      END LOOP;
 
END;


