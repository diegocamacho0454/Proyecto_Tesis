----- NRN ---------
select p.sncode NRN , p.indicador NRN_PM, p.descripcion DESTINO 
from inh_param_servicios p 
where p.tipo_proc = 15;

---------HLR--------

SELECT a.dn_num, a.dn_status, a.dn_status_requ, a.hlcode  
FROM directory_number a 
WHERE a.dn_num IN ('3194849681');

------Title--------------

select h.hlrcode, h.hlnom, h.alias_conm, h.global_title
from inh_hlr h
order by 1
;

 
