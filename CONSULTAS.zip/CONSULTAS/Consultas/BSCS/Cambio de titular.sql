SELECT ca.customer_id, cs.co_id, dn.dn_num
FROM CONTRACT_ALL ca, contr_services cs, directory_number dn
WHERE ca.co_id = cs.co_id
AND cs.dn_id = dn.dn_id
AND substr(cs.cs_stat_chng, -1) <> 'd'
AND dn.dn_num IN(
'3183933336'

);

-----�  En la tabla CUSTOMER _ALL actualizar el campo PASSPORNO al documento del nuevo cliente:----------

SELECT a.*,rowid FROM CUSTOMER_aLL a  WHERE a.CUSTOMER_ID = 295333350;

/* ------ En la tabla CCONTACT_ALL se debe actualizar el campo CCBILL, quitando la X del 
         anterior cliente y marcando el Nuevo con X may�scula:  --------------*/
         
SELECT a.*, rowid FROM CCONTACT_ALL a WHERE CUSTOMER_ID IN (264350150);
