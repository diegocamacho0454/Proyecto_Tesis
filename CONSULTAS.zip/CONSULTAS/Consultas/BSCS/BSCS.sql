--------------------------------------- REVISION DE LA LINEA -------------------------------------------------------
SELECT A.CO_ID, FUNC_CAP_CO_ID_GSM(CO_ID,'MIN',3005) MIN,   FUNC_CAP_CO_ID_GSM(CO_ID,'IMSI',3005) IMSI,
FUNC_CAP_CO_ID_GSM(CO_ID,'HLR',NULL)  HLR,          FUNC_CAP_CO_ID_GSM(CO_ID,'SERV',3013) ACT,
FUNC_CAP_CO_ID_GSM(CO_ID,'RCAT',NULL) RC,           FUNC_CAP_CO_ID_GSM(CO_ID,'PLPR',NULL) TIPOPLAN,
FUNC_CAP_CO_ID_GSM(CO_ID,'CIC',3005) CIC,           A.STATUS  ,A.REF_TEXT, A.USERID, A.INSERT_DATE, A.TS, A.*, rowid 
FROM SYSADM.MDSRRTAB A WHERE CO_ID   IN (SELECT CO_ID  FROM CONTR_SERVICES WHERE DN_ID IN (
SELECT D.DN_ID FROM DIRECTORY_NUMBER D WHERE DN_NUM  IN ('&min'))) ORDER BY REQUEST DESC;  

--------------------------- SERVICIOS DE UNA LINEA -----------------------------------------------------------
    SELECT M.SNCODE,M.DES,C.SPCODE,S.DES,CS_SEQNO,CS_STAT_CHNG, --C.ROWID,
  (SELECT DES FROM MPUTMTAB WHERE TMCODE = C.TMCODE AND STATUS = 'W') PLAN_TARIFARIO,C.*
  FROM CONTR_SERVICES C, MPUSNTAB M, MPUSPTAB S WHERE M.SNCODE = C.SNCODE AND S.SPCODE = C.SPCODE
  AND CO_ID IN (SELECT CO_ID
                    FROM CONTR_SERVICES A, DIRECTORY_NUMBER B
                    WHERE A.DN_ID = B.DN_ID  AND A.CS_DEACTIV_DATE IS NULL
                    AND B.DN_NUM IN ('&min'))  ORDER BY C.CS_SEQNO    DESC, 2, C.SNCODE;
      
      sysadm.procarga
      sysadm.acproc_buzon_reset_icon
      Sysadm.Ac_Activa_Obsequio_Cfm
      sysadm.esn_sp_upd_esn_robados
      
      
select * from customer_all c 
where customer_id in ('226016130');

-----consulta sobre la tabla contr_devices---------

Select cd_seqno ,co_id , cd_port_num, cd_activ_date , cd_validfrom , cd_entdate , cd_deactiv_date , cd_moddate ,
decode(substr(cd_sm_num,8,1),0,'Oriente',1,'Occidente',2,'Costa',4,'Oriente') Zona,
''''||cd_sm_num||''''||',' , ''''||port_id||''''||','  ,
cd_status ,  cd_pending_state
from contr_devices a
where co_id in (30339481)
order by CO_ID,cd_seqno asc ;


---- STORAGE_MEDIUM ----- Para la sim activa (a) SM_MODDATE debe ser NULL             
Select
sm_id, sm_serialnum , sm_status , sm_entdate , sm_moddate
from storage_medium
where sm_serialnum in ('89571015022061009743')for update;    

---- PORT ---- Para la sim activa (a) PORT_DEACTIV_DATE - PORT_MODDATE deben ser NULL       
select port_id, p.sm_id,port_num,port_status, port_activ_date,port_deactiv_date, port_entdate, port_moddate
  from port p
 where port_id in ('308973483')for update;

-------------LISTAS NEGRAS-------------------
select * from esn_robados where esn = '89571015022061009743';


---------- listas negras -----------------

select * from sysadm.ex_black_list e 
where e.co_id = sysadm.getcoid(30339481)
and e.sncode = 3090
and e.estado = 1;

----------servicios que soporta un plan---------
select lk.tmcode, (select des from mputmtab tm where tm.tmcode = lk.tmcode and tm.status = 'W') 
PLAN, lk.vscode, lk.vsdate, lk.status, lk.spcode,(select des from mpusptab sp where sp.spcode = lk.spcode) Paquete, lk.sncode, 
(select des from mpusntab sn where sn.sncode = lk.sncode) Servicio, lk.accessfee from mpulktmb lk 
where lk.tmcode in (&plan) and spcode+0 = (&spcode) and lk.vscode = (select max(lk1.vscode) 
from mpulktmb lk1 where lk1.tmcode = lk.tmcode and lk1.vsdate < sysdate) order by lk.tmcode, lk.spcode, lk.sncode, lk.accessfee;



      
---------TICKLER historico-------------------------------------------------
select * from tickler_record_historico
where customer_id  = '218332521'                 order by 2 desc              
;
-------------------TICKLER GENERAL---------------------
select t.y_coordinate, t.customer_id, t.tickler_code, t.tickler_status, t.created_by, t.created_date,T.CLOSED_DATE, t.short_description, t.long_description
from tickler_records t          
where t.customer_id  = '199686020'                                                                                           
--and t.long_description like '%Aplica%'                  
--and t.tickler_code like '%PLAN%'
order by 2 desc;


--TICKLER 
SELECT created_date, created_by, customer_id, tickler_number, tickler_number, short_description, long_description, co_id 
  FROM tickler_records 
WHERE customer_id in (SELECT customer_id
          FROM contract_all
         WHERE co_id IN (SELECT co_id
                           FROM contr_services a, directory_number b
                          WHERE a.dn_id = b.dn_id
                            AND b.dn_num in ('&min')
                         /*and cs_deactiv_date IS NULL*/
                         ))
ORDER BY created_date DESC;

-----transaccion sin fluir----------  
select count(*)
from mdsrrtab
where status = 2 and CO_ID in ('261543283');


----------------------------------------------------------------------------
-------------------------MDSRRETAB---TRANSACCIONES DEL SISTEMA DE UNA LINEA-----------
select 
co_id , hlcode HLR , status , res  ,userid , ts ,ref_text  ,request_update ,customer_id
from mdsrrtab
Where co_id in ( &contrato)
--AND rownum < 6
--and request_update is null
--and ref_text LIKE 'Cambio de Suscripcion%'
--and status  NOT IN  (7,103) --,2,21)
--and status  in (21)
--and status  in (2,22)-- En proceso
--and request_update Is NULL  
--AND userid = 'ESJ9756A'
--AND userid = 'BMH'
--AND to_date(to_char(TS, 'dd/mm/yyyy'),'dd/mm/yyyy') = to_date(to_char('25/04/2014'),'dd/mm/yyyy')
--and ref_text = 'Cambio de minutos'  
--and status not in (7,103)
--and hlcode <> 20
--and request = 1767125239
--and RES LIKE'%Error ejecucion HLR : DATABASE SYSTEM FAILURE%'
ORDER BY co_id, request desc ;

-----------------------------------------------------------------------
----------ULTIMA TRANSACCION DE UNA LINEA-------------
select 
co_id , status , res , ts ,ref_text
from mdsrrtab a
where request = (select max(request)
               from mdsrrtab b
               where a.co_id = b.co_id
               and ref_text <> 'Transaccion de conciliacion'
               )
and co_id in ( &contrato);
------------------------------------------

----VALIDAR CEDULA DE LA LINEA ------------

select C.*, ROWID   from ccontact_all c  where c.customer_id IN (285895781);

----------CFM por anticipado-----------------------
select * from Inh_cfmant where co_id = '121203198';

SELECT A.*, rowid FROM CAP_MASIVOS A WHERE co_id IN ('3128112261') ORDER BY FECHA DESC;


select * from  MPUSNTAB M WHERE UPPER(SHDES) LIKE '00RDI'; 
select * from  MPUSNTAB M WHERE M.SNCODE in (11538);   --Servicios

SELECT A.*, rowid FROM CONTR_SERVICES A WHERE co_id IN ('105752084');


----datos demograficos de la linea-----      
      sysadm.prodatosdemograficos();

    
----Validar la descripcion del plan con el TMCODE de la linea---  
select a.tmcode, a.des, e.descripcion, a.vsdate, a.vscode
  from mputmtab a, mpulktmb c, mpusptab d, ex_descplanes e
where a.tmcode in ('23919')

           --(SELECT a.tmcode
             --    FROM CONTR_SERVICES A, DIRECTORY_NUMBER B
             --   WHERE A.DN_ID = B.DN_ID  AND A.CS_DEACTIV_DATE IS NULL
             --   AND B.DN_NUM IN ('3202830279'))
   and a.tmcode = c.tmcode
   and c.sncode in (3, 3013, 1)
   and c.spcode = d.spcode
   and a.shdes || d.shdes = e.shdes_mputmtab_mpusptab
   and a.vscode in
       (select max(b.vscode) from mputmtab b where b.tmcode = a.tmcode)
   and c.vscode in
       (select max(x.vscode) from mpulktmb x where c.tmcode = x.tmcode); 
----Validar la descripcion del Paquete con el SPCODE -17681--        
select * from EX_DESCRIPCIONES_PAQ where SPCODE ='4002';        
       
select * from  MPUSNTAB M  WHERE /* m.des like '%Internac%'*/SNCODE in (select distinct sncode from MPUlktmb Mp WHERE  mp.tmcode =13571);

select * from mpulktmb Mp WHERE  mp.tmcode =18111 and mp.sncode=3384;

----activacion paquete de bienvenida---
Select  * From sysadm.pcrf_paq_bienvenida pb 
Where pb.co_id = 255055902;

---validacion de quien activo el paquete----
Select  * From sysadm.pcrf_paq_bienvenida_bitacora b 
Where b.co_id = 249028922;

select * from sysadm.cap_pcrf_all a where MSISDN IN ('573118272583');

-------------DESCRIPCION DEL PLAN PARA DOWNGREED------------------------------------------------- 

select * from Ex_planes n 
where n.tmcode = '23919';


---------------LOS CAMBIOS DE PLANES DE UN CONTRATO---------
SELECT I.*, TM.DES FROM INH_CAMBIO_PLAN_HECHOS I, MPUTMTAB TM 
WHERE I.CUSTOMER_ID IN (SELECT CUSTOMER_ID FROM CONTRACT_ALL  WHERE CO_ID IN ('213686373')) 
AND I.TMCODE = TM.TMCODE AND TM.STATUS = 'W' ORDER BY I.FECHA desc; 
---------------------------------------------------------------------------------------------------




--------------------------- HISTORICO SERVICIOS DE UNA LINEA -------------------------------------------------
SELECT N.SNCODE, N.DES, I.SPCODE, S.DES, CS_SEQNO, CS_STAT_CHNG,
(SELECT DES FROM MPUTMTAB WHERE TMCODE = I.TMCODE AND STATUS = 'W') PLAN_TARIFARIO, I.*
FROM INH_DELETE_CONTR I, MPUSPTAB S, MPUSNTAB N
WHERE I.SPCODE = S.SPCODE AND I.SNCODE = N.SNCODE
AND CO_ID = '276415923' ORDER BY I.CS_SEQNO DESC, 2, I.SNCODE;



---------------------------------MICROCELDA--------------------  ----------------------------------------------
select * from inh_tmsp_prep  where tmcode=22970;

------------------------------------HISTORICO CONTROL HOTRATING----------------------------------------------
select * from CAP_MASIVOS_HISTORICO h where h.co_id='85195161' order by h.fecha desc;
select * from CAP_MASIVOS h where h.co_id='85195161' order by h.fecha desc;

select * from INH_INFO_CAMBIOMIN where minanterior = '3118986474';


----------------------------------------------------------
select * from split_contratos s where s.co_id in('216661978');

---FACTURA ELECTR�NICA
select * from ex_factu_elec_insentiva_invi i
where i.vcmin in (3118344237); 

------------------CODIGO MATERIAL ACTIVACION-------------------
select * from SYSADM.INH_INFOACTPREPAGO where codmin = '3003627745';


------------------------------------CUSTOMER ID MAESTRA------------------------------------------------------
select * from customer_all c where c.custcode in ('8.21974816');

select * from SYSADM.LOG_BALANCEO where Customer_id ='166537528' order by fecha desc;

---------- CRUCE DE MINES ----------
SELECT TAREA_ID, PROCESO_STATUS, FECHA_INICIO, PROCESO_ERRORES, USUARIORED, DESC_CORTA, DESC_USUARIO
FROM sysadm.ex_batch_Tareas WHERE DESC_CORTA = 'Cruce Mines' 
and PARAMETROS_STRING1 like '%3012653477%' ORDER BY TAREA_ID desc;

---------- VALIDAR ZONA ----------

SELECT a.dn_num, a.dn_status, a.dn_status_requ, a.hlcode 
FROM directory_number a 
WHERE a.dn_num IN ('3156488299');

-----------------------BONIFICACION 5 MINUTOS-----------------------
select * from inh_mindescuento
where co_id
in
       (select co_id
          from contr_services a
         where dn_id in
               (select dn_id from directory_number where dn_num in ('3144426267'))
               and substr (a.cs_stat_chng, -1)<> 'd');


--------------------CONTRASE�A DE UNA L�NEA--------------------------
SELECT CSPASSWORD 
FROM customer_all 
WHERE customer_id = (select customer_id    
                    from contract_all
                     where co_id = (select co_id 
                                    from contr_services 
                                    where cs_deactiv_date is null
                                    and   dn_id = (select dn_id
                                                   FROM directory_number 
                                                   WHERE dn_num = '&min')));


--------------------------------MINES DE UN NIT--------------------------------------------------------------
SELECT '&nit', A.CO_ID, C.DN_NUM, A.CUSTOMER_ID
  FROM SYSADM.CONTRACT_ALL     A,
       SYSADM.CONTR_SERVICES   B,
       SYSADM.DIRECTORY_NUMBER C,
       INH_TMSP_PREP           D
WHERE B.DN_ID = C.DN_ID
   AND B.CO_ID = A.CO_ID
   AND A.TMCODE = D.TMCODE
   AND PREPAGO NOT IN (0, 3)
   AND SUBSTR(B.CS_STAT_CHNG, -1) <> 'd'
   AND CUSTOMER_ID IN
       (SELECT CUSTOMER_ID
          FROM SYSADM.CUSTOMER_ALL
         WHERE CUSTOMER_ID_HIGH IN (SELECT CUSTOMER_ID
                                      FROM SYSADM.CUSTOMER_ALL
                                     WHERE PASSPORTNO = '&nit'
                                       AND CSLEVEL = 10)
        UNION ALL
        SELECT CUSTOMER_ID
          FROM SYSADM.CUSTOMER_ALL
         WHERE CUSTOMER_ID_HIGH IS NULL
           AND PASSPORTNO = '&nit'
           AND CSLEVEL = 40);


--------Linea migrada AMDOCS-----
SELECT a.co_id , a.ch_reason,'Linea Migrada a AMDOCS'      
FROM CONTRACT_HISTORY a 
      WHERE a.ch_reason = '289'
      AND ch_seqno = (SELECT max(ch_seqno)
                      FROM contract_history b
                      WHERE a.co_id = b.co_id)
      AND co_id in (SELECT co_id
                    FROM contr_services
                    WHERE dn_id in (SELECT dn_id
                                    FROM directory_number
                                    WHERE dn_num in ('3209694940')));

-----------CO_ID ACTIVO DEL MIN RESUMIDA----------
SELECT A.Co_Id,A.Cs_Activ_Date,B.Dn_Num FROM CONTR_SERVICES A, DIRECTORY_NUMBER B
                  WHERE A.DN_ID = B.DN_ID AND A.CS_DEACTIV_DATE IS NULL 
                  AND A.CO_ID IN (select co_id from CONTR_DEVICES  where port_id in 
                                     (select port_id from PORT where port_num in 
                                                    ('732101420811949'))
                                                           and cd_deactiv_date is null);
      
                                                

                                                           

------------------datos por customer_id--------------------

select * from contract_all where customer_id = '221032603';

-----------------------IMEI Actual--------------------
SELECT a.dn_num, b.co_id, b.tmcode,b.spcode, c.customer_id , d.imei
  FROM directory_number a, contr_services b, contract_all c, inh_imei d
WHERE a.dn_num in (

'3118344237'
)
   AND b.dn_id = a.dn_id
   AND c.co_id = b.co_id
   AND d.customer_id = c.customer_id
   AND b.cs_deactiv_date IS NULL; 
 
----IMEI------
select * 
from INH_IMEI 
where customer_id in ('110318914');       


  
  -----------------------HISTORICO de IMEI--------------------
SELECT a.dn_num, b.co_id, b.tmcode,b.spcode, c.customer_id , d.imei,d.fec_activ,d.fec_desactiv
  FROM directory_number a, contr_services b, contract_all c, inh_historico_imei d
WHERE a.dn_num in ('3118344237')
   AND b.dn_id = a.dn_id
   AND c.co_id = b.co_id
   AND d.customer_id = c.customer_id
   AND b.cs_deactiv_date IS NULL 
  ORDER BY nvl(d.fec_desactiv,SYSDATE) ASC ;


---borrar registro de IMEI------
delete from sysadm.equipment where equipment_id = 260098910;
select equipment_id,customer_id,rec_version,imei from equipment where imei in('861956031146393');
-----validar si fue devuelta la linea a BSCS-----
SELECT * FROM  bscsmig.mig_cliente_procesado where dn_num in('3102587960');                           
------estado de la linea por co_id-----linea 3234614116 validar en un mes---                  
select * 
from contract_history   
where co_id =219556808 
order by co_id,ch_seqno desc;

-----revudancia ICCID------
select *from curr_co_device where co_id = '186649780';
----se valida el campo costcenter_id no debe estar null con el customer_id de la linea---lineas prepago
select * from customer_all where customer_id = '200627391'; 




-----tablas para validar perimisos de usuarios----
select * from sysadm.ex_usuarios u 
--where u.nombre like '%CG%' 
where u.usuariobscs in ('ECM9908A');  

select * from users 
where username = 'ECM9908A';

select u.usuariored, u.nombre, u.activo 
from ex_usuarios u
where u.usuariored IN ('ECM9908A');     


SELECT * FROM EX_USUARIOS_UBICACION U 
WHERE U.USUARIORED IN ('ECM9908A');


select cs_seqno ,
  a.tmcode , a.spcode , a.sncode,
co_id ,  cs_status , cs_stat_chng , cs_activ_date ,cs_deactiv_date , a.sncode , des ,
cs_request , sn_class , cs_pending_state , cs_pending_param 
from contr_services a , mpusntab b
where a.sncode = b.sncode
and co_id in ('167509385',
'178543571',
'191628591',
'91338513',
'39259024',
'221078185',
'209609403',
'192771685',
'147479489',
'178893156'
)
and a.sncode in ('3288')
and substr(cs_stat_chng,-1) in ('a')
order by co_id , cs_seqno;

------- HISTORICO ACTUAL DE LA LINEA ----------

select * from contract_history  c   
where c.co_id in ('219556808')         
order by c.co_id, c.ch_seqno desc;

-------SUSPENSION DE LINEA--------
SELECT * 
FROM INH_SUSPENSION S 
WHERE S.CO_ID IN (SELECT CO_ID 
FROM CONTR_SERVICES A, DIRECTORY_NUMBER B 
WHERE A.DN_ID = B.DN_ID 
AND B.DN_NUM IN (
'3133917142'));

----------------pagos de servicio o equipo---------------------

select * from cashreceipts_all c  
where c.customer_id = '175942749'      
order by c.caxact desc                                                       
;

---------------Cuando No se deja consultar en AC-------------


SELECT * From contract_history where co_id = '3012121462';


/*Update contract_history set CH_REASON=32 WHERE REQUEST='2781017363' AND CO_ID='190418879';*/

-------------- Validar entrega de paquete de SMS ---------
select x.fuom un_gratis, x.*
from mpulkfum x where spcode = 4103 and sncode =3004 and x.fucode in
(select a.fucode from mpufutab a where a.shdes in
(select b.shdes from mputmtab b where b.tmcode = 21900)
);

-----Trafico de llamadas------

SELECT *FROM RTX WHERE R_P_CUSTOMER_ID = '291831694' 


 

---------- listas negras -----------------

select * from sysadm.ex_black_list e 
where e.co_id = sysadm.getcoid(287643951)
and e.sncode = 3090
and e.estado = 1;


----ELEGIDOS ASIGNADOS A UNA L�NEA.    
SELECT A.*, ROWID  FROM INH_ELEGIDOS_NEW.INH_ELEGIDOS A WHERE CO_ID IN (SELECT CO_ID
                  FROM CONTR_SERVICES A, DIRECTORY_NUMBER B
                  WHERE A.DN_ID = B.DN_ID AND A.CS_DEACTIV_DATE IS NULL 
                  AND B.DN_NUM IN ('&min'));
                  
--------- Operadores ---------
select p.sncode NRN , p.indicador NRN_PM, p.descripcion DESTINO 
from inh_param_servicios p 
where p.tipo_proc = 15;

--- validar legalizacion min
select func_cap_co_id_gsm(i.CO_ID, 'MIN', 3013) MIN,
       i.co_id,
       i.text04,
       i.text23,
       i.text30
  from info_contr_text i
 where i.co_id in ('314367871');
 
 
 
 ---- Campa�as BSCS -----

select *
    from sysadm.perm_usuarios      p,  
         sysadm.perm_camp_usuarios c,  
         sysadm.perm_campana       a  
   where p.customer_id IN ('267210482')  
     and p.id = c.id_usuario    
     and c.id_campana  = a.id;


select * from sysadm.perm_historico_beneficios a where a.id_usuario IN ('6036520');



-- consulta historico por msisdn    
             
SELECT cu.passportno,--cu.customer_id_high, 
       cs.tmcode,
       dn.dn_num, 
       dn_status,
       sysadm.func_cap_co_id(cs.co_id, 'HLR', null) hlr,
       cs.co_id,ca.customer_id, --cu.custcode, cs.co_id, cs.cs_seqno,
       substr(cs.Cs_Stat_Chng, -1) estado, 
       cu.prgcode,
       (SELECT x.cd_port_num
         FROM sysadm.contr_devices x
        WHERE x.co_id = cs.co_id 
          AND x.cd_seqno = (SELECT MAX(y.cd_seqno) 
                              FROM sysadm.contr_devices y 
                             WHERE y.co_id = x.co_id)) imsi,
       (SELECT x.cd_sm_num
         FROM sysadm.contr_devices x       
        WHERE x.co_id = cs.co_id 
          AND x.cd_seqno = (SELECT MAX(y.cd_seqno) 
                              FROM sysadm.contr_devices y 
                             WHERE y.co_id = x.co_id)) iccid,  
       (SELECT tm.des
           FROM mputmtab tm
          WHERE tm.tmcode = cs.tmcode
            AND tm.vscode = (SELECT MAX(x.vscode)
                               FROM mputmtab x
                              WHERE x.tmcode = tm.tmcode)) tmdes,
       sysadm.func_cap_co_id(cs.co_id, 'PLPR', NULL) TipoPlan,
       cu.billcycle,
       (SELECT x.billcycle_desc 
         FROM sysadm.billcycles x 
           WHERE x.billcycle = cu.billcycle) billcycle_desc,
      cc.ccfname, cc.cclname,
       ch.ch_reason causal_activ,
       (SELECT x.rs_desc FROM sysadm.reasonstatus_all x WHERE x.rs_id = ch.ch_reason) causal_activ_desc,
       ch.entdate fec_activ, ch.userlastmod usuario_activ,
       cd.ch_reason causal_desac,
       (SELECT x.rs_desc FROM sysadm.reasonstatus_all x WHERE x.rs_id = cd.ch_reason) causal_desac_desc,
       cd.entdate fec_desac, cd.userlastmod usuario_desac,
       (SELECT po.destino
           FROM sysadm.cap_ported_out po
          WHERE po.co_id = cs.co_id 
            AND po.fecha = (SELECT MAX(x.fecha) FROM cap_ported_out x WHERE x.co_id = po.co_id)
       ) destino 
       ,CU.PASSPORTNO
  FROM sysadm.directory_number dn, sysadm.contr_services cs,
       sysadm.contract_all ca, sysadm.customer_all cu,
       sysadm.contract_history ch, 
       sysadm.contract_history cd, 
       sysadm.ccontact_all cc
WHERE dn.dn_num in (&MSISDN)
   AND cs.dn_id = dn.dn_id
   AND ca.co_id = cs.co_id
   AND cu.customer_id = ca.customer_id
   AND ch.co_id(+) = cs.co_id
   AND ch.ch_seqno(+) = 2
   AND cd.co_id(+) = cs.co_id 
   AND cd.ch_status(+) = 'd'  
   AND cc.customer_id (+) = cu.customer_id  
   and cc.ccbill (+) = 'X' 
   --and substr(cs.Cs_Stat_Chng, -1) = 'a'
ORDER BY NVL(cd.entdate, SYSDATE) DESC, cs.co_id, cs_seqno DESC;

select a.* , rowid from directory_number a
where a. dn_num in (&MSISDN);







-----------llamadas-----------------}

SELECT d.dn_num,
       r.rtx_sqn,
       r.start_d_t,
       ((r.rounded_volume/60)) minutos,
       r.tzcode,
       round(((r.rounded_volume/60)*60)*(r.amount_per_unit_1))valor_unitario,
       round (r.rated_flat_amount),
       r.o_p_number,
       r.actual_volume     
  FROM RTX r,directory_number d
WHERE r.R_P_CUSTOMER_ID = '266067796'
   
    AND r.SNCODE = '3013'
     and r.r_p_dn_id=d.dn_id  

and r.start_d_t >= to_date('20200610','YYYYMMDD')
and r.start_d_t <= to_date('20200709','YYYYMMDD')

order by r.start_d_t


----- conocer el ciclo de facturaci�n -- 

select * from INH_CICLOS where estado = 'ACT' and ciclo in ('26');


--------- Balanceo ---------

select x.CUSTOMER_ID, sum(x.OHINVAMT1) saldo_correcto
  from (SELECT CUSTOMER_ID,OHXACT,OHREFDATE,
               'Factura' Tipo,
               to_char(OHREFDATE, 'dd/mm/yyyy') OHREFDATE,
               to_char(OHREFDATE, 'yyyymmdd') OHREFDATE2,
               to_char(OHINVAMT, '999G999G999G999D99') OHINVAMT,
               to_char(OHOPNAMT, '999G999G999G999D99') OHOPNAMT,
               to_char(OHDUEDATE, 'dd/mm/yyyy') OHDUEDATE,
               to_char(OHDUEDATE, 'yyyymmdd') OHDUEDATE2,
               OHINVAMT OHINVAMT1,
               OHOPNAMT OHOPNAMT1,
               OHREFNUM,
               ' ' NOMBRE_BANCO
          FROM ORDERHDR
         WHERE CUSTOMER_ID in (&customer_id)
           AND OHSTATUS IN ('IN', 'CM')
        Union
        SELECT CUSTOMER_ID,CH.CAXACT,CH.CAENTDATE,
               'Pago' Tipo,
               to_char(CH.CAENTDATE, 'dd/mm/yyyy') CAENTDATE,
               to_char(CH.CAENTDATE, 'yyyymmdd') CAENTDATE2,
               to_char(-CH.CACHKAMT, '999G999G999G999D99') CACHKAMT,
               ' ',' ',' ',
               -CH.CACHKAMT,
               0,
               ' ',
               CH.CABANKNAME
          FROM CASHRECEIPTS CH
         WHERE CH.CUSTOMER_ID in (&customer_id)
           AND (CH.CATYPE IN ('1', '3', '4', '7', '10', '12') OR
               (CH.CATYPE = '8' AND CH.CACHKAMT > 0))
        Union
        SELECT CUSTOMER_ID,CH.CAXACT,CH.CAENTDATE,
               'Ajuste' Tipo,
               to_char(CH.CAENTDATE, 'dd/mm/yyyy') CAENTDATE,
               to_char(CH.CAENTDATE, 'yyyymmdd') CAENTDATE2,
               to_char(-CH.CACHKAMT, '999G999G999G999D99') CACHKAMT,
               ' ',' ',' ',
               -CH.CACHKAMT,
               0,
               ' ',
               CH.CABANKNAME
          FROM CASHRECEIPTS CH
         WHERE CH.CUSTOMER_ID in (&customer_id)
           AND CH.CATYPE = '9'
        Union
        SELECT CUSTOMER_ID,CH.CAXACT,CH.CAENTDATE,
               'Anulaci�n' Tipo,
               to_char(CH.CAENTDATE, 'dd/mm/yyyy') CAENTDATE,
               to_char(CH.CAENTDATE, 'yyyymmdd') CAENTDATE2,
               to_char(CH.CACHKAMT, '999G999G999G999D99') CACHKAMT,
               ' ',' ',' ',
               CH.CACHKAMT,
               CH.CACHKAMT,
               ' ',
               CH.CABANKNAME
          FROM CASHRECEIPTS CH
         WHERE CH.CUSTOMER_ID in (&customer_id)
           AND CH.CARPP IS NOT NULL) X
group by x.CUSTOMER_ID;



--------- Registro Pagos ---------

select * from cashreceipts_all c  
where c.customer_id = '245508600'       
order by c.caxact desc

