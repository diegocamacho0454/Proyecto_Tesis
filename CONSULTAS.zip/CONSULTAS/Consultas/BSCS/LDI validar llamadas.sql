---------------- DATOS LINEA -----------------
select ca.customer_id, cs.co_id, dn.dn_num 
from contract_all ca, contr_services cs, directory_number dn 
where ca.co_id = cs.co_id 
and cs.dn_id = dn.dn_id 
and substr(cs.cs_stat_chng, -1) <> 'd' 
and dn.dn_num in ('3207131835');

-----Validar tarificacion de las llamadas----
SELECT d.dn_num,
       r.rtx_sqn,
       r.start_d_t,
       ((r.rounded_volume/60)) minutos,
       r.tzcode,
       round(((r.rounded_volume/60)*60)*(r.amount_per_unit_1))valor_unitario,
       round (r.rated_flat_amount),
       r.o_p_number,
       r.actual_volume      
  FROM RTX r,directory_number d
WHERE r.R_P_CUSTOMER_ID = '146498274'       
  AND r.O_P_NUMBER LIKE '%C%'
   AND r.SNCODE = '3013'   
   and r.r_p_dn_id=d.dn_id   
 order by r.start_d_t;
