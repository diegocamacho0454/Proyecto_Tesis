---todas las formas de pago---
select * from sysadm.Paymenttype_All;
---forma de pago actual---
select * from sysadm.PAYMENT where customer_id = '109715597';
----historico de cambio de forma de pago----
select * from sysadm.BANK_ACCT_HIST where customer_id = '109715597';
----validar el nombre de la forma de pago
select * from sysadm.BANK_ALL where  UPPER(bank_id) LIKE '%-43%';


