---------------- DATOS LINEA -----------------
select ca.customer_id, cs.co_id, dn.dn_num 
from contract_all ca, contr_services cs, directory_number dn 
where ca.co_id = cs.co_id 
and cs.dn_id = dn.dn_id 
and substr(cs.cs_stat_chng, -1) <> 'd' 
and dn.dn_num in ('3124337841');


----- Consulta de lista Negras-------

select * from sysadm.ex_black_list e
where e.co_id = sysadm.getcoid(182180068)
and e.sncode = 3090
and e.estado = 1;
