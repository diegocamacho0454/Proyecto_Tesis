--Obtener sncode:

Select * from mpusntab n
where des like '%Claro UP%'; 
--where n.sncode in ('12067') 
order by 1 asc;

--Obtener spcode: NOTA: El nombre del paquete se obtiene del AC --
Select * from mpusptab
Where des like '%PqBas500LDI USA CAN MEX PTORIC%';  
--where spcode IN ('4332') ;

------ Valida si el servicio est� configurado para el plan y el paquete -----
Select * from mpulktmb 
where tmcode in ('22800')
and  sncode in ('10966') 
and spcode in ('6734')          
order by 1 desc;
