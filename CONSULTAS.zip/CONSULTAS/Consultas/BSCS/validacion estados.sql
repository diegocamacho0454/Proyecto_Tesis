select count(*) from activacion@activa where estado = '200';  --ActAutomatica
select count(*) from activacion@activa where estado = 'Rechazada por Datos Incorrectos';  --ActAutomatica
select count(*) from activacion@activa where estado = 'Pendiente_C';  --Cesion pos pos
select count(*) from actinclusion@activa where estado in ('200');  --ActAlmCadPos
select count(*) from activacion@activa where estado = '40';  --ActPrepago
select count(*) from activacionpre@activa where estado = '80';  --ActPrepAutomatica
select count(*) from activacionpre@activa where estado = '90';  --HabilitacionPrepAmx
select count(*) from Extranet.actInclusion@activa where estado = '90';
select count(*) from activacion@activa where estado = '50';  --Reinstalacion
SELECT count(*) from Extranet.Activacion@activa WHERE  estado IN ('100','200');  --Legalizacion ::  ActLegalizacion.sql
SELECT count(*) FROM Extranet.ActInclusion@activa WHERE estado = '90' AND CodMin <> '0' AND (Resn = 91 OR Resn = 92 OR Resn = 95 OR Resn = 96);  --Inclusi�n:
SELECT count(*) FROM Extranet.ActInclusion@activa WHERE  estado = '90' AND CodMin <> '0' AND  (Resn = 93 OR Resn = 94 OR Resn = 97 OR Resn = 98);   --Exclusion:
