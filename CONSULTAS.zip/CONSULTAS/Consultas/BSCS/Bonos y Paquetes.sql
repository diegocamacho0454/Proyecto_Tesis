---------------------------- BSCS ----------------------------------


-- 1. Los bonos y paquetes se encuentran configurados en la tabla.

SELECT * FROM sysadm.inh_conf_promocion_minutos;


-- 2. Registro de minutos bonos o paquetes

SELECT * FROM sysadm.INH_MINADIC_HOTRATING
WHERE CO_ID = &CONTRATO
ORDER BY FECHA_IN DESC;

-- 4. Reporte de bono o paquete a Hotrating  

SELECT * FROM sysadm.inh_aprov_hotrating
WHERE CO_ID = &contrato
ORDER BY F_INICIO desc;

-- Consultar si la l�nea tiene activo un Bono / Paquete

SELECT A.CO_ID, A.TMCODE, A.SPCODE, A.SNCODE, B.DES, A.CS_STAT_CHNG, A.CS_ACTIV_DATE
FROM CONTR_SERVICES A , MPUSNTAB B
WHERE A.SNCODE = B.SNCODE
AND CO_ID = &contrato;
--AND SPCODE = 5773

---------------------------- ACTIVA ----------------------------------

SELECT * FROM EXTRANET.ACTIVACION_PROCESOS_CAD A;

---procedimiento para desactivar paquete de voz----------
sysadm.pkg_bonos_y_paquetes.p_desactivar_paquete

