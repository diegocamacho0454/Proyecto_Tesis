SELECT i.*,rowid FROM SYSADM.inh_act_ascard i where i.imei in ('355860104316292');--ORDER BY IMEI DESC;
-------------------------------------------------------------------------------
SELECT i.*,rowid FROM SYSADM.inh_act_ascard i where i.msisdn in ('3143837044');
---------------------------------------------------------------------------------
SELECT i.*,rowid FROM SYSADM.inh_act_ascard i where i.custcode_ser in ('1.19502522');
--------------------------------------------------------------------------------------
SELECT i.*,rowid FROM SYSADM.inh_act_ascard i where i.nro_identificacion in ('422046');
