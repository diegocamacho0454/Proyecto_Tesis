
-- ******************************************************************************
-- Solicitud cambio de causal de Desactivaci�n - se requiere que este respaldada 
-- la solicitud por aval de Coordinador Jovanny Garcia Bonilla 
-- ******************************************************************************

-- Datos linea, se requiere el contrato

select c.dn_num, a.co_id, a.customer_id, b.customer_id_high, a.co_crd_check, 
a.co_crd_chk_start, a.co_crd_chk_end, a.co_crd_clicks, a.tmcode, b.billcycle 
from contract_all a, customer_all b, directory_number c, contr_services d
where c.dn_id = d.dn_id 
and a.co_id = d.co_id 
and a.customer_id = b.customer_id 
--and Substr(d.cs_stat_chng,-1) in ('a','s')--,'d')
and c.dn_num in (
'3102407293'
)ORDER BY dn_num, CO_ID


-- Conocer causal actual de la linea antes del cambio

SELECT a.co_id , a.ch_seqno , a.ch_status , a.ch_reason , b.rs_desc ,a.ch_validfrom , a.ch_pending
from contract_history a , reasonstatus_all b
where a.ch_reason = b.rs_id
and ch_seqno = (select max(ch_seqno)
				  from contract_history b
				  where a.co_id = b.co_id)
and co_id in (&contrato)
order by co_id, ch_seqno desc 

-- Actualizacion de la causal.


Update  contract_history a
set ch_reason = 302
where ch_seqno = (select max(ch_seqno)
				  from contract_history b
				  where a.co_id = b.co_id)
and co_id in( 

&contrato

) 

-- Consulta de Causales    

select * from reasonstatus_all 
--where RS_ID in (144)
where RS_DESC like ('%Cliente%')
--order by RS_DESC

-- Ejemplos

--(75) FALLECIO 
--(145) Problemas Personales / Econ�micosm, 
--202 Problemas Internos Empresa
-- 76 No est� utilizando el Servicio





