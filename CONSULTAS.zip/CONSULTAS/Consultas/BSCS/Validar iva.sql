DECLARE
    VC_MIN VARCHAR2(20) := &CELULAR;
    VC_PORC VARCHAR2(20) :=&VC_PORC;
 
    CURSOR IMPU IS
        SELECT D.DN_NUM,
               A.CO_ID,
               TO_NUMBER(A.SNCODE) SNCODE,
               A.TMCODE,
               B.DES,
               C.ACCESSFEE VALOR,
              TXV.TAXRATE IVA
              --TO_CHAR(VC_PORC,'99')
          FROM CONTR_SERVICES   A,
               MPUSNTAB         B,
               MPULKTMB         C,
               DIRECTORY_NUMBER D,
               TAX_ALL          TA,
               TAXVERSION       TXV
         WHERE D.DN_NUM in (3233249208)
           AND A.CO_ID =
               (SELECT CS.CO_ID
                  FROM CONTR_SERVICES CS
                 WHERE CS.DN_ID = D.DN_ID
                   AND SUBSTR(CS.CS_STAT_CHNG, -1) IN ('a', 's'))
           AND SUBSTR(A.CS_STAT_CHNG, -1) IN ('a', 's')
           AND B.SNCODE = A.SNCODE
           AND C.TMCODE = A.TMCODE
           AND C.SPCODE = A.SPCODE
           AND C.SNCODE = A.SNCODE
           AND C.VSCODE = (SELECT MAX(Z.VSCODE)
                             FROM MPULKTMB Z
                            WHERE Z.TMCODE = C.TMCODE
                              AND Z.SPCODE = C.SPCODE
                              AND Z.SNCODE = C.SNCODE)
           AND C.ACCESSFEE > 0
           AND C.ACCSERV_CODE = SUBSTR(TA.TAX_MAP_EXT, -2)
           AND TA.TAXCODE = TXV.TAXCODE(+);

BEGIN
    DBMS_OUTPUT.PUT_LINE('MIN|CO_ID|SNCODE|TMCODE|DESCRIPCION|VALOR|IVA|CAMPA�A');

    FOR CALCULO IN IMPU LOOP
        IF CALCULO.DN_NUM IS NOT NULL THEN
            DBMS_OUTPUT.PUT_LINE(CALCULO.DN_NUM || '|' || CALCULO.CO_ID || '|' ||
                                 CALCULO.SNCODE || '|' || CALCULO.TMCODE || '|' ||CALCULO.DES || '|' ||CALCULO.VALOR||'|'||
                                ((CALCULO.VALOR * (CALCULO.IVA/100)) +
                                 CALCULO.VALOR)||'|'||(((CALCULO.VALOR * (CALCULO.IVA/100)) +
                                 CALCULO.VALOR)*(VC_PORC/100)));
        END IF;
    END LOOP;
END;
