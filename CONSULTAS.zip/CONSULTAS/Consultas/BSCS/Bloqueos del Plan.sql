--------------Bloqueos--------

Select * from mpusntab n 
where des like '%Prote%';

----------Mirar si el plan soporta Un servicio----16137---
select lk.tmcode, 
  (select des from mputmtab tm where tm.tmcode = lk.tmcode and tm.status = 'W') PLAN,lk.vscode, lk.vsdate, lk.status, lk.spcode, 
  (select des from mpusptab sp where sp.spcode = lk.spcode) Paquete ,lk.sncode, 
  (select des from mpusntab sn where sn.sncode = lk.sncode) Servicio,lk.accessfee
  from mpulktmb lk
  where lk.tmcode = 18119
and   sncode = 10966
   --and spcode = 4003
    and lk.vscode = (select max(lk1.vscode) from mpulktmb lk1 where lk1.tmcode = lk.tmcode and lk1.vsdate < sysdate)
  order by lk.tmcode, lk.spcode, lk.sncode, lk.accessfee;
  
  
  
select cs_seqno ,
  a.tmcode , a.spcode , a.sncode,
co_id ,  cs_status , cs_stat_chng , cs_activ_date ,cs_deactiv_date , a.sncode , des ,
cs_request , sn_class , cs_pending_state , cs_pending_param 
from contr_services a , mpusntab b
where a.sncode = b.sncode
and co_id in ('130533968',
'76585193',
'188176503',
'128306751',
'173313662',
'181475886',
'214658500',
'83465325'
)
and a.sncode in ('3004','3009')
and substr(cs_stat_chng,-1) in ('a')
order by co_id , cs_seqno;
  
  
-------------- mensajes del plan
select x.fuom un_gratis, x.* 
from mpulkfum x where spcode = 5724 and sncode =3004 and x.fucode in 
(select a.fucode from mpufutab a where a.shdes in 
(select b.shdes from mputmtab b where b.tmcode = 15790)
);

  
