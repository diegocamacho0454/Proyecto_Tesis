






    select
request, co_id , hlcode HLR , status , res  ,userid , ts ,ref_text  ,request_update ,customer_id, a.rowid
from mdsrrtab a
Where co_id in ( &contrato)
--AND rownum < 6
--and request_update is null
--and ref_text LIKE 'Cambio de Suscripcion%'
--and status  NOT IN  (7,103) --,2,21)
--and status  in (21)
--and status  in (2,22)-- En proceso
--and request_update Is NULL
--AND userid = 'ESJ9756A'
--AND userid = 'BMH'
--AND to_date(to_char(TS, 'dd/mm/yyyy'),'dd/mm/yyyy') = to_date(to_char('25/04/2014'),'dd/mm/yyyy')
--and ref_text = 'Cambio de minutos'
--and status not in (7,103)
--and hlcode <> 20
--and request = 1767125239
--and RES LIKE'%Error ejecucion HLR : DATABASE SYSTEM FAILURE%'
ORDER BY co_id, request desc;



--------- CONTR_SERVICES 

    select
co_id ,  cs_seqno ,cs_status , cs_stat_chng , cs_activ_date , dn_id ,cs_deactiv_date , tmcode ,spcode, sncode ,
cs_request , sn_class , cs_sparam1 , cs_pending_state , cs_pending_param , a.rowid
from contr_services a
where co_id in ( &contrato)
--and sncode in (12567)
order by co_id , cs_seqno

    
-- CONTR_SERVICES Servicio de una linea con nombre.



select a.co_id, a.cs_seqno, a.tmcode , a.spcode , a.sncode, des ,
cs_status , cs_stat_chng , cs_activ_date ,cs_deactiv_date ,cs_pending_state , cs_pending_param 
from contr_services a , mpusntab b
where a.sncode = b.sncode
and co_id in (&contrato)
--and a.sncode in (3004,3009)
and   substr(a.cs_stat_chng, -1) in ('a')
--and a.sncode in ('12861','12859','12862','12998')  --12861--Whatsapp  12859--Facebook 12862--Cabify 12998-Netflix Servicio $0
--and a.sncode in ('13031') --Claro Video 11509 --Claro Musica
--and a.sncode in ('12567')-- Blindaje
--and a.sncode in ('12567')
order by a.co_id , cs_seqno;



