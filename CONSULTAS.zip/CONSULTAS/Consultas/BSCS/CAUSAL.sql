---0--------------Customer ID-------------------------------------
SELECT a.dn_num, b.co_id, b.cs_seqno, b.tmcode, b.cs_stat_chng, b.cs_deactiv_date, d.customer_id, d.custcode
  FROM directory_number a, contr_services b, contract_all c, customer_all d
WHERE a.dn_num in ('3183599168')
   AND b.dn_id = a.dn_id
   AND c.co_id = b.co_id
   AND d.customer_id = c.customer_id
   --AND b.cs_deactiv_date IS NULL 
  ORDER BY nvl(b.cs_deactiv_date,SYSDATE) DESC ;

-----1-------------Cambio de Causal-----------------
SELECT a.co_id , a.ch_seqno , a.ch_status , a.ch_reason , b.rs_desc ,a.ch_validfrom , a.ch_pending
from CONTRACT_HISTORY a , reasonstatus_all b
where a.ch_reason = b.rs_id
and ch_seqno = (select max(ch_seqno)
                          from contract_history b
                          where a.co_id = b.co_id)
and CO_ID in ('185616784')order by co_id, CH_SEQNO desc ;  


--2-- CAUSALES DE DESACTIVACION ------
select * from reasonstatus_all 
--where RS_ID in (134);
where RS_DESC like ('%Problema%');
--where RS_STATUS in ('d');


----3---- CAMBIO CAUSAL ---------
Update  contract_history a
set ch_reason = 202
where ch_seqno = (select max(ch_seqno)
                          from contract_history b
                          where a.co_id = b.co_id)
and co_id in('185616784');   
