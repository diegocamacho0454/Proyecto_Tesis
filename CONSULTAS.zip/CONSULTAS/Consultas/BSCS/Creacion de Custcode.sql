-------------------------------CUSTCODE-----------------------------------------------------------------------
SELECT a.dn_num, b.co_id, b.cs_seqno, b.tmcode,b.spcode, b.cs_stat_chng, b.cs_deactiv_date, d.customer_id, d.custcode
  FROM directory_number a, contr_services b, contract_all c, customer_all d
WHERE a.dn_num in ('3128498301')
   AND b.dn_id = a.dn_id
   AND c.co_id = b.co_id
   AND d.customer_id = c.customer_id
   --AND b.cs_deactiv_date IS NULL 
  ORDER BY nvl(b.cs_deactiv_date,SYSDATE) DESC ;

--------------Verificar que el cliente no tenga creado CUSTCODE de equipo-------------------
-----Responsable de pago:CUSTOMER_ID Se crear� un CUSTOMER_ID DE EQUIPO con su OCC responsable de pago------
-------No responsable de pago:CUSTOMER_ID_HIGH Se crear� un CUSTOMER_ID_HIGH DE EQUIPO con su OCC------
SELECT i.custcode_equipo, i.customer_id_equipo, i.fecha_registro, i.ciclo ,c.customer_id ,c.customer_id_high ,c.paymntresp 
FROM sysadm.inh_rel_equ_ser i ,sysadm.customer_all c 
WHERE i.customer_id_servicio (+) = NVL2(c.paymntresp,c.customer_id,c.customer_id_high) and c.customer_id in('249559880');

-------si existe se valida si el OCC ya se encuetra creado o esta pendiente por crear----
----si esta se cierra-----
---- si no esta se valida informacion en activacion@equipo-----
SELECT f.*,rowid FROM SYSADM.FEES F WHERE F.CUSTOMER_ID in('196128321');

--------validar registro del equipo por IMEI-----
----Activacion----
SELECT * FROM ACTIVACION_EQUIPO@activa AE 
WHERE AE.ID_ACTIVACION = (SELECT A.ID_ACTIVACION FROM ACTIVACION@activa A WHERE A.IMEI = '&Imei' 
AND A.FECBSCS IS NOT NULL) AND AE.FECHA_INICIAL IS NULL;
----Reposicion----
SELECT * FROM ACTIVACION_EQUIPO@activa AE 
WHERE AE.IMEI = '&Imei' AND lower(AE.CAUSAL) = 'reposicion' AND AE.FECHA_INICIAL IS NULL;

-----
SELECT A.*, rowid FROM ACTIVACION_EQUIPO@activa A WHERE A.CUSTOMER_ID in('246084654',
'234643416',
'166837731',
'174362262',
'190944105');
delete from ACTIVACION_EQUIPO@activa where Customer_id = 224739735 and id_equipo = 12915730;

-----registro del equipo en activacion@equipo--648894--
PKG_UTL_CAMPANIAS.CREACION_CUSTCODE_ACTIVA;

SYSADM.PKG_VENTA_EQUIPOS_4444.PRC_ASOCIAR_EQUIPO;

----------VALIDAR CUSTOMER ID CON EL CUSTCODE--------------
SELECT Customer_id --Customer_id_high, custcode, csactivated  
FROM customer_all cu WHERE custcode IN ('8.22113044', '8.22189719', '8.21997335', '8.22110673', '8.22093860', '8.22093899');

SELECT * FROM CUSTOMER_aLL WHERE CUSTOMER_ID IN ('142638040','142616725','147109661','113703624','172589784','147638483');
