SELECT a.custcode, d.dn_num,c.co_id FROM SYSADM.CUSTOMER_ALL A, SYSADM.CONTRACT_ALL B,CONTR_SERVICES C, DIRECTORY_NUMBER d
WHERE A.CUSTCODE in('1.07964326')
AND B.CUSTOMER_ID=A.CUSTOMER_ID
AND C.CO_ID=B.CO_ID
AND C.MAIN_DIRNUM='X'
AND SUBSTR(C.CS_STAT_CHNG,-1) IN ('a','s')
AND d.dn_id=c.dn_id;

SELECT CS.CO_ID,
       D.DN_NUM,
       D.DN_ID,
       A.APLICA_CON_IVA,
       P.*,
       C.*,
       A.*,
       SYSADM.PKG_TAXRATE_BSCS.FNC_OBTENER_TAXRATE_TMCODE(CS.TMCODE) CFM
  FROM SYSADM.PERM_USUARIOS      P,
       SYSADM.PERM_CAMP_USUARIOS C,
       SYSADM.PERM_CAMPANA       A,
       SYSADM.CONTR_SERVICES     CS,
       SYSADM.DIRECTORY_NUMBER   D
WHERE D.DN_NUM IN ('&CODMIN')
   AND P.ID = C.ID_USUARIO
   AND C.ID_CAMPANA = A.ID
   AND CS.CO_ID = P.CO_ID
   AND D.DN_ID = CS.DN_ID
   AND CS.MAIN_DIRNUM = 'X'
   AND CS.CS_SEQNO = (SELECT MAX(CS1.CS_SEQNO)
                        FROM CONTR_SERVICES CS1
                       WHERE CS1.CO_ID = CS.CO_ID);
                       
                       SELECT B.DN_NUM MIN,
       A.CO_ID,
       A.USERID,
       A.REF_TEXT,
       SUBSTR(A.REF_TEXT, -5) AS TMCODE,
       TRUNC(A.INSERT_DATE)
  FROM MDSRRTAB A, DIRECTORY_NUMBER B, CONTR_SERVICES C
WHERE B.DN_NUM IN ('&CODMIN')
   AND C.DN_ID = B.DN_ID
   AND C.MAIN_DIRNUM = 'X'
   AND SUBSTR(C.CS_STAT_CHNG, -1) IN ('a', 's')
   AND A.CO_ID = C.CO_ID
   AND (UPPER(REF_TEXT) LIKE 'CAMBIO DE PLAN%' OR
       REF_TEXT LIKE 'CAMBIO DE SUSCRIPCION%')
ORDER BY TS DESC;

                       
                       ---------------------------VER CAMPA�AS POR ID USUAIRO---------------------------------------------------------------
SELECT B.DN_NUM,
       TO_CHAR(A.VALOR_BONIFICADO, '999,999,999.99') VALOR_BONIFICADO,
       E.CUSTOMER_ID,
       A.*,
       F.FLAG_PERMANENCIA,
       F.FLAG_CONVIVENCIA,
       F.APLICA_CON_IVA,
       F.APLICA_DESACT_CARTERA,
       F.RETENCION,
       F.FECHA_INICIO,
       F.APLICA_SUSPENDIDOS
  FROM SYSADM.PERM_HISTORICO_BENEFICIOS A,
       SYSADM.DIRECTORY_NUMBER          B,
       SYSADM.CONTR_SERVICES            C,
       SYSADM.PERM_CAMP_USUARIOS        D,
       SYSADM.PERM_USUARIOS             E,
       SYSADM.PERM_CAMPANA              F
WHERE B.DN_NUM = '&CODMIN'
   AND C.DN_ID = B.DN_ID
   AND C.MAIN_DIRNUM = 'X'
   AND SUBSTR(C.CS_STAT_CHNG, -1) IN ('a','s')
   AND E.CO_ID = C.CO_ID
   AND A.ID_USUARIO = D.ID_USUARIO
   AND D.ID_USUARIO = E.ID
   AND E.CO_ID = C.CO_ID
   AND F.ID = A.ID_CAMPANA
ORDER BY A.FECHA_APLICA;

---estado de la linea---
SELECT *
  FROM contract_history h
WHERE co_id IN ((SELECT a.co_id
                   FROM contr_services a
                   JOIN (SELECT dn_num, dn_id
                          FROM directory_number
                         WHERE dn_num in ('3104347774')) b
                     ON (a.dn_id = b.dn_id)))order by ch_validfrom desc;


