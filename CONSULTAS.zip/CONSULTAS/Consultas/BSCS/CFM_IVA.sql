SELECT CS.TMCODE,
       CS.SPCODE,
       CS.SNCODE,
       ACCESSFEE,
       SUBSCRIPT,
       SN.DES DESCRIPCION_SERVICIO,
       SP.DES DESCRIPCION_PAQUETE,
       CS.CS_SEQNO,
       CS.DN_ID,
       CS.CS_STAT_CHNG,
       SUBSTR(TRIM(CS.CS_STAT_CHNG), -1, 1) ESTADOS,
       SUBSTR(TRIM(CS.CS_STAT_CHNG), -1, 1) || ' ' ||
       TO_CHAR(TO_DATE(SUBSTR(TRIM(CS.CS_STAT_CHNG), -7, 6), 'rrmmdd'),
               'dd/mm/yyyy') ESTADO,
       DECODE(CS_PENDING_STATE, NULL, '0', CS_PENDING_STATE) CS_PENDING_STATE,
       SUBSTR(TRIM(CS.CS_PENDING_STATE), -1, 1) || ' ' ||
       TO_CHAR(TO_DATE(SUBSTR(TRIM(CS.CS_PENDING_STATE), -7, 6), 'rrmmdd'),
               'dd/mm/yyyy') PENDIENTE,
       SUBSTR(TRIM(CS.CS_PENDING_STATE), -1, 1) ESTADOP,
       CS.CS_DATE_BILLED,
       DN.DN_NUM,
       CS.CS_SPARAM1,
       TXV.TAXRATE IVA
  FROM CONTR_SERVICES   CS,
       DIRECTORY_NUMBER DN,
       MPULKTMB         TMB,
       MPUSNTAB         SN,
       MPUSPTAB         SP,
       TAX_ALL          TA,
       TAXVERSION       TXV
WHERE CS.CO_ID = (&co_id)
   AND CS.DN_ID = DN.DN_ID(+)
   AND CS.TMCODE = TMB.TMCODE
   AND CS.SPCODE = TMB.SPCODE
   AND CS.SNCODE = TMB.SNCODE
   AND CS.SNCODE = SN.SNCODE
   AND CS.SPCODE = SP.SPCODE
   AND TMB.VSDATE = (SELECT MAX(TMB2.VSDATE)
                       FROM MPULKTMB TMB2
                      WHERE TMB2.VSDATE <= TRUNC(SYSDATE, 'DD')
                        AND CS.TMCODE = TMB2.TMCODE)
   AND CS.CS_SEQNO = (SELECT MAX(C.CS_SEQNO)
                        FROM CONTR_SERVICES C
                       WHERE C.CO_ID = (&co_id))
   AND TMB.ACCSERV_CODE = SUBSTR(TA.TAX_MAP_EXT, -2)
   AND TA.TAXCODE = TXV.TAXCODE(+)
ORDER BY SP.DES, SN.DES
