---------------- DATOS LINEA -----------------
select ca.customer_id, cs.co_id, dn.dn_num 
from contract_all ca, contr_services cs, directory_number dn 
where ca.co_id = cs.co_id 
and cs.dn_id = dn.dn_id 
and substr(cs.cs_stat_chng, -1) <> 'd' 
and dn.dn_num in ('3105525875');



--------1.  Validar la causal de activaci�n de la l�nea-----------

SELECT a.co_id , a.ch_seqno , a.ch_status , a.ch_reason , b.rs_desc ,a.ch_validfrom , a.ch_pending
from CONTRACT_HISTORY a , reasonstatus_all b
where a.ch_reason = b.rs_id
and ch_seqno = (select max(ch_seqno)
                          from contract_history b
                          where a.co_id = b.co_id)
and CO_ID in ('254282399')order by co_id, CH_SEQNO desc ;  


---------2.  En su momento la l�nea fue marcada en los campos CS_ACCESS, CS_OVW_ACCESS Y CS_OVW_ACC_PRD-----
--------- (Actualmente el campo CS_OVW_ACC_PRD ya se encuentra en 0 porque esa facturaci�n ya paso.)--------

Select co_id, cs_activ_date, cs_deactiv_date, CS_ACCESS, CS_OVW_ACCESS, CS_OVW_ACC_PRD
from contr_services where co_id in ('246875533');
