select x.CUSTOMER_ID, sum(x.OHINVAMT1) saldo_correcto
  from (SELECT CUSTOMER_ID,
               OHXACT,
               OHREFDATE,
               'Factura' Tipo,
               to_char(OHREFDATE, 'dd/mm/yyyy') OHREFDATE,
               to_char(OHREFDATE, 'yyyymmdd') OHREFDATE2,
               to_char(OHINVAMT, '999G999G999G999D99') OHINVAMT,
               to_char(OHOPNAMT, '999G999G999G999D99') OHOPNAMT,
               to_char(OHDUEDATE, 'dd/mm/yyyy') OHDUEDATE,
               to_char(OHDUEDATE, 'yyyymmdd') OHDUEDATE2,
               OHINVAMT OHINVAMT1,
               OHOPNAMT OHOPNAMT1,
               OHREFNUM,
               ' ' NOMBRE_BANCO
          FROM ORDERHDR
         WHERE CUSTOMER_ID in (&customer_id)
           AND OHSTATUS IN ('IN', 'CM')
        Union
        SELECT CUSTOMER_ID,
               CH.CAXACT,
               CH.CAENTDATE,
               'Pago' Tipo,
               to_char(CH.CAENTDATE, 'dd/mm/yyyy') CAENTDATE,
               to_char(CH.CAENTDATE, 'yyyymmdd') CAENTDATE2,
               to_char(-CH.CACHKAMT, '999G999G999G999D99') CACHKAMT,
               ' ',
               ' ',
               ' ',
               -CH.CACHKAMT,
               0,
               ' ',
               CH.CABANKNAME
          FROM CASHRECEIPTS CH
         WHERE CH.CUSTOMER_ID in (&customer_id)
           AND (CH.CATYPE IN ('1', '3', '4', '7', '10', '12') OR
               (CH.CATYPE = '8' AND CH.CACHKAMT > 0))
        Union
        SELECT CUSTOMER_ID,
               CH.CAXACT,
               CH.CAENTDATE,
               'Ajuste' Tipo,
               to_char(CH.CAENTDATE, 'dd/mm/yyyy') CAENTDATE,
               to_char(CH.CAENTDATE, 'yyyymmdd') CAENTDATE2,
               to_char(-CH.CACHKAMT, '999G999G999G999D99') CACHKAMT,
               ' ',
               ' ',
               ' ',
               -CH.CACHKAMT,
               0,
               ' ',
               CH.CABANKNAME
          FROM CASHRECEIPTS CH
         WHERE CH.CUSTOMER_ID in (&customer_id)
           AND CH.CATYPE = '9'
        Union
        SELECT CUSTOMER_ID,
               CH.CAXACT,
               CH.CAENTDATE,
               'Anulaci�n' Tipo,
               to_char(CH.CAENTDATE, 'dd/mm/yyyy') CAENTDATE,
               to_char(CH.CAENTDATE, 'yyyymmdd') CAENTDATE2,
               to_char(CH.CACHKAMT, '999G999G999G999D99') CACHKAMT,
               ' ',
               ' ',
               ' ',
               CH.CACHKAMT,
               CH.CACHKAMT,
               ' ',
               CH.CABANKNAME
          FROM CASHRECEIPTS CH
         WHERE CH.CUSTOMER_ID in (&customer_id)
           AND CH.CARPP IS NOT NULL) X
group by x.CUSTOMER_ID;
