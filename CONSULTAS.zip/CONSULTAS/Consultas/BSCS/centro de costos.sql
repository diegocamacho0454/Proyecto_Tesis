SELECT ca.customer_id, cs.co_id, dn.dn_num
FROM CONTRACT_ALL ca, contr_services cs, directory_number dn
WHERE ca.co_id = cs.co_id
AND cs.dn_id = dn.dn_id
AND substr(cs.cs_stat_chng, -1) <> 'd'
AND dn.dn_num IN(
'3124488979'

);


select customer_id, area_id, costcenter_id
from customer_all
where customer_id in ('225874293');


select area_id Area, area_desc
from area
where area_desc like ('%BOGOTA%');

select area_id Area, area_desc
from area
where area_id ='100004';


SELECT cost_id Centro_de_Costos, cost_desc
from costcenter
where cost_desc like ('%BARRANQUILLA%');

select * from sysadm.costcenter where cost_id = 100016;

/*
UPDATE customer_all
SET AREA_ID = 100002 , 
COSTCENTER_ID = 100015 
WHERE CUSTOMER_ID IN ('158502395')
