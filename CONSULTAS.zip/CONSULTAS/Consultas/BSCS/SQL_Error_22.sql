select a.co_id, func_cap_co_id_GSM(co_id,'MIN',NULL) MIN,   func_cap_co_id_GSM(co_id,'IMSI',NULL) IMSI, 
        func_cap_co_id_GSM(co_id,'HLR',NULL)  HLR,          func_cap_co_id_GSM(co_id,'SERV',3013) ACT, 
        func_cap_co_id_GSM(co_id,'RCAT',NULL) RC,           func_cap_co_id_GSM(co_id,'PLPR',NULL) TipoPlan,
        func_cap_co_id_GSM(co_id,'CIC',NULL) CIC,           a.status , func_cap_co_id_GSM(co_id,'MIN',NULL) MIN,a.ref_text ,a.userid, a.insert_date, a.ts, a.* 
        from sysadm.MDSRRTAB a where co_id in (select co_id  FROM contr_services where dn_id in (
        select dn_id from directory_number where dn_num  in ('3115834408'))) order by REQUEST desc
   --for update; 
        ;
        
        
----------------------------CAP_ MASICOS y directory_number---------
SELECT A.*, ROWID FROM CAP_MASIVOS A WHERE MSISDN= '3124503368' ORDER BY FECHA DESC;


select * from directory_number where dn_num  in ('3124503368');

Select C.*, rowid
from directory_number C
where C.dn_num = ('&MIN');


--------------validar la disponibilidad de un min en cruce de mines----------------

SELECT a.dn_num, a.dn_status, a.dn_status_requ, a.hlcode 
FROM directory_number a 
WHERE a.dn_num = XXXXX



----------------------------------------------------------------------------------------------------------
--------------------INH:IMEi para validar el imei y que customer ID y fecha de activacion------------------

select * from inh_imei where imei = '351616061383004'; --- si muestra informacion es porque el IMEI esta atado a un Customer_ID se debe liberar
  
select * from inh_historico_imei where imei = '351616061383004';---Muestra el histrico de CUstomer_ID de un IMEI

select * from esn_robados where ESN = '351616061383004'; --- muestra si el IMEI o ICCID se encuantran en la lista de robados, Si paracen no se puede liberar. 




-------------------------------------------------------------------------------------
 ---------------------VALIDACION DE IMEI CON CUSTOMER _ID---------------------------

SELECT * FROM inh_imei WHERE customer_id ='179340489';


--------------------Validacion Compra de equipo (IMEI)-----------------
select * from activacion_equipo@activa where customer_id ='179340489';




-----------------------------------------------------------------------------------
-----------------------------------validacion con CO_ID-----------------------------

------consulta del contrato------


select * from contract_history where co_id = 232821769 order by ch_seqno asc;

----------------------------------
-- Para la ultima secuencia cd_activ_date - cd_moddate (null)
     
Select cd_seqno , co_id , cd_port_num , cd_activ_date , cd_validfrom, cd_entdate , cd_deactiv_date , cd_moddate ,
decode(substr(cd_sm_num,8,1),0,'Oriente',1,'Occidente',2,'Costa') Zona,
''''||cd_sm_num||''''||',' , ''''||port_id||''''||','  , 
cd_status ,  cd_pending_state  
from contr_devices a
where co_id in (179340489)
--where cd_sm_num = '89571011010042370833'
--where cd_port_num = '732101078607283'
order by CO_ID,cd_seqno asc 

--for update
; 

------------------------------------------------
-- -----validar el estado de una linea con inconvenientes de robo y perdida o duplicidad de ICCID-- en AC dmc521
select * from curr_co_device where co_id = '155406435';



--------------------------------------------------------------------------
-------------------------------validacion con ICCID----------------------
Select  
sm_serialnum , sm_status , sm_entdate , sm_moddate
from storage_medium 
where sm_serialnum in (
'89571010015077084861',
'89571010014032381603',
'89571010015077084861',
'89571014015128655152'
) ;

--------------------------------------------- 

select port_id , port_num , port_status , port_activ_date , port_deactiv_date , port_entdate , port_moddate
from port p
where port_id  in(
'202005795',
'193876441',
'216277874',
'193876441',
'237990776'
);

----------------------------------------------
select * from port where port_id  in(
'173859969'
);


-------------------------------------------------------------- 
------------------------Conciliaci�n BSCS CON CO_ID-----------------

declare
vc varchar2(30000);
begin
sysadm.proc_concilia(181062752,vc); 
DBMS_OUTPUT.put_line(vc);
end;

---------------------------------------------------------------------
--------------------------------------------------------------------
------------------cambio del estado en las tablas port y Storage---------------------
/*
update port p
set p.port_status = 'a'
where p.port_id = '178878912'
and p.port_status = 'd'


Update  storage_medium 
set sm_status = 'a'
where sm_serialnum ='89571012013118483703'
and sm_status = 'd'
*/

---------------------------------------------------------------------
-----------------------VALIDACION POR IMSI---------------------------

--- Consulta por IMSI

SELECT dn.dn_num, dn.dn_status, cs.co_id, cs.cs_seqno, 
       (SELECT tm.des
           FROM mputmtab tm
          WHERE tm.tmcode = cs.tmcode
            AND tm.vscode = (SELECT MAX(x.vscode)
                               FROM mputmtab x
                              WHERE x.tmcode = tm.tmcode)) tmdes,
       sysadm.func_cap_co_id(cs.co_id, 'PLPR', NULL) TipoPlan,
       cs.cs_stat_chng,
       cs.cs_deactiv_date,
       bs.port_num imsi,
       (SELECT x.cd_port_num 
           FROM sysadm.contr_devices x
          WHERE x.co_id = cs.co_id
            AND x.cd_seqno = (SELECT MAX(y.cd_seqno)
                                FROM sysadm.contr_devices y
                               WHERE y.co_id = x.co_id)) imsi_actual--,
       /*(SELECT x.hlr
           FROM cap_rangoshlr x
          WHERE dn.dn_num BETWEEN x.inicio AND x.final) hlr*/
  FROM (SELECT DISTINCT po.port_num, sm.sm_serialnum, cd.co_id
           FROM sysadm.port po, sysadm.storage_medium sm,
                sysadm.contr_devices cd
          WHERE po.port_num in (&IMSI)
            AND sm.sm_id = po.sm_id
            AND cd.cd_sm_num = sm.sm_serialnum) bs, sysadm.contr_services CS,
       directory_number DN
WHERE cs.co_id = bs.co_id
   AND dn.Dn_id = cs.dn_id
ORDER BY NVL(cs.cs_deactiv_date, SYSDATE) DESC;


-------------------------------------------------------------------

---------------------VALIDACION POR TMCODE---------------------------

-----Con la siguiente consulta en BSCS , con el TMCODE podremos evidenciar la descripci�n del plan:

select a.tmcode, a.des, e.descripcion, a.vsdate, a.vscode
  from mputmtab a, mpulktmb c, mpusptab d, ex_descplanes e
where a.tmcode in (&tmcode)
   and a.tmcode = c.tmcode
   and c.sncode in (3, 3013, 1)
   and c.spcode = d.spcode
   and a.shdes || d.shdes = e.shdes_mputmtab_mpusptab
   and a.vscode in
       (select max(b.vscode) from mputmtab b where b.tmcode = a.tmcode)
   and c.vscode in
       (select max(x.vscode) from mpulktmb x where c.tmcode = x.tmcode);
       
  ---------------------ERROR - 200------------------------
       
select * from inh_control_preactivacion where esn = '8957101401609103604%'; 

