select * from inh_upgamx_tabcontrol where msisdn = '3124312507';

select * from esn_robados where esn in ('89571014018013340351');

select * from SYSADM.CAP_STP where MSISDN in('3135694878');


----cambiar estado HA por ACTIVADO--- 
Select t.ESTADO, t.fecbscs, t.codmin, t.iccid, t.fecregis, t.*,rowid 
from activacionpre@activa.world t
Where codmin in('3223638851');


select t.estado,t.codmin,t.sexo,dn.dn_status, I.FECHA_REGISTRO, t.*
from activacionpre@activa t, inh_upgamx_tabcontrol i, directory_number dn
where i.estado = '0'
  and i.msisdn = t.codmin
  and t.estado in ('RechazadaHABAMX','MSISDN NO ACT')--,'Rechazada')
  and dn.dn_num = t.codmin
  and t.codmin = '3123326493'
  order by 5 
  ;

