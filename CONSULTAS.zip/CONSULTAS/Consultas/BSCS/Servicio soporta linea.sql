Select * from mpusntab n 
where des like '%cobrar%';

 select lk.tmcode,
 (select des from mputmtab tm where tm.tmcode = lk.tmcode and tm.status = 'W') PLAN,lk.vscode, lk.vsdate, lk.status, lk.spcode,
 (select des from mpusptab sp where sp.spcode = lk.spcode) Paquete ,lk.sncode,
 (select des from mpusntab sn where sn.sncode = lk.sncode) Servicio,lk.accessfee
 from mpulktmb lk
 where lk.tmcode = 19580
  and sncode = 8017
  -- and spcode = 4101
   and lk.vscode = (select max(lk1.vscode) from mpulktmb lk1 where lk1.tmcode = lk.tmcode and lk1.vsdate < sysdate)
 order by lk.tmcode, lk.spcode, lk.sncode, lk.accessfee;
