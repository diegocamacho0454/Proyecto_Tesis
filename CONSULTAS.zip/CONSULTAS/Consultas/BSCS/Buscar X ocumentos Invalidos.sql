---BUSCAR DOCUMENTOS INVALIDOS ----
select * from doc_invalidos_1 d
where numero_documento like '%1118533232%';
