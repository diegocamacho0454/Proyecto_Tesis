--***************************************************************************************************
-- Despliega los elegidos configurados en laslas tablas:

-- INH_ELEGIDOS para Pospago,
-- CICLOP.CAMBIO_PLAN_SINFIN@PLATAFORMA_PREPAGO Para Prepago.

--***************************************************************************************************
-- Luis Edgardo Morales. Hitss. Service Desk. 
-- 2014/09/08
--***************************************************************************************************

DECLARE
   TYPE ARREGLO IS TABLE OF VARCHAR2(25);
   arListado   ARREGLO := ARREGLO(    
&vArreglo
   );

   nmCoId       NUMBER;
   nmvarlin     NUMBER;
   nmDnid       NUMBER;
   VcElMpuf     VARCHAR2(50);
   NmEleInh     NUMBER;
   VcDescEl     VARCHAR2(50);
   FeIngEle     DATE;
   Feproc       DATE;
   Vcshdes      VARCHAR2(5);
   Vcdes        VARCHAR2(30);
   NmFnf        VARCHAR2(15);
   VcEleg       VARCHAR2(15);
   Vcsalmin     VARCHAR2(15);
   Vcminelg     VARCHAR2(15);
   

  PROCEDURE prcBuscarDatos(vcMsisdn IN VARCHAR2,
                           nmCoId  OUT NUMBER) IS
   BEGIN

      nmCoId  := NULL;

      SELECT cs.co_id ,  cs.dn_id
        INTO nmCoId , nmDnid
        FROM sysadm.directory_number dn, sysadm.contr_services cs
        WHERE dn.dn_num = vcMsisdn
        AND cs.dn_id = dn.dn_id
        AND (substr(cs.cs_stat_chng, -1) <> 'd' or substr(cs.cs_stat_chng, -1) IS NULL);
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
      NULL;
      WHEN TOO_MANY_ROWS THEN
            DBMS_OUTPUT.put_line(vcMsisdn||' '||nmCoId||' '||'Min asignado a varias lineas Dn_id : '||' '||nmDnid);       
            Nmvarlin := 1;
   END;

 
BEGIN

--dbms_output.put_line('Min'||','||'PREPAGO'||','||'Fecha');  
  
   FOR i IN arListado.first .. arListado.last
     
    LOOP   
      prcBuscarDatos(arListado(i), nmCoId);


--SELECT A.*, ROWID  FROM INH_ELEGIDOS_NEW.INH_ELEGIDOS A WHERE CO_ID = 157064917; 

     dbms_output.put_line('------------------------------------------------------ ');
     dbms_output.put_line('MIN >  '||' '||arListado(i)); 
     dbms_output.put_line(' ');    
     dbms_output.put_line('Elegidos Pospago  > ');  
     dbms_output.put_line(' ');     
     
         FOR X IN (SELECT min_elegido , shdes , feregistro  
                   FROM INH_ELEGIDOS_NEW.INH_ELEGIDOS A 
                   WHERE CO_ID = nmCoId)
                
           LOOP

     Vcsalmin := arListado(i); 

     dbms_output.put_line('INH_ELEGIDOS > '||' '|| x.min_elegido||' '||x.shdes||' '||x.feregistro );

                        
          END LOOP;                   

-- SELECT * FROM CICLOP.CAMBIO_PLAN_SINFIN@PLATAFORMA_PREPAGO WHERE MIN in ('3138995186'); 

     dbms_output.put_line(' ');
     dbms_output.put_line('Elegidos Prepago  > '); 
     dbms_output.put_line(' ');

          FOR Y IN 1 .. 9

LOOP        

--      dbms_output.put_line('CAMBIO_PLAN_SINFIN  : '||' '||NmCon);

        SELECT 'fnf_'||Y
        INTO VcEleg 
        FROM DUAL;
  
   --  dbms_output.put_line(mina);
 BEGIN            
          SELECT DECODE(y,1,fnf_1,2,fnf_2,3,fnf_3,4,fnf_4,5,fnf_5,6,fnf_6,7,fnf_7,8,fnf_8,9,fnf_9), fecha_procesado
          INTO NmFnf , Feproc
          FROM CICLOP.CAMBIO_PLAN_SINFIN@PLATAFORMA_PREPAGO 
          WHERE  VcEleg = VcEleg
          AND MIN =  arListado(i);
                EXCEPTION
                WHEN NO_DATA_FOUND THEN
                NULL;
COMMIT;
END;

          IF NmFnf IS NOT NULL THEN
            
  --           dbms_output.put_line('PREPAGO : '||' '||NmFnf||' '||Feproc);

dbms_output.put_line('CAMBIO_PLAN_SINFIN > '||' '||NmFnf||' '||Feproc||' '||Vcminelg);
             
          END IF;             

  END LOOP;
 COMMIT;
--dbms_output.put_line(Vcsalmin);

        END LOOP;
END;










