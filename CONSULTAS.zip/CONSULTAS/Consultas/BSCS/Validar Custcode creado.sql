
-----------------Customer ID-------------------------------------
SELECT a.dn_num, b.co_id, b.cs_seqno, b.tmcode, b.cs_stat_chng, b.cs_deactiv_date, d.customer_id, d.custcode
  FROM directory_number a, contr_services b, contract_all c, customer_all d
WHERE a.dn_num in ('3202108511')
   AND b.dn_id = a.dn_id
   AND c.co_id = b.co_id
   AND d.customer_id = c.customer_id
   --AND b.cs_deactiv_date IS NULL 
  ORDER BY nvl(b.cs_deactiv_date,SYSDATE) DESC ;

-----validar existencia custcod-------

SELECT i.custcode_equipo,i.customer_id_equipo,i.fecha_registro,i.ciclo,c.customer_id,c.customer_id_high,c.paymntresp 
FROM sysadm.inh_rel_equ_ser i, sysadm.customer_all c 
WHERE i.customer_id_servicio (+) = NVL2(c.paymntresp,c.customer_id,c.customer_id_high) 
and c.customer_id = '249149225';
--- validar valores-----

SELECT A.CUSTCODE_NUEVO, A.SEQ_EQ_USUARIO, A.NRO_TOTAL_CUOTAS, A.*
FROM activacion_equipo@activa A WHERE A.CUSTOMER_ID = '129841031';    

-- Referencia de Equipo ---
SELECT * FROM SYSADM.INH_REL_EQU_SER S WHERE S.CUSTOMER_ID_SERVICIO = '249149225';
--- Validar el OCC creado con el periodo y valor de la cuota --- 
SELECT * FROM SYSADM.FEES f WHERE F.CUSTOMER_ID = '249149225';
