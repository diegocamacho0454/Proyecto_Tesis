--selecciono al cliente y el codigo de la promocion
select *
  from sysadm.ex_cliente_promo c
where c.co_id in (156091585)
   --and c.estado <> 'fin'
order by fec_prom desc;

--busco el codigo de la promocion y los meses que se le dara la promocion
select * from sysadm.ex_promo_cfm c where c.co_prom=99;--2,6  

--busco la fecha en la que se le dio la promocion,
select * from inh_prom_clientes p where p.co_id = 18026303 and p.customer_id=yyyyyy;

--valida el estado del contrato y de los servicios
SELECT *
  FROM sysadm.contr_services cs
WHERE co_id = 156091585
   AND sncode = 3013
   AND cs_seqno = (SELECT /*+ index(cs, pkcontr_services) */
                    MAX(cs_seqno)
                     FROM contr_services cs
                    WHERE co_id = 156091585
                      AND sncode + 0 IN (3, 3013))
AND substr(cs_stat_chng, -1) IN ('a', 's', 'd');
