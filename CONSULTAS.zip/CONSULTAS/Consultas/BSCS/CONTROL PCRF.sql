
---------------------------------------CONTROL GPRS----------------------------------------------------------
select * from CAP_CONTROL_GPRS where msisdn in ('3167405054');
--------------------------------------TRANSACCIONES BSCS-PCRF-MAGUARE--------------------------------------------
select request,co_id,accion,Estado,msisdn,tmcode,fecha_registro,fecha_procesado,respuesta 
from SYSADM.CAP_PCRF_EVENTO e 
where e.msisdn in ('3106086166') order by e.fecha_procesado desc;

--------------CALIDAD PAQUETE GPRS-------------
select a.*,a.rowid from CAP_CONF_DATOS A WHERE SPCODE = 5014;
select a.*,a.rowid from CAP_CONF_DATOS A WHERE TMCODE = 10342;
--Si al validar el campo CUSTOM3 y este se encuentra en MIXTO, se debe validar el escenario 3.

select * from sysadm.cap_pcrf_all a where MSISDN IN ( '573214376389');

---------------------------------------CONFIGURACI�N PAQUETE GPRS--------------------------------------------------
----validar configuracion del paquete----
select a.* from CAP_CONF_DATOS A WHERE SPCODE = 4103; 
----validar configuracion del plan----
select a.* from CAP_CONF_DATOS A WHERE TMCODE IN ('17064','16022');


--------Transacciones de linea----------------
select a.co_id, sysadm.func_cap_co_id_GSM(co_id,'MIN',NULL) MIN, 
sysadm.func_cap_co_id_GSM(co_id,'IMSI',NULL) IMSI, func_cap_co_id_GSM(co_id,'HLR',NULL)  HLR,
sysadm.func_cap_co_id_GSM(co_id,'SERV',3013) ACT, func_cap_co_id_GSM(co_id,'RCAT',NULL) RC,
sysadm.func_cap_co_id_GSM(co_id,'PLPR',NULL) TipoPlan, func_cap_co_id_GSM(co_id,'CIC',NULL) CIC,
a.status , sysadm.func_cap_co_id_GSM(co_id,'MIN',NULL) MIN,  a.ref_text ,a.userid, a.insert_date, a.ts, a.* from sysadm.MDSRRTAB a 
where co_id in (select co_id  FROM contr_services where dn_id 
in (select dn_id from directory_number where dn_num  in ('3214376389'))) order by REQUEST desc;


--------------- SERVICIOS DE UNA LINEA -------------
SELECT M.SNCODE,M.DES,C.SPCODE,S.DES,CS_SEQNO,CS_STAT_CHNG, C.ROWID,
(SELECT DES FROM MPUTMTAB WHERE TMCODE = C.TMCODE AND STATUS = 'W') PLAN_TARIFARIO,C.*
FROM CONTR_SERVICES C, MPUSNTAB M, MPUSPTAB S WHERE M.SNCODE = C.SNCODE AND S.SPCODE = C.SPCODE
AND CO_ID = 122008027 ORDER BY C.CS_SEQNO    DESC, 2, C.SNCODE;


