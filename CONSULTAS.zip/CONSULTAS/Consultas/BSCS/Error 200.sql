select * from inh_control_preactivacion d where d.esn ='201501306197';
delete from inh_control_preactivacion d where d.esn ='401711353961'
