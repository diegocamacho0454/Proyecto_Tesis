--***************************************************************************************************
-- El dato de entrada para este scrip es el CO_ID
-- Procediemiento para conciliacion de Lineas.

--***************************************************************************************************
-- Luis Edgardo Morales. Hitss. Service Desk. 
-- 2014/12/04
--***************************************************************************************************

DECLARE

   TYPE ARREGLO IS TABLE OF VARCHAR2(25);
   arListado   ARREGLO := ARREGLO( &coid );

   vrespuesta   VARCHAR2(200);
   Nmcontrato   NUMBER;
   
 
BEGIN

   FOR i IN arListado.first .. arListado.last

       LOOP
         
       Nmcontrato := arListado(i); 

       proc_concilia( Nmcontrato	,	vrespuesta);
 
       commit;
       
       DBMS_OUTPUT.PUT_LINE('Co_id : '||' '||arListado(i)||' '||vrespuesta);      
                               
       END LOOP;                   


END;

