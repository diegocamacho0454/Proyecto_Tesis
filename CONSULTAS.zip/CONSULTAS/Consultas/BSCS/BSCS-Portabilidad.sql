---CONSULTA VALIDA_ESTADO_ACTUAL_LINEA----
SELECT a.dn_num, a.dn_status,a.Hlcode,rowid, 
(SELECT x.co_id 
FROM contr_services x 
WHERE x.dn_id = a.dn_id 
AND SUBSTR(x.cs_stat_chng, -1) <> 'd') CO_ID 
FROM directory_number a 
WHERE a.dn_num IN ('3166999923')
ORDER BY a.dn_status;

---CONSULTA VALIDA_LOG_PORTABILIDAD---
SELECT A.* 
FROM (SELECT MSISDN, 
             CO_ID, 
             NRN DESTINO, 
             FECHA_DESACTIVACION FECHA, 
             'P-OUT' EVENTO 
      FROM SYSADM.INH_LOGDESACTIVACION_PN A 
      WHERE A.MSISDN = '&MSISDN' 
      UNION 
      SELECT MSISDN, CO_ID, DESTINO, FECHA, 'P-OUT' EVENTO 
      FROM CAP_PORTED_OUT A 
      WHERE A.MSISDN = '&MSISDN' 
      UNION
      SELECT DN_NUM MSISDN, 
             NULL CO_ID, 
             NULL DESTINO, 
             FECHA, 
             'REPATRIACION' EVENTO 
             FROM SYSADM.INH_REPATRIACION A 
             WHERE A.DN_NUM = '&MSISDN' 
           UNION
           SELECT DN_NUM MSISDN, 
                  NULL CO_ID, 
                  NULL DESTINO, 
                  FECHA_PROCESO FECHA, 
                  'CANCELACION' EVENTO 
                  FROM SYSADM.INH_DEVPORTANODE A 
                  WHERE A.DN_NUM = '&MSISDN' 
                  UNION SELECT /*+ INDEX (UQDIRNUM_NUM_ENT b) */ 
                  B.DN_NUM MSISDN, 
                  A.CO_ID, 
                  NULL DESTINO, 
                  A.ENTDATE FECHA, 
                  DECODE(A.CH_STATUS, 
                             'o', 
                             'ACTIVACION',
                             'd', 
                             'DESACTIVACION', 
                             A.CH_STATUS) EVENTO --, c.* 
                FROM CONTRACT_HISTORY A, DIRECTORY_NUMBER B, CONTR_SERVICES C 
                WHERE B.DN_NUM = '&MSISDN' 
                AND C.DN_ID = B.DN_ID 
                AND A.CO_ID = C.CO_ID 
                AND A.CH_STATUS IN ('o', 'd')) A 
                ORDER BY FECHA DESC;
                
                
 ---CONSULTA CONOCE_DESTINO_MSISDN_PORT_OUT---
 SELECT DN_NUM MIN, PO.DESTINO DESTINO 
 FROM SYSADM.CAP_PORTED_OUT PO, 
      SYSADM.CONTR_SERVICES CS, 
      DIRECTORY_NUMBER D 
 WHERE PO.CO_ID = CS.CO_ID 
   AND CS.DN_ID = D.DN_ID 
   AND PO.FECHA = 
   (SELECT MAX(X.FECHA) FROM CAP_PORTED_OUT X WHERE X.CO_ID = PO.CO_ID) 
   AND D.DN_NUM IN ('&MSISDN');


-----activacion linea en Prepago-----   
select * from inh_infoactprepago t where t.codmin in ('3226931843') and t.coid = 145273067;   

--select T.ESTADOPREPAGO, t.* from inh_infoaprovprepago t where t.codmin in ('3188777873') and t.coid = 173695425;


--- PARA VALIDAR PORTABILIDAD----

 Select ESTADO, fecbscs, codmin, iccid, t.*, rowid
 from activacionpre@activa t
 Where codmin in ('3166999923');

