-- tipo de plan

SELECT a.dn_num, b.co_id, b.tmcode,
       (SELECT sysadm.fncextraer(x.clase_plan, ',', 3)
           FROM inh_tmsp_prep x
          WHERE x.tmcode = b.tmcode
            AND ROWNUM = 1) clase_plan
  FROM directory_number a, contr_services b
WHERE a.dn_num IN ('&min')
   AND b.dn_id = a.dn_id
   AND SUBSTR(b.cs_stat_chng, -1) <> 'd';
   --


SELECT * from sysadm.inh_promocion_cfm_pol WHERE co_id IN (SELECT co_id
                                                        FROM contr_services   a,
                                                             directory_number b
                                                       WHERE a.dn_id =
                                                             b.dn_id
                                                         AND b.dn_num in ('&min'));
                  
SELECT *
  FROM sysadm.ex_cliente_promo
WHERE co_id IN (SELECT co_id
                   FROM contr_services a, directory_number b
                  WHERE a.dn_id = b.dn_id
                    AND b.dn_num in ('&min'));--**************************************************;
                   
/*SELECT m.des, c.*
  FROM contr_services c, mpusntab m
WHERE c.sncode = m.sncode
   AND co_id IN (SELECT a.co_id
                   FROM contr_services a
                   JOIN (SELECT dn_num, dn_id
                          FROM directory_number
                         WHERE dn_num in ('&min')) b
                     ON (a.dn_id = b.dn_id))
                     and substr(c.cs_stat_chng, -1) <> 'd';*/

--HISTORIA CONTRATO
-----------------------------------------
--select * from contr_services  WHERE co_id = 7751521

SELECT *
  FROM contract_history h
WHERE co_id IN ((SELECT a.co_id
                   FROM contr_services a
                   JOIN (SELECT dn_num, dn_id
                          FROM directory_number
                         WHERE dn_num in ('&min')) b
                     ON (a.dn_id = b.dn_id)))order by ch_validfrom desc;

--CICLO
-----------------------------------------
SELECT al.billcycle, al.*
  FROM customer_all al
WHERE customer_id IN
       (SELECT customer_id
          FROM contract_all
         WHERE co_id IN (SELECT co_id
                           FROM contr_services a, directory_number b
                          WHERE a.dn_id = b.dn_id
                            AND b.dn_num in ('&min')));
                            
/*SELECT * 
FROM INH_CICLOS 
WHERE CICLO =  10   
IN (                      SELECT CO_ID
                           FROM contr_services a, directory_number b
                          WHERE a.dn_id = b.dn_id
                            AND b.dn_num in ('3212158891')
                            AND SUBSTR(a.cs_stat_chng, -1) = 'd'
                            )
                            ;*/

--CLIENTES 
-----------------------------------------
SELECT *
  FROM inh_prom_clientes
WHERE customer_id in (SELECT customer_id
          FROM contract_all
         WHERE co_id IN (SELECT co_id
                           FROM contr_services a, directory_number b
                          WHERE a.dn_id = b.dn_id
                            AND b.dn_num in ('&min')));

--USUARIOS
-----------------------------------------
SELECT *
  FROM inh_prom_ejeusuarios  
WHERE co_id -- = 66466390;
       IN ((SELECT a.co_id
             FROM contr_services a
             JOIN (SELECT dn_num, dn_id
                    FROM directory_number
                   WHERE dn_num in ('&min')) b
               ON (a.dn_id = b.dn_id)));
--TICKLER 



SELECT a.created_date, a.created_by,tickler_code, a.customer_id, a.tickler_number,a.tickler_status, a.short_description, a.long_description, a.co_id ,a.closed_date 
  FROM tickler_records a 
WHERE customer_id in (SELECT customer_id
          FROM contract_all
         WHERE co_id IN (SELECT co_id
                           FROM contr_services a, directory_number b
                          WHERE a.dn_id = b.dn_id
                            AND b.dn_num in ('&min')
                                                  ))
ORDER BY created_date DESC;

SELECT *
  FROM fees
WHERE customer_id IN
       (SELECT customer_id
          FROM contract_all
         WHERE co_id IN (SELECT co_id
                           FROM contr_services a, directory_number b
                          WHERE a.dn_id = b.dn_id
                            AND b.dn_num in ('&min')))
ORDER BY seqno;
---
select * from sysadm.ex_promo_cfm where co_prom in (SELECT f.co_prom
  FROM sysadm.ex_cliente_promo f
 WHERE co_id IN (SELECT co_id
                   FROM contr_services a, directory_number b
                  WHERE a.dn_id = b.dn_id
                    AND b.dn_num IN ('&min')))  
                       ;                                                        
                                                             
-----TMCODE PLAN VIEJO Y NUEVO EN BSCS DE REPORTES-----
            select * from sysadm.inh_cambio_plan_hechos where customer_id IN
       (SELECT customer_id
          FROM contract_all
         WHERE co_id IN (SELECT co_id
                           FROM contr_services a, directory_number b
                          WHERE a.dn_id = b.dn_id
                            AND b.dn_num in ('&min')));
 --
   
                                           
