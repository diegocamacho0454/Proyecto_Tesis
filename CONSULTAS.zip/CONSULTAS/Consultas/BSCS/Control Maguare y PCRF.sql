--***************************************************************************************************

-- Valida si las lineas entan controladas en Maguare y PCRF

--***************************************************************************************************
-- Creado por:
-- Luis Edgardo Morales. Hitss. Service Desk.
-- 2014/10/14
-- Modificado por:
-- Jhonnatan Camilo Ortiz Soriano. Hitss. Service Desk. 
-- 2015/02/18
--***************************************************************************************************

DECLARE
   TYPE ARREGLO IS TABLE OF VARCHAR2(25);
   arListado   ARREGLO := ARREGLO(    
&vArreglo
   );
  

   nmCoId       NUMBER;
   vcMsisdn     VARCHAR2(15);
   nmvarlin     NUMBER;
   nmDnid       NUMBER;
   Nmtmcode     NUMBER;
   Nmspcode     NUMBER;
   VrConMag     VARCHAR2(15);
   VcDesarr     VARCHAR2(15);
   NmCtaMag     NUMBER;
   VcActivo     VARCHAR2(15);
   
   
  PROCEDURE prcBuscarDatos(vcMsisdn IN VARCHAR2,
                           nmCoId  OUT NUMBER) IS
   BEGIN

      nmCoId  := NULL;

      SELECT cs.co_id ,  cs.dn_id
        INTO nmCoId , nmDnid
        FROM sysadm.directory_number dn, sysadm.contr_services cs
        WHERE dn.dn_num = vcMsisdn
        AND cs.dn_id = dn.dn_id
        AND (substr(cs.cs_stat_chng, -1) <> 'd' or substr(cs.cs_stat_chng, -1) IS NULL);
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
      NULL;
      WHEN TOO_MANY_ROWS THEN
            DBMS_OUTPUT.put_line(vcMsisdn||' '||nmCoId||' '||'Min asignado a varias lineas Dn_id : '||' '||nmDnid);       
            Nmvarlin := 1;
   END;


PROCEDURE prcBuscaMaguarePCRF(vcMsisdn IN VARCHAR2,
                          VrConMag  OUT VARCHAR2
                          ) IS
   BEGIN

    SELECT DECODE(COUNT(*),1,'Controlada','NO')
    INTO VrConMag 
    FROM CAP_CONTROL_GPRS          
    WHERE msisdn in (vcMsisdn)
    AND rownum = 1;
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
          VrConMag :='No' ; 
          
   END;

  
PROCEDURE prcBuscaTmcode(nmCoId IN VARCHAR2,
                         Nmtmcode  OUT VARCHAR2
                         ) IS
   BEGIN

    SELECT tmcode 
    INTO Nmtmcode
    FROM contr_services a 
    WHERE cs_seqno = ( SELECT max(cs_seqno)
                       FROM contr_services b
                       WHERE a.co_id = b.co_id 
                       AND a.sncode = b.sncode)
    and co_id = nmCoId
    AND a.sncode = 3013;
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
          NULL;

   END;
   
PROCEDURE prcBuscaSpcode(nmCoId IN VARCHAR2,
                         Nmspcode OUT NUMBER,
                         VcActivo  OUT VARCHAR2
                         ) IS
   BEGIN

    SELECT spcode, cs_stat_chng
    INTO Nmspcode, VcActivo
    FROM contr_services a 
    WHERE cs_seqno = ( SELECT max(cs_seqno)
                       FROM contr_services b
                       WHERE a.co_id = b.co_id 
                       AND a.sncode = b.sncode)
    and co_id = nmCoId
    AND a.sncode = 3288;
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
          NULL;

   END;

PROCEDURE prcBuscaPCRFTmcode(Nmtmcode  IN NUMBER,
                       VcDesarr OUT VARCHAR2
                         ) IS
   BEGIN
     
    SELECT desarrollo
    INTO VcDesarr
    FROM cap_conf_datos 
    WHERE  tmcode= Nmtmcode;
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
          NULL;        


   END;

PROCEDURE prcBuscaPCRFSpcode(Nmspcode IN NUMBER,
                       VcDesarr OUT VARCHAR2
                         ) IS
   BEGIN
     
    SELECT desarrollo
    INTO VcDesarr
    FROM cap_conf_datos 
    WHERE  spcode= Nmspcode;
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
          NULL;        


   END;   

 --********************************************************************************
 -- Inicio
 --********************************************************************************   

BEGIN

dbms_output.put_line('MIN'||','||'CO_ID'||','||'TMCODE'||','||'SPCODE'||','||'DATOS'||','||'MAGUARE'||','||'SERVICIO');
  
   FOR i IN arListado.first .. arListado.last
     
    LOOP  
 
    vcMsisdn := arListado(i); 
     
 --********************************************************************************
 -- Busca datos.
 --********************************************************************************
     
    prcBuscarDatos(arListado(i), nmCoId);
    prcBuscaTmcode(nmCoId,Nmtmcode);
    prcBuscaSpcode(nmCoId,Nmspcode,VcActivo);
    prcBuscaPCRFTmcode(Nmtmcode,VcDesarr);
    prcBuscaMaguarePCRF(arListado(i),VrConMag);
    
    IF (VcDesarr IS NULL) THEN
      prcBuscaPCRFSpcode(Nmspcode,VcDesarr);
    END IF;

    dbms_output.put_line(arListado(i)||','||nmCoId||','||Nmtmcode||','||Nmspcode||','||VcDesarr||','||VrConMag||','||VcActivo); 

    END LOOP;

END;




