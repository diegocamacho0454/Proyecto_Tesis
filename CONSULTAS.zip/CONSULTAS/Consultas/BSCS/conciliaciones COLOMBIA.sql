
--------------------------- REVISION DE LA LINEA ------------------------------------------------------------

SELECT A.CO_ID, FUNC_CAP_CO_ID_GSM(CO_ID,'MIN',3005) MIN,   FUNC_CAP_CO_ID_GSM(CO_ID,'IMSI',3005) IMSI,
FUNC_CAP_CO_ID_GSM(CO_ID,'HLR',NULL)  HLR,          FUNC_CAP_CO_ID_GSM(CO_ID,'SERV',3013) ACT,  --3013 --0001
FUNC_CAP_CO_ID_GSM(CO_ID,'RCAT',NULL) RC,           FUNC_CAP_CO_ID_GSM(CO_ID,'PLPR',NULL) TIPOPLAN,
FUNC_CAP_CO_ID_GSM(CO_ID,'CIC',3005) CIC,           A.STATUS ,A.REF_TEXT, A.USERID, A.INSERT_DATE, A.TS, A.* 
FROM SYSADM.MDSRRTAB A WHERE CO_ID IN (SELECT CO_ID  FROM CONTR_SERVICES WHERE DN_ID IN (
SELECT DN_ID FROM DIRECTORY_NUMBER WHERE DN_NUM  IN ('&MIN'))) ORDER BY REQUEST DESC;  

--------------------------- ELEGIDOS DE LA LINEA -------------------------------------------------
SELECT a.rowid, a.*          FROM EX_DESACTIVSERVICIO a WHERE CO_ID IN (SELECT CO_ID  FROM CONTR_SERVICES WHERE DN_ID IN (
SELECT DN_ID FROM DIRECTORY_NUMBER WHERE DN_NUM  IN ('&MIN')));
SELECT A.*, ROWID  FROM MPUFFTAB A           WHERE CO_ID IN (SELECT CO_ID  FROM CONTR_SERVICES WHERE DN_ID IN (
SELECT DN_ID FROM DIRECTORY_NUMBER WHERE DN_NUM  IN ('&MIN')));
SELECT A.*, ROWID  FROM INH_ELEGIDOS_NEW.INH_ELEGIDOS A WHERE CO_ID IN (SELECT CO_ID  FROM CONTR_SERVICES WHERE DN_ID IN (
SELECT DN_ID FROM DIRECTORY_NUMBER WHERE DN_NUM  IN ('&MIN'))); 
SELECT *           FROM RED_INT                         WHERE CO_ID IN (SELECT CO_ID  FROM CONTR_SERVICES WHERE DN_ID IN (
SELECT DN_ID FROM DIRECTORY_NUMBER WHERE DN_NUM  IN ('&MIN')));
SELECT *           FROM  sysadm.inh_eleg5_log  l        WHERE CO_ID IN (SELECT CO_ID  FROM CONTR_SERVICES WHERE DN_ID IN (
SELECT DN_ID FROM DIRECTORY_NUMBER WHERE DN_NUM  IN ('&MIN')));
SELECT * FROM CICLOP.CAMBIO_PLAN_SINFIN@PLATAFORMA_PREPAGO WHERE MIN in ('&MIN');

--------------------------------------------------------------------------------

SELECT a.rowid, a.*          FROM EX_DESACTIVSERVICIO a WHERE CO_ID = '&COID';       
SELECT A.*, ROWID  FROM MPUFFTAB A                      WHERE CO_ID = '&COID';      
SELECT A.*, ROWID  FROM INH_ELEGIDOS_NEW.INH_ELEGIDOS A WHERE CO_ID = '&COID';  
SELECT *           FROM RED_INT                         WHERE CO_ID = '&COID';
SELECT *           FROM  sysadm.inh_eleg5_log  l        WHERE CO_ID = '&COID';
SELECT *           FROM CONTR_SERVICES CS               WHERE CS.CO_ID IN (&COID) AND CS.MAIN_DIRNUM = 'X' ORDER BY 1, 5; --CONOCER EL PLAN ACTUAL DE CONTRATO. 
SELECT I.*, TM.DES FROM INH_CAMBIO_PLAN_HECHOS I, MPUTMTAB TM WHERE I.CUSTOMER_ID IN (SELECT CUSTOMER_ID FROM CONTRACT_ALL WHERE CO_ID IN (&COID)) AND I.TMCODE = TM.TMCODE AND TM.STATUS = 'W' ORDER BY I.FECHA; --LOS CAMBIOS DE PLANES DE UN CONTRATO.


SELECT CS.CO_ID, CS.TMCODE, CS.SPCODE, CS.CS_SEQNO, CS.CS_STAT_CHNG, I.MICROCELDA FROM CONTR_SERVICES CS, INH_TMSP_PREP I WHERE CS.CO_ID IN (&COID) AND CS.MAIN_DIRNUM = 'X' AND CS.TMCODE = I.TMCODE ORDER BY CS.CS_SEQNO;--MICROCELDAS QUE SOPORTA EL PLAN ACTUAL DEL CONTRATO
SELECT *           FROM INH_TMSP_PREP                   WHERE TMCODE IN (12776); --MICROCELDAS QUE SOPORTA UN PLAN

select * From sysadm.red_int_historico2013 where co_id = '104894734';

------------------------------------------------------------

SELECT * FROM CAP_NCC WHERE TELEFONO = '3113439352';
select * from INH_SUBSIDIO WHERE CO_ID =95092716;
SELECT * FROM CONTR_SERVICES  WHERE CO_ID = '10838718';
--------------------------- SERVICIOS DE UNA LINEA -----------------------------------------------------------

SELECT M.SNCODE,M.DES,C.SPCODE,S.DES,CS_SEQNO,CS_STAT_CHNG FECHA, C.ROWID,
(SELECT DES FROM MPUTMTAB WHERE TMCODE = C.TMCODE AND STATUS = 'W') PLAN_TARIFARIO,C.*
FROM CONTR_SERVICES C, MPUSNTAB M, MPUSPTAB S WHERE M.SNCODE = C.SNCODE AND S.SPCODE = C.SPCODE
AND CO_ID = 225001549 ORDER BY C.CS_SEQNO    DESC, 2, C.SNCODE;
SELECT * FROM SYSADM.CONTR_SERVICES A WHERE A.CO_ID=165354478;

select * from cap_masivos_historico where msisdn = '3113439352';

--------------------------- HISTORICO DE SERVICIO DE LA LINEA -------------------------------------------------

SELECT N.SNCODE, N.DES, I.SPCODE, S.DES, CS_SEQNO, CS_STAT_CHNG,
(SELECT DES FROM MPUTMTAB WHERE TMCODE = I.TMCODE AND STATUS = 'W') PLAN_TARIFARIO, I.*
FROM INH_DELETE_CONTR I, MPUSPTAB S, MPUSNTAB N
WHERE I.SPCODE = S.SPCODE AND I.SNCODE = N.SNCODE
AND CO_ID = '165354478' ORDER BY I.CS_SEQNO DESC, 2, I.SNCODE;

----Aprovisionamiento de Elegidos a Plataforma Prepago---------------------------

SELECT * FROM CICLOP.CAMBIO_PLAN_SINFIN@PLATAFORMA_PREPAGO WHERE MIN in
(
'&min'
);
 
-- ELEGIDOS
select a.*, a.rowid
  from mpufftab a
where co_id in (SELECT co_id
                   FROM contr_services a, directory_number b
                  WHERE a.dn_id = b.dn_id
                    AND b.dn_num in ('&min'));
                   
-- REDINT
SELECT i.fecha_creacion,i.*
  FROM sysadm.red_int i
  where co_id in (SELECT co_id
                            FROM contr_services a, directory_number b
                           WHERE a.dn_id = b.dn_id
                             AND b.dn_num in ('&min'))
 ORDER BY i.shdes, i.fecha_creacion,i.rowid desc ;

--------------------------- LOS ELEGIDOS QUE DEBEN INSTALARSE CUANDO SE REALICE EL CAMBIO DE PLAN --------------------------------------------------

SELECT CUSTOMER_ID, TICKLER_NUMBER,FECHA_CREACION,NROS_DESTINO,ELEGIDO_FIJO,PORCENTAJE,MICRO_CELDA,TMCODE, (SELECT MICROCELDA FROM INH_TMSP_PREP I WHERE I.TMCODE = J.TMCODE) MICROCELDA_CNF FROM INH_TICKLER_FUTURO J WHERE CUSTOMER_ID IN (SELECT CUSTOMER_ID FROM CONTRACT_ALL WHERE CO_ID IN (&COID)); 
SELECT * FROM TICKLER_RECORD_HISTORICO WHERE CUSTOMER_ID in('30336856');

--------------------------- IMSI (CD_PORT_NUM) ACTUAL DE UNA L�NEA -----------------------------------------------

SELECT A.CD_PORT_NUM, a.co_id
FROM CONTR_DEVICES A
WHERE A.CO_ID in (182398269) 
AND A.CD_SEQNO =(SELECT MAX(B.CD_SEQNO) FROM CONTR_DEVICES B WHERE A.CO_ID = B.CO_ID);

--------------------------- CASO UPGRADE -----------------------------------------------------------------------------
     
SELECT * FROM ACTIVACION@ACTIVA WHERE ESTADO != ('ACTIVADO') AND FECREGIS >= TO_DATE ('24/05/2012','DD/MM/YYYY'); 
SELECT COUNT(*) FROM ACTIVACION@ACTIVA WHERE  RESN = 10;
SELECT * FROM ACTIVACION@ACTIVA a WHERE a.CODMIN= '3214729688'; -- Para caso UPGRADE 
SELECT * FROM EXTRANET.ACTIVACION_UPGRADE_SALDO@ACTIVA WHERE ID_ACTIVACION IN (45206477); -- Para caso UPGRADE

SELECT a.*, rowid FROM ACTINCLUSION@ACTIVA A WHERE A.CODMIN IN ('3106356591');
SELECT A.ESTADO, A.DISTRIBUIDOR1, A.CO_ID, A.TEXT5, A.CODMIN, A.COLGAR_A_MAESTRA, A.ROWID FROM ACTINCLUSION@ACTIVA A  WHERE A.CODMIN IN ('3138882199'),'3142476306','3103916066','3146162930') AND DISTRIBUIDOR1 LIKE ('SAU21.00049');---VALIDAR SI LA INCLUSION QUEDO OK 
SELECT A.ID_ACTIVACION, A.CODMIN, A.ESTADO, A.RESN, A.FECREGIS         FROM ACTIVACIONPRE@ACTIVA A WHERE A.CODMIN = '3137354607';

-----------------------------------------------------------------------------------------------------------------------

SELECT *          FROM INH_INFOACTPREPAGO    WHERE FECACTIV > TO_DATE ('24/12/2011','DD/MM/YYYY');
SELECT A.*,ROWID  FROM INH_INFOACTPREPAGO A  WHERE CODMIN in('3147152347') ORDER BY COID DESC; -- REPORTE DE LINEAS PREPAGO A PLATAFORMA PREPA CON EVENTOS DE ACTIVACIONES 
SELECT *          FROM SYSADM.INH_INFOAPROVPREPAGO       WHERE CODMIN = '3134252252'  ORDER BY REQUEST DESC; -- REGISTRA  LAS LINEAS POSTPAGO QUE SE REPORTAN A PREPAGO.
SELECT *          FROM SYSADM.USERS                      WHERE USERNAME = 'INH_MCB'; --- SE REGISTRAN TODOS LOS USUARIOS
SELECT *          FROM ALL_USERS                         WHERE UPPER (USERNAME) LIKE 'EYB2322B';
SELECT A.*, ROWID FROM SYSADM.INH_USUARIOS_OCC A         WHERE USERNAME = 'ICL4966A'; -- SE REGISTRAN LOS USUARIOS DE OCC.
SELECT * FROM DEALER a WHERE  a.CUSTOMER_ID= '-544';
select * from sysadm.original_dealer a where a.co_id='101664935';



--------------------------- CONSULTAS GENERALES A TABLAS -------------------------------------------------------------------------------

SELECT *FROM RTX WHERE R_P_CUSTOMER_ID = '56170693'  AND O_P_NUMBER LIKE '%019014443444%' AND SNCODE = '3013'; -- REGISTRA TODAS LAS LLAMADAS HECHAR POR UN MIN 
SELECT c.*,ROWID           FROM CONTRACT_HISTORY  c               WHERE CO_ID = '116672036'; ,'108467560'); CUSTCODE = '1.00358345'; 
SELECT A.*, ROWID  FROM DIRECTORY_NUMBER A               WHERE DN_NUM IN ('3203789999');
---se deja campo CCBILL en NULL--- 
SELECT A.*, ROWID FROM CCONTACT_ALL  a WHERE CUSTOMER_ID  IN ('237594843') and a.ccbill ='X'  ;
----solo un registro 8.21521940.00.00.100032 8.21521940.00.00.100036 8.21521940.00.00.100039
select a.customer_id,a.customer_id_high,a.custcode,a.billcycle,a.passportno from customer_all a
where custcode in('8.21521940.00.00.100039');

select c.* from ccontact_all c
where c.customer_id IN ('219416989')  and c.ccmoddate is null ;
SELECT A.CUSTOMER_ID,a.customer_id_high,a.custcode,a.paymntresp FROM customer_all  a                  WHERE CUSTOMER_ID IN ('12128429','216104095');

SELECT A.*, ROWID  FROM INH_CUENTALINEAS_MAESTRAS_PRO A  WHERE PASSPORTNO = '119864537'; --CONSULTA DE CREDITO    
SELECT A.*, ROWID  FROM TICKLER_RECORDS A                WHERE CUSTOMER_ID = '127997114' ORDER BY TICKLER_NUMBER DESC;  ---VERIFICAR LOS TICKLER, HISTORIAL DE MOVIMIENTOS DE UNA L�NEA.. 
SELECT *           FROM REASONSTATUS_ALL                 WHERE RS_ID = '248'; WHERE RS_DESC LIKE '%PORTA%';  --PERMITE CONOCER LAS CAUSALES DE LOS ESTATUS DE LA LINEA.
SELECT *           FROM BILLCYCLES A                     WHERE A.BILLCYCLE IN ('44');
SELECT *           FROM FEES                             WHERE CUSTOMER_ID = '181343577'  AND REMARK LIKE '*#3%'; -- PARA VERIFICAR LOS OCC.
SELECT /*+ FULL (I) PARALLEL (I,4) */ *          FROM INH_PURGING.FEES_ARCHIVING   I    WHERE CUSTOMER_ID = '19047494';
SELECT *           FROM CONTR_SERVICES                   WHERE CO_ID ='86955015' and DN_ID = 34374846;
SELECT *           FROM CONTRACT_ALL                     WHERE CO_ID =86955015;
SELECT *           FROM ORDERHDR_ALL                     WHERE CUSTOMER_ID = '55227184';
 
SELECT * FROM SYSADM.GLACCOUNT A WHERE A.GLACODE=4145701957; ----------------------Nombre del concepto


SELECT A.*, ROWID  FROM INH_HISTORICO_IMEI A             WHERE CUSTOMER_ID IN ('172082651'); --CONOCER EL HISTORIAL DE IMEIS QUE HA TENIDO UNA L�NEA.
SELECT *           FROM INH_IMEI                         WHERE CUSTOMER_ID IN ('172082651'); --CONOCER EL IMEI ACTUAL DE UNA LINEA
SELECT *           FROM CONTR_DEVICES                    WHERE CO_ID = 166625637;  --PERMITE VISUALIZAR EL IMSI 
SELECT *           FROM CONTR_DEVICES                    WHERE CD_SM_NUM = '732101046980089';  --PERMITE VISUALIZAR EL IMSI

SELECT A.*, ROWID  FROM INH_CONTROL_PREACTIVACION A;       ---PARA CASOS CUANDO INTENTAR REALIZAR REPOSICION, ACTIVACION WB. -- PARA CASOS ERROR -200
SELECT *           FROM INH_CONTROL_PREACTIVACION        WHERE FECHA <  TO_DATE ('12/04/2012','DD/MM/YY');
DELETE             FROM INH_CONTROL_PREACTIVACION        WHERE FECHA <  TO_DATE ('12/04/2012','DD/MM/YY');
SELECT *           FROM EX_REFERIDOS                     WHERE MIN_ORIG = 3132871517;  
SELECT *           FROM SYSADM.INH_PARAMETROS;

SELECT *           FROM MPUSNTAB                         WHERE UPPER (DES) LIKE '%GPRS%'; -- SERVICIO  DESCRIPCION DEL SERVICIO. 
SELECT *           FROM CAP_NCC                          WHERE TELEFONO  IN ('3204154324') ORDER BY 1 DESC;    -- PERMITE SABER QUE SERVICIO ESTAN EN LA PLATAFORMA MAGUARE
SELECT A.*, ROWID  FROM CONTR_SERVICES A                 WHERE CO_ID IN (77190135); -- PERMITE CONOCER LOS SERVICIOS ASOCIADOS A UN PAQUETE Y UN PAQUETE AUN PLAN.
SELECT *           FROM MDSRRTAB                         WHERE REQUEST = (91723930); 
SELECT *           FROM CAP_STP_PN                       WHERE CO_ID = 87020181;
SELECT *           FROM MPUSNTAB                         WHERE SNCODE = 3105; --  SI APROVISIONA EL SERVICIO EN EL HLR , Y = SI SE APROVISIONA EN HLR
SELECT *           FROM INH_SYSGPRS;  
SELECT *           FROM CAP_COMAN_SERV                   WHERE SERVICIO LIKE '%8017%' AND PLATAFORMA = 'HLRGSM'; --PERMITE CONOCER COMANDO QUE SE ENVIA PARA LA PLATAFORMA HLR --B ES DESACTIVADO
SELECT A.*, ROWID  FROM CAP_CONCI_APNS A                 WHERE MSISDN= '3125740462'  ORDER BY FECHA; -- LA CONCILIACION PASA A ESTA TABLA PRIMERO, CUANDO PASA A ESTADO 2 SE PASA A LA TABLA CAP_MASIVOS
SELECT A.*, ROWID  FROM CAP_MASIVOS           A          WHERE MSISDN= '3115460548' ORDER BY FECHA DESC; -- SEGUNDA TABLA DONDE PASAN LAS CONCILIACIONES. 
SELECT * FROM CAP_MASIVOS_HISTORICO WHERE  MSISDN= '3115460548' ORDER BY  1 DESC;
SELECT COUNT(*)    FROM CAP_CONCI_APNS                   WHERE ESTADO = '1';
SELECT *           FROM MDSRRTAB_ALL                     WHERE CO_ID ='82223978';
SELECT A.*, ROWID  FROM MDSRRTAB A                       WHERE CO_ID  =  97399017 ORDER BY REQUEST DESC;      
SELECT *           FROM MDSRRTAB                         WHERE REQUEST= 1056746419  ORDER BY REQUEST DESC;      

SELECT *           FROM MDSRRTAB                         WHERE HLCODE IS NULL  ORDER BY REQUEST DESC;      
SELECT *           FROM INH_INTERMINCONTROLTB            WHERE CODMIN1 = '3124522748';
SELECT *           FROM GLACCOUNT_ALL                    WHERE GLACODE IN ('4345609113','2815112496');
SELECT *           FROM SYSADM.INH_PROMOCION_CFM_POL     WHERE CO_ID = '35404604';   
select *           FROM CAP_BUZON                        WHERE TELEFONO = '3116473282';


-------------------------------------CONOCER LOS RC QUE HA TENIDO LA LINEA------------------------------------

SELECT CO_ID, HLR,MSISDN,RCAT,ACCION_TRAN,SERVICIOS,USUARIO,FECHA,FECHA_FINAL, RES 
FROM CAP_MASIVOS WHERE CO_ID IN (&COID) UNION 
SELECT CO_ID, HLR,MSISDN,RCAT,ACCION_TRAN,SERVICIOS,USUARIO,FECHA,FECHA_FINAL, RES 
FROM CAP_MASIVOS_HISTORICO WHERE CO_ID IN (&COID) AND ACCION_TRAN = 'CCG' ORDER BY FECHA DESC;
-----------------------------------------------------------------------------------------------------------------------

SELECT A.*, ROWID  FROM CAP_MASIVOS           A          WHERE CO_ID = 114746286 ORDER BY FECHA DESC;
SELECT A.*, ROWID  FROM CAP_MASIVOS_HISTORICO A          WHERE CO_ID = 114746286 ORDER BY 1 DESC;    
SELECT A.*, ROWID  FROM CAP_MASIVOS  A                   WHERE REQUEST=964941431;
SELECT *           FROM MPULKTMB                         WHERE SPCODE = 4160 AND TMCODE = 4933;
-----------------------------------------------------------------------------------------------------------------------
SELECT *           FROM CAP_SUSCRIBE_MANAGER             WHERE CO_ID = 117050662  ORDER BY REQUEST DESC; 
SELECT *           FROM CAP_CONF_DATOS                   WHERE TMCODE = 8982;
SELECT *           FROM CAP_CONF_DATOS                   WHERE SPCODE = 5016;
SELECT *           FROM SYSADM.INH_DATOS_APN_CONTRATO    WHERE CO_ID=100301233;
-----------------------------------------------------------------------------------------------------------------------
SELECT *           FROM CAP_CONTROL_GPRS	               WHERE MSISDN= '3206749669'; --SI LA LINEA EST� CONTROLADA. 
SELECT *           FROM CAP_GPRS_BMH                     WHERE MSISDN= '3205031184';   --PANAMA
SELECT *           FROM BMH_REQUEST                      WHERE CO_ID = 38193946;  
SELECT *           FROM CAP_SUSCRIBE_MANAGER             WHERE CO_ID = 90103309      ORDER BY 1 DESC;     
SELECT *           FROM USERS                            WHERE USERNAME='G9276052';
-----------------------------------------------------------------------------------------------------------------------
SELECT *           FROM CAP_QUEUE                        WHERE CO_ID = 15043742;
SELECT *           FROM CAP_QUEUE                        WHERE SERVICIOS LIKE '%BBPRE%' AND ROWNUM <=10;
SELECT *           FROM TMP_CAMBIO_MINUTOS               WHERE ESTADO='0';
SELECT *           FROM MPDHMTAB
SELECT *           FROM CAP_GSMPURO;

-------------------------------RANGOS -------------------------------------------------------------------------------------

SELECT *           FROM CAP_RANGOSHLR                    WHERE 3123558744             BETWEEN INICIO AND FINAL;
SELECT *           FROM CAP_RANGOSIN                     WHERE 3116242222             BETWEEN INICIO AND FINAL;
SELECT *           FROM CAP_RANGOSNAP                    WHERE 3133335069             BETWEEN INICIO AND FINAL;
SELECT *           FROM CAP_NUM_STP                      WHERE 3202337660             BETWEEN INICIO AND FINAL;
SELECT *           FROM CAP_RANGOSSRRI                   WHERE 3207276661             BETWEEN INICIO AND FINAL;

SELECT *           FROM INH_PLANESBB                     WHERE SNCODE = 6605;         
SELECT *           FROM INH_PLANESBB                     WHERE SNCODE = 8048   AND  SPCODE=   4615 AND TIPO= 'PKVL';   --PRIMERA COMBINACION JAVA
SELECT *           FROM INH_PLANESBB                     WHERE SNCODE = 6020   AND  TMCODE=   7398 AND TIPO= 'PKVL';   --SEGUNDA COMBINACION JAVA
                               
SELECT *           FROM CAP_BB                           WHERE CO_ID =   89186875      ORDER BY FECHA DESC;
SELECT *           FROM CAP_BB                           ORDER BY REQUEST DESC;
SELECT *           FROM CAP_BB_HIST                      WHERE MSISDN = '3132138418';
SELECT *           FROM CAP_MO                           WHERE TELEFONO ='3105868059'  ORDER BY FECHA DESC;
SELECT *           FROM CAP_OTA                          WHERE TELEFONO ='3106571872'  ORDER BY REQUEST DESC;
SELECT *           FROM CAP_POC                          WHERE TELEFONO ='3145961008'  ORDER BY REQUEST DESC;       
SELECT *           FROM CAP_NCC                          WHERE TELEFONO ='3124494397'  ORDER BY REQUEST DESC;       --MAGUARE--DOS MESES ANTES VOL
SELECT *           FROM CAP_NCC                          WHERE FECHA_FTP = TO_DATE ('24/12/2010 16:42:09','DD/MM/YYYY HH24:MI:SS')  ; 
SELECT *           FROM CAP_DPI                          WHERE TELEFONO ='3142391383'  ORDER BY REQUEST DESC;       

SELECT *           FROM CAP_RAC                          WHERE CO_ID = 17177998        ORDER BY REQUEST DESC;        
SELECT *           FROM CAP_RBT                          WHERE CO_ID = 89186875;         -- SYSADM.PROC_VENTAS 
SELECT *           FROM CAP_RIP                          WHERE CO_ID = 70467666;
SELECT *           FROM CAP_STP                          WHERE REQUEST =1013864283;
SELECT *           FROM CAP_STP                          WHERE ESTADO IN('E1');
SELECT *           FROM CAP_VPN                          ORDER BY REQUEST DESC;    --PANAMA
SELECT *           FROM CAP_SRRI                         WHERE CO_ID = 17177998;
SELECT *           FROM SYSADM.CAP_BUZON                 WHERE TELEFONO = '3107536745' ORDER BY REQUEST; -- PARA VALIDAR EL SERVICIO BUZON DE MENSAJES.
SELECT *           FROM CAP_SMSMMS                       WHERE CO_ID = 29022370        ORDER BY REQUEST DESC;
SELECT *           FROM CAP_SMSMMS                       WHERE TELEFONO = '3153291355' ORDER BY REQUEST DESC;
SELECT *           FROM CAP_HOTRATING                    WHERE TELEFONO = '3177252811' ORDER BY REQUEST DESC;         --HOTRATING
SELECT *           FROM CAP_MESSAGING                    WHERE ESTADO='E'              ORDER BY REQUEST DESC;
SELECT *           FROM CAP_MESSAGING                    ORDER BY REQUEST DESC;
SELECT *           FROM CAP_SYNCHRONICA                  ORDER BY REQUEST DESC;
SELECT *           FROM CAP_SUSCRIBE_MANAGER             ORDER BY REQUEST DESC;
SELECT *           FROM CAP_SUSCRIBE_MANAGER             WHERE ORDER BY REQUEST DESC;

SELECT *           FROM CAP_PREPAGO                      WHERE MSISDN ='3177252811' ;
SELECT *           FROM CAP_APROPREPAGO                  WHERE MSISDN ='3177252811' ;
SELECT *           FROM CAP_APROPREPAGO                  ORDER BY 1 DESC;
SELECT *           FROM CAP_PREPAGO                      WHERE ESTADO IN('1') ORDER BY 1;
SELECT COUNT(*)    FROM CAP_PREPAGO                      WHERE ESTADO IN('1') ORDER BY 1;

------------------------------- HALLAMOS LA CIUDAD Y DEPARTAMENTO DE ACTIVACION DE LA LINEA.
SELECT B.CCCITY
INTO VCIUDAD_DEPARTAMENTO
FROM CONTRACT_ALL A, CCONTACT_ALL B
WHERE A.CO_ID = 'VCO_ID'
AND A.CUSTOMER_ID = B.CUSTOMER_ID
AND B.CCBILL = 'X';

SELECT * FROM  MPUTMTAB M       WHERE  TMCODE       LIKE '%12694%';              --PLANES
SELECT * FROM  MPUTMTAB M       WHERE  UPPER(DES)       LIKE '%LARGA%';      --PLANES
SELECT * FROM  MPUSPTAB M       WHERE  SPCODE       LIKE '%5747%';              --PAQUETES
SELECT DISTINCT SNCODE  FROM  MPULKTMB M  WHERE  SPCODE   = 4001;               --SERVICIOS ASOCIADOS AL PAQUETE
SELECT DISTINCT SPCODE  FROM  MPULKTMB M  WHERE  TMCODE   =9652 AND SPCODE = 4001; --SERVICIOS QUE SOPORTA LOS PLANES

SELECT * FROM  SERVICES_PARAMS  WHERE  TMCODE       LIKE '%7476%';              --PLANES CON RC INICIAL
SELECT * FROM  MPULKTMB M       WHERE  TMCODE ='9738' AND SNCODE='7608';        --PRECIO PLANES
SELECT * FROM  MPULKTMB M       WHERE  TMCODE ='9738' AND SPCODE ='4103' AND SNCODE='3013';       --PRECIO PAQUETES


SELECT * FROM MPULKTMB WHERE TMCODE = 9821;


SELECT * FROM MPULKTMB WHERE TMCODE = '9821' AND SPCODE = '4101';

select * from  MPUSNTAB M       WHERE  UPPER(SNCODE) LIKE '%7256%';              --Servicios 
select * from  MPUSNTAB M       WHERE  UPPER(des)    LIKE '%AULGE%';             --Servicios
select * from  MPUSNTAB M       WHERE  UPPER(SHDES)  LIKE '%AULGE%';               --Servicios

-----------------------------------------------CONSULTA DE YADER----------------------------------------------
---------------------VALIDA LOS PAQUETES ASOCIADOS A UN PLAN Y A SU VEZ LOS SERVICIO BASICOS QUE SOPORTA EL PAQUETE. 

select lk.tmcode, 
(select des from mputmtab tm where tm.tmcode = lk.tmcode and tm.status = 'W') PLAN,lk.vscode, lk.vsdate, lk.status, lk.spcode, 
(select des from mpusptab sp where sp.spcode = lk.spcode) Paquete ,lk.sncode, 
(select des from mpusntab sn where sn.sncode = lk.sncode) Servicio,lk.accessfee
from mpulktmb lk
where lk.tmcode = 9652
  --and sncode = 3013
  and spcode = 4001
  and lk.vscode = (select max(lk1.vscode) from mpulktmb lk1 where lk1.tmcode = lk.tmcode and lk1.vsdate < sysdate)
order by lk.tmcode, lk.spcode, lk.sncode, lk.accessfee;


------------------------------- MUESTRA SERVICIOS ASOCIADOS A UN TMCODE, SPCODE, PRGCODE----------------

SELECT M.TMCODE,M.VSCODE, M.SPCODE, S.SNCODE, S.DES, MM.SCCODE, N.PRGCODE
FROM   MPUSNTAB  S, MPULKTMB M, MPULKNXC MM, MPULKNXG N
WHERE  M.TMCODE = 8614
AND    M.VSCODE = (SELECT MAX(B.VSCODE) FROM MPUTMTAB B WHERE B.TMCODE = M.TMCODE AND B.VSDATE <= SYSDATE )
AND    M.SPCODE IN (5747) 
AND    M.SNCODE = S.SNCODE 
AND    MM.SNCODE = M.SNCODE    
AND    N.SNCODE = M.SNCODE    
AND    NVL(M.CSIND, 'Y')!= 'X' 
AND    M.STATUS  = 'P' 
AND    MM.SCCODE IN (1, 2, 3) 
AND    N.PRGCODE = 12;   --12:DATOS   ;3:PERSONAL.


------------------------------- COMANDOS --------------------------------------------------------------------

SELECT * FROM CAP_COMAN_SERV
    WHERE SERVICIO LIKE '%00R96%'  --00ENR;0ENR2;00R93;SRRI;BBPRE;INPRE;0TRIG   O SNCODE=3109
    AND PLATAFORMA ='HLRCAL'
    AND ACCION_SERV ='A'
    AND ESTADO ='A'
    ORDER BY 1,2,3,5;

SELECT * FROM CAP_COMAN_SERV
    WHERE COMANDO LIKE '%FP%'
    AND PLATAFORMA ='HLRCAL' 
    AND ACCION_SERV ='B'
    AND ESTADO='A'
    ORDER BY SECUENCIA;
    
SELECT * FROM CAP_COMAN_TRAN
    WHERE ACCION_TRAN LIKE '%REC%'  --ACT;SUS;REC;DES;CIMSI
    AND ESTADO ='A'
    AND PLATAFORMA = 'HLRGSM'
    ORDER BY SECUENCIA; 

SELECT * FROM CAP_COMAN_TRAN
    WHERE PLATAFORMA = 'ACT';       --STP;

SELECT * FROM CAP_COMAN_APNS
    WHERE PLATAFORMA = 'HLRPTE';    --STP;

------------------------------- DATOS LINEA ---------------------------------------------------------------------------------------------

select * from INH_IMEI                  WHERE CUSTOMER_ID = 42448594; 
select * from CAP_RANGOSIN              where INICIO like  '312277%';   
select * from DIRECTORY_NUMBER          where dn_num like  '3177252811';   
select * from CONTRACT_HISTORY          where CO_ID    =107861152 order by 2  ;  --ACTIVA EN LA SECUENCIA 2 --Permite saber en  que estado se encuentra la linea.
select * from CONTRACT_ALL              where CO_ID    =40094598    ;  
select * from CONTRACT_ALL              where customer_id= 110532875;
SELECT * FROM CUSTOMER_aLL              WHERE CUSTOMER_ID = 45009805;
select * from CUSTOMER_ALL              where passportno= '900323191';
select * from CUSTOMER_ALL              where custcode='8.21821454';
select * from CUSTOMER_ALL              where customer_id_high='46291198';
select * from BC_SHIFT                  where customer_id='241991990';               --cambios de ciclo
select * from TMP_CAMBIO_CICLOS         where customer_id='241991990';               --cambios de ciclo

SELECT * FROM REASONSTATUS_ALL          WHERE RS_ID=2;

select * from DIRECTORY_NUMBER          where dn_num   ='3128666267';   --a,r,d,f,b
select * from CONTR_SERVICES            where dn_id    = 36150777    and cs_deactiv_date IS NULL;  --a,s,d
select * from CONTR_DEVICES             where co_id    = 98581229     and cd_deactiv_date is null;
select * from CONTR_DEVICES             where cd_sm_num LIKE '8957101000905575375%';
select * from CONTR_DEVICES             where port_id  = 95823165      and cd_deactiv_date is null;
select * from PORT                      where port_id  = 75206172;               
select * from PORT                      where SM_id    = 10430368;               
select * from PORT                      where port_num ='732101116586334';
select * from STORAGE_MEDIUM            where co_id    =54819490;
select * from STORAGE_MEDIUM            where sm_serialnum LIKE '%358642024574201%';  --# en la SIMCARD
select * from sysadm.INH_INFO_CAMBIOMIN where minanterior='3212259011';

select * from STORAGE_MEDIUM            where sm_serialnum LIKE '89571011008076897234%';
select * from PORT                      where port_num ='732101017242088';
select * from CONTR_DEVICES             where port_id  = 111476909      and cd_deactiv_date is null;
select * from CONTR_DEVICES             where co_id = 25690649      and cd_deactiv_date is null;
select * from CONTR_SERVICES            where co_id    = 17177998       and cs_deactiv_date IS NULL;
select * from DIRECTORY_NUMBER          where dn_id    = 61708244;

-- LINEAS SIN DESACTIVACION SERVICIO CAMBIO DE MINs -----------------------------

SELECT *        FROM CAP_MINANTCRT      WHERE msisdn_anterior = 3212259011

SELECT *        FROM CAP_RANGOSHLR      WHERE 3124519694 between inicio and final 732101044738356
SELECT *        FROM CAP_RANGOSHLR      WHERE 3112990000  between inicio and final
SELECT *        FROM CAP_MINANTCRT      WHERE msisdn_anterior in ('3103706237');



--------------------------------------------
-- servicios por min

SELECT a.dn_num,
       cs.dn_id,
       ca.customer_id,
       (SELECT x.id_telmex FROM sysadm.inh_activpos_tipocli x WHERE x.customer_id = ca.customer_id) id_telmex,
       cu.passportno,
       cu.custcode,
       cs.co_id,
       cs.cs_seqno,
       cs.tmcode,
       (SELECT tm.des
          FROM mputmtab tm
         WHERE tm.tmcode = cs.tmcode
           AND tm.vscode = (SELECT MAX(x.vscode)
                              FROM mputmtab x
                             WHERE x.tmcode = tm.tmcode)) tmdes,
       sysadm.func_cap_co_id(cs.co_id, 'PLPR', NULL) TipoPlan,
       cs.spcode,
       (SELECT sp.des FROM mpusptab sp WHERE sp.spcode = cs.spcode) spdes,
       cs.sncode,
       (SELECT sn.des FROM mpusntab sn WHERE sn.sncode = cs.sncode) sndes,
       cs.cs_stat_chng,
       cs.cs_activ_date,
       cs.cs_deactiv_date,      
       cs.cs_sparam1,
       (SELECT params FROM services_params x WHERE x.tmcode = cs.tmcode AND x.spcode = cs.Spcode
         AND x.sncode = cs.sncode) rc_default,
       cs.cs_pending_state,
       cs.Cs_Pending_Param,
       cs.cs_request,
       sysadm.func_cap_co_id(cs.co_id, 'IMSI', NULL) imsi,
       cs.rowid
  FROM sysadm.contr_services cs,
       (SELECT dn.dn_num, cs.co_id, MAX(cs.cs_seqno) cs_seqno
          FROM sysadm.contr_services cs, sysadm.directory_number dn
         WHERE dn.dn_num = '&MIN'
           AND cs.dn_id = dn.dn_id
           AND (substr(cs.cs_stat_chng, -1) <> 'd' OR
                substr(cs.Cs_Pending_State, -1) <> 'd')
         GROUP BY dn.dn_num, cs.co_id) a,
       sysadm.contract_all ca, sysadm.customer_all cu
WHERE cs.co_id    = a.co_id
   AND cs.cs_seqno = a.cs_seqno
   AND ca.co_id    = a.co_id
   AND cu.customer_id  = ca.customer_id
ORDER BY cs.co_id DESC, cs.cs_seqno DESC, cs.tmcode, cs.spcode, cs.sncode;

 

------------------------------------------------------------------------------

-- servicios por coid

SELECT a.dn_num,
       cu.custcode,
       cs.Dn_Id,
       ca.customer_id,
       cs.co_id,
       cs.cs_seqno,
       cs.tmcode,
       (SELECT tm.des
          FROM mputmtab tm
         WHERE tm.tmcode = cs.tmcode
           AND tm.vscode = (SELECT MAX(x.vscode)
                              FROM mputmtab x
                             WHERE x.tmcode = tm.tmcode)) tmdes,
       sysadm.func_cap_co_id(cs.co_id, 'PLPR', NULL) TipoPlan,
       cs.spcode,
       (SELECT sp.des FROM mpusptab sp WHERE sp.spcode = cs.spcode) spdes,
       cs.sncode,
       (SELECT sn.des FROM mpusntab sn WHERE sn.sncode = cs.sncode) sndes,
       --cs.cs_status,
       cs.cs_stat_chng,
       cs.cs_activ_date,
       cs.cs_deactiv_date,   
       cs.Cs_Date_Billed,  
       cs.cs_sparam1,
       cs.cs_pending_state,
       cs.Cs_Pending_Param,
       cs.cs_request,
       sysadm.func_cap_co_id(cs.co_id, 'IMSI', NULL) imsi,
       cs.rowid,
       sysadm.FUNC_CAP_CO_ID(  CS.CO_ID , 'HLR', NULL ) HLR
  FROM sysadm.contr_services cs,
       (SELECT dn.dn_num, cs.co_id, MAX(cs.cs_seqno) cs_seqno
          FROM sysadm.contr_services cs, sysadm.directory_number dn
         WHERE cs.co_id = &nmCoId
           AND cs.dn_id = dn.dn_id
           /*AND (substr(cs.cs_stat_chng, -1) <> 'd' OR
                substr(cs.Cs_Pending_State, -1) <> 'd')*/
         GROUP BY dn.dn_num, cs.co_id) a,
       sysadm.contract_all ca,
       sysadm.customer_all cu
WHERE cs.co_id    = a.co_id
  -- AND cs.cs_seqno = a.cs_seqno
   AND ca.co_id    = a.co_id
   AND cu.customer_id = ca.customer_id
ORDER BY cs.co_id DESC, cs.cs_seqno DESC, cs.tmcode, cs.spcode, cs.sncode;


-----------------------------------------------------------------------------------------------------

select * from directory_number a where a.dn_num='3214195759';
select * from contr_services a where a.dn_id='64952979';
select * from cashreceipts_all where customer_id='162197763';

----------------------------------------------consulta para buscar CUSCODE---------------------------

SELECT a.dn_num, b.co_id, b.cs_seqno, b.tmcode, b.cs_stat_chng, b.cs_deactiv_date, d.customer_id, d.custcode
  FROM directory_number a, contr_services b, contract_all c, customer_all d
WHERE a.dn_num = '3132970310'
   AND b.dn_id = a.dn_id
   AND c.co_id = b.co_id
   AND d.customer_id = c.customer_id
  ORDER BY nvl(b.cs_deactiv_date,SYSDATE) DESC ;


-----------------------consultar todas las l�neas que est�n inscritas en una maestra.---------------

SELECT *  FROM CUSTOMER_ALL a WHERE a.custcode in ('8.21456217');

select * from sysadm.customer_all a where a.customer_id_high='44328271' and a.cstype='a';

select dn.*
from customer_all ca, contract_all co, contr_services cs, directory_number dn
where ca.customer_id in ('189490803')--= &customer_id
and co.customer_id = ca.customer_id
and cs.co_id = co.co_id
and dn.dn_id = cs.dn_id;

-------------- consulta cuscode por nit-----------------------------

SELECT '900602521', A.CO_ID, C.DN_NUM, A.CUSTOMER_ID--,a.*, c.*
  FROM SYSADM.CONTRACT_ALL     A,
       SYSADM.CONTR_SERVICES   B,
       SYSADM.DIRECTORY_NUMBER C,
       INH_TMSP_PREP           D
WHERE B.DN_ID = C.DN_ID
   AND B.CO_ID = A.CO_ID
   AND A.TMCODE = D.TMCODE
   AND PREPAGO NOT IN (0, 3)
   AND SUBSTR(B.CS_STAT_CHNG, -1) <> 'd'
   AND CUSTOMER_ID IN
       (SELECT CUSTOMER_ID
          FROM SYSADM.CUSTOMER_ALL
         WHERE CUSTOMER_ID_HIGH IN (SELECT CUSTOMER_ID
                                      FROM SYSADM.CUSTOMER_ALL
                                     WHERE PASSPORTNO = '900602521'
                                       AND CSLEVEL = 10)
        UNION ALL
        SELECT CUSTOMER_ID
          FROM SYSADM.CUSTOMER_ALL
         WHERE CUSTOMER_ID_HIGH IS NULL
           AND PASSPORTNO = '900602521'
           AND CSLEVEL = 40);

------------------------ELEGIDOS FAMILIARES ---------------------------
select * from sysadm.inh_eleg_familia WHERE NUM_DOCUMENTO = ('19109633');
SELECT * from sysadm.INH_ELEG_FAMILIA_HIST  WHERE NUM_DOCUMENTO = ('19109633');

-----------------------Contrase�as-----------------------------------

SELECT CSPASSWORD 
FROM customer_all 
WHERE customer_id = (select customer_id 
                    from contract_all
                     where co_id = (select co_id 
                                    from contr_services 
                                    where cs_deactiv_date is null
                                    and   dn_id = (select dn_id
                                                   FROM directory_number 
                                                   WHERE dn_num = '3209466563')));

-------------Consulta elegidos Poliedro-----------------------
select a.fecregis, a.estado, a.producto, a.codmin, a.nombres, a.apellido, a.planilla, a.trajo_equipo, a.*
from activacion@activa a
where codmin  = '3206749669';

--------------------------------------------------------------
select * from ex_paquetes_planes p
where p.tmcode = 12747;

-------------CONSULTA PDF CONTRA TXT--------------------------------

select * from customer_all a where a.custcode = '8.21509873';

select customer_id,remark,substr(TRIM(remark),-10),amount,entdate,valid_from , username,period,length(remark)
FROM sysadm.FEES 
where customer_id in (12679082)
AND entdate>= to_date ('23042017 00:00:00','ddmmyyyy hh24:mi:ss') 
AND entdate<= to_date ('22052017 23:59:59','ddmmyyyy hh24:mi:ss')
--AND substr(TRIM(remark),-10)= '3102643221'
---AND length(remark)>69  --3146451332 
AND remark like '%Promoc%';



select * from inh_purging.fees_archiving a 
where a.customer_id in (18552627)
AND entdate>= to_date ('28012013 00:00:00','ddmmyyyy hh24:mi:ss') 
AND entdate<= to_date ('18092013 23:59:59','ddmmyyyy hh24:mi:ss');

--------------5 sept------------------------------------------
select * from inh_mindescuento
where co_id
in
       (select co_id
          from contr_services aselect * from SYSADM.CAP_PCRF_EVENTO e where e.msisdn in ('&min') order by e.fecha_registro desc;
         where dn_id in
               (select dn_id from directory_number where dn_num in ('3206780402'))
               and substr (a.cs_stat_chng, -1)<> 'd');

---VALIDACI�N DE ERROR EN REPORTE DE CICLO A PCRF

select * from SYSADM.CAP_PCRF_EVENTO e where e.msisdn in ('&min') order by e.fecha_registro desc;



Select * from mpusntab n 
where des like '%Roa%';

Select * from mpulktmb 
Where tmcode in ('11968') and spcode in ('4101') 
and sncode in (6506) 
order by 1 desc;

Select * from mpusntab n 
where sncode in (5747) ;

select * from CAP_CONTROL_GPRS where msisdn= '3123777548';

select * from inh_cambiofavorito_actualiza@plataforma_prepago where msisdn = (&min);

--------------------Servicio que soporta un plan---------------------------------------

Select * from mpusntab n 
where des like '%Ya%';

Select * from mpulktmb 
Where tmcode in ('7486')and spcode in ('4134') 
and sncode in (7847) 
order by 1 desc

Select * from mpusntab n 
where sncode in (8569) 

---Poliedro---

select estado, codmin min, a.id_activacion, fecregis fecha
from actinclusion@activa a
where codmin  = '3132392580';

--Elegidos de migraci�n reportados a pospago en Poliedro

select * from elegidos_plan@activa where id_activacion in (select a.id_activacion
from activacion@activa a
where a.codmin  in ('&min'));

select * from tabcomapdistribuidores@activa where iddistribuidor = '-17438';


---consulta consecutivo de factura

SELECT o.ohxact consecutivo, customer_id, o.ohentdate fecha,o.ohinvamt vlr_pagar, o.ohstatus estado 
FROM sysadm.orderhdr_all o WHERE customer_id = '110600099'ORDER BY o.ohentdate DESC;



--consulta detalle de factura
select a.otxact cnsc_detalle, a.otglsale cuenta,g.gladesc descripcion, a.otmerch valor 
from ordertrailer a, glaccount_all g where a.otglsale = g.glacode and otxact = 868202634;


