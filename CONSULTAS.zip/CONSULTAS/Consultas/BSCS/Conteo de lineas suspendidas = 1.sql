begin
  -- Call the procedure
  sysadm.PROCUENTALINEASNEW(vcDocumento => :vcDocumento,
                            nmInd => :nmInd,
                            nmIndTipoLinea => :nmIndTipoLinea,
                            nmTiempoDias => :nmTiempoDias,
                            vcSalida => :vcSalida,
                            vcDescSalida => :vcDescSalida,
                            rcSalida => :rcSalida);
end;
