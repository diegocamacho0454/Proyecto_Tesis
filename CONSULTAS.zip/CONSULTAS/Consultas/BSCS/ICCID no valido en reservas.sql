SELECT ca.customer_id, cs.co_id, dn.dn_num
FROM CONTRACT_ALL ca, contr_services cs, directory_number dn
WHERE ca.co_id = cs.co_id
AND cs.dn_id = dn.dn_id
AND substr(cs.cs_stat_chng, -1) <> 'd'
AND dn.dn_num IN(
'3135822391'

);

SELECT I.*, ROWID FROM INH_IMEI I WHERE I.CUSTOMER_ID in ( 
'311056645'

) ;
