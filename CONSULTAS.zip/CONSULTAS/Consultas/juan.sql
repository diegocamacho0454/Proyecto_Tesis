------ consulta en poliexp06 campa�as disponibles acorde a la activaci�n fecha/tmcode/dealer

select *     from CPNG_CAMPANIA       a
where a.nombre like '%navi%';
    where a.idcampania IN ('1151');
--- EJEMPO DE COMO VALIDAR POR TMCODE
SELECT DISTINCT C.TMCODE,
               --CF.IDCONFIG,
               B.DATOSADD,
               --B.PERIODOS,
               --Z.IDZONA,
               --CP.IDPROCESOV,
               CA.*,
               --DECODE(NVL(Z.IDZONA, 99), 99, 'TODAS', Z.IDZONA) ZONAS,
               DECODE(NVL(D.CODDISTRI, '99'), '99', 'TODAS', D.CODDISTRI) CODDISTRI
FROM CPNG_CONFIGXPLAN   C,
      CPNG_CONFIGURACION CF,
      CPNG_CAMPANIA      CA,
      CPNG_CONFIGXDEALER D,
      CPNG_CONFIGXZONA   Z,
      CPNG_BENEFICIO     B,
      CPNG_CONFIGXPROCESOVENTA CP
WHERE 1 = 1
  AND C.TMCODE IN (&TMCODE)
  AND C.IDCONFIG = CF.IDCONFIG
  AND CF.IDCAMPANIA = CA.IDCAMPANIA
  AND D.IDCONFIG(+) = CF.IDCONFIG
  AND Z.IDCONFIG(+) = CF.IDCONFIG
  AND CF.IDCONFIG = B.IDCONFIG
  AND CF.IDCONFIG = CP.IDCONFIG
  AND DECODE(NVL(D.CODDISTRI, '99'), '99', 'TODAS', D.CODDISTRI) IN ('&DEALER','TODAS')
--AND Z.IDZONA IN (2)
--AND CA.FECHAINICIAL <= TO_DATE('/04/2017', 'DD/MM/YYYY')
AND to_date('&FECHA_ACTIVACION','DD/MM/YYYY') BETWEEN  CA.FECHAINICIAL AND CA.FECHAFINAL
--AND Z.IDZONA IN ('TODAS');
--AND B.DATOSADD = (1252)
--AND B.DATOSADD IN (&ID_CAMPANA)
--AND Z.IDZONA IN (0, 1, 2, 3);
--AND D.CODDISTRI IN ('&DEALER');

---------------------------- segunda

--------------- BSCS consulta de aprovisionamiento de campa�a
select DISTINCT p.co_id,
                p.customer_id,
                c.fecha_registro_prom,
                c.fecha_inicio_prom,
                TO_CHAR(ADD_MONTHS(c.fecha_inicio_prom,(a.duracion)- 2), 'dd/mm/yyyy hh24:mi:ss') as vencimiento,
                p.ciclo,
                c.id_usuario,
                c.estado,
                c.id_campana,
                c.usuario_bd,
                dnu.dn_num,
                a.descripcion,
                a.duracion
                
  from sysadm.perm_usuarios      p,
       sysadm.perm_camp_usuarios c,
       sysadm.perm_campana       a,
       Sysadm.Directory_Number   dnu,
       sysadm.contr_services     se,
       sysadm.customer_all cu
where dnu.dn_num in ('3208567482')
and p.customer_id = cu.customer_id
   and p.id = c.id_usuario
   and c.id_campana = a.id
   and p.co_id = se.co_id
   and se.dn_id = dnu.dn_id;
---------- tercera 

select a.RTAR,a.tmcode,a.codigo_distribuidor,a.fecbscs,a.CODMIN, a.trajo_equipo, a.tipo_contrato, a.FECREGIS, a.ESTADO, a.id_activacion, a.imei, a.*
from ACTIVACION a
where codmin in ('&codmin');

---- Validar campa�a activa --- campo aplica en 9 validar con el grupo prom el aprovisionamiento de la campa�a----- de no salir nada validar en poliexp con la primera consulta 
select c.*, c.rowid
from extranet.cpng_campanaxactivacion c
where c.idactivacion in (select a.id_activacion from ACTIVACION a where a.codmin in ('&codmin'));

-------------------------------- base de datos activa validaci�n de activaci�n y registro de campa�a
