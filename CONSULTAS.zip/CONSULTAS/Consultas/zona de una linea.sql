---Validar hlcode en portabilidad en SIMCard con error de regi�n.
SELECT a.dn_num, a.dn_status, a.dn_status_requ,a.hlcode
FROM directory_number a
WHERE a.dn_num in('3227339987');

------ VALIDAR ZONA -----
select n.dn_num,n.hlcode zona_min, p.hlcode zona_iccid,s.sm_serialnum sm_iccid,c.port_id puerto,c.cd_port_num imsi,
     sysadm.fnc_buscar_dnhlcode(c.co_id) Zona_IMSI, c.rowid
from contr_devices     c
   ,port             p
   ,storage_medium   s
   ,contr_services   se
   ,directory_number n  
where n.dn_num =any('3227339987') 
--c.co_id = 178084075
and c.cd_deactiv_date is null
and  p.port_id = c.port_id
and  s.sm_id = p.sm_id
and  se.co_id = c.co_id
and  se.dn_id = n.dn_id
and  se.cs_deactiv_date is null;

------ VALIDAR ZONA V2-----

SELECT * FROM DIRECTORY_NUMBER
WHERE DN_NUM IN ( '&min')
