---------- CRUCE DE MINES ----------
    SELECT TAREA_ID, PROCESO_STATUS, FECHA_INICIO, PROCESO_ERRORES, USUARIORED, DESC_CORTA, DESC_USUARIO
    FROM sysadm.ex_batch_Tareas WHERE DESC_CORTA = 'Cruce Mines' 
    and PARAMETROS_STRING1 like '%3004717583%' ORDER BY TAREA_ID desc; 

---------- CAMBIO DE MIN ----------
select * from INH_INFO_CAMBIOMIN where customer_id=139083313; 


---------- VALIDAR ZONA ----------

SELECT a.dn_num, a.plcode ,a.dn_status, a.dn_status_requ, a.hlcode, a.dn_status_mod_date 
FROM directory_number a 
WHERE a.dn_num IN ('3102103593','3212333080'); 

SELECT a.dn_num, a.plcode ,a.dn_status, a.dn_status_requ, a.hlcode, a.dn_status_mod_date 
FROM directory_number a 
WHERE a.dn_num IN ('3153926711'); 

SELECT *
FROM directory_number a 
WHERE a.dn_num IN ('3144712223','3108127595'); 


SELECT * FROM
sysadm.cap_conf_datos
WHERE desarrollo ='PCRF'
AND TMCODE =8548 --Plan de servicio 3288 en contr_services en estado 'a' o 's'
AND sncode =3288
AND estado ='A';

SELECT * FROM
sysadm.cap_conf_datos
WHERE desarrollo ='PCRF'
AND SPCODE =4712--Paquete de servicio 3288 en contr_services en estado 'a' o 's'
AND sncode =3288
AND estado ='A';



select * from inh_mindescuento
where co_id
in 
    (select co_id
      from  contr_services a
     where dn_id in
            (select dn_id from directory_number where dn_num in ('3133628167'))
            and substr (a.cs_stat_chng, -1) <> 'd');





























