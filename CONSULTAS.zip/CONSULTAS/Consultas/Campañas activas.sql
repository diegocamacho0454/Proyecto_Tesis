-- Se verifica en la tabla INH_REL_EQU_SER, si la l�nea ya cuenta con informaci�n para facturaci�n del equipo:

select * 
from sysadm.inh_rel_equ_ser s 
where '106750305' in (s.customer_id_equipo, s.customer_id_servicio);

select a.*, rowid from sysadm.inh_rel_equ_ser a where a.customer_id_equipo = '1.01227319';

-- Valida fecha de Activacion del la linea.

select  codmin, fecregis, estado, imei, trajo_equipo, fecbscs
from activacion@activa 
where codmin = '3043573443'
and estado = 'ACTIVADO'


-- Validacion compra de equipo

SELECT customer_id, co_id,  Valor_facturado, cant_meses_pactados, cant_meses_superados, 
ult_mes_fact, imei, fecha_venta, causal, nro_total_cuotas
FROM activacion_equipo@activa
WHERE customer_id = 266781285 


-- Se valida si la linea tiene aprovisionada alguna promoci�n

select *
from sysadm.perm_usuarios      p, sysadm.perm_camp_usuarios c, sysadm.perm_campana  a
where p.customer_id in  (&customer)
and p.id = c.id_usuario
and c.id_campana = a.id



--  Se consulta si la promoci�n fue o no entregada. 

select * 
from sysadm.perm_historico_beneficios a 
where a.id_usuario in (&idusu)
order by fecha_registro desc;

1252 2221

select a.*, a.rowid
from sysadm.perm_camp_benef_vta_equipos a
where a.id_usuario = 1083199


-- ********************************************************************************
-- Validaciones COMHP35
-- cd /user1/users/INH_WORKARROUND/aplicaciones_back/AplicaCampanaPerm/log

-- grep 182147130 APLICACAMPANAPERM2015*.*
-- Si el rechazo generado es No se encontr� permanencia para el usuario, el caso debe ser escalado GSAC 
-- ellos son los que se encargan de esta permanencia.
-- ********************************************************************************


-- Se valida en la FEES si la promocion fue aplicada.

select seqno, a.customer_id, a.amount, a.remark, a.glcode, a.taxcode,a.entdate, period
from fees a
where customer_id = 264901425   
and remark like '%LD%'



select ciclo , nombre , inicio , final Fecha_Corte
from  inh_ciclos a , customer_all b
where a.ciclo = b.billcycle
and customer_id = 66243472


SELECT * 
  FROM sysadm.ex_cliente_promo 
WHERE co_id IN (SELECT co_id 
                   FROM contr_services a, directory_number b 
                  WHERE a.dn_id = b.dn_id 
                    AND b.dn_num in (&min));



select * from TBL_BENEFICIO


 

 
 

  
  
  
  
  
  
  
  
  
  
  
  
